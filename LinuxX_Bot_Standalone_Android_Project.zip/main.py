import http.server, socketserver, json, os, sys, subprocess, threading, urllib.parse
from pathlib import Path
BASE=Path(__file__).resolve().parent
CONFIG=BASE/"linuxx_config.json"
PORT=8765
worker=None
state={"token":"","room":"","username":""}
if CONFIG.exists():
    try: state.update(json.loads(CONFIG.read_text(encoding="utf-8")))
    except Exception: pass

def save():
    CONFIG.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")

def stop_worker():
    global worker
    if worker and worker.poll() is None:
        try: worker.terminate(); worker.wait(timeout=5)
        except Exception:
            try: worker.kill()
            except Exception: pass
    worker=None

class H(http.server.BaseHTTPRequestHandler):
    def out(self,obj,code=200):
        b=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def body(self):
        n=int(self.headers.get("Content-Length","0") or 0)
        try:return json.loads(self.rfile.read(n).decode()) if n else {}
        except:return {}
    def do_GET(self):
        if self.path=="/":
            b=(BASE/"index.html").read_bytes(); self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path=="/config":
            self.out({**state,"running":bool(worker and worker.poll() is None)}); return
        self.send_error(404)
    def do_POST(self):
        global state,worker
        if self.path=="/config":
            x=self.body()
            for k in ("token","room","username"): state[k]=str(x.get(k,"")).strip()
            save(); self.out({"ok":True}); return
        if self.path=="/start":
            x=self.body()
            for k in ("token","room","username"): state[k]=str(x.get(k,state[k])).strip()
            if not all(state.values()): self.out({"ok":False,"error":"Token / Room / Username required"},400); return
            save(); stop_worker()
            env=os.environ.copy(); env["LINUXX_OWNER_USERNAME"]=state["username"]; env["LINUXX_BOT_ID"]="1"; env["HIGHRISE_WORKER"]="1"
            cmd=[sys.executable,"-m","highrise","bot_worker:HighriseBot",state["room"],state["token"]]
            try:
                worker=subprocess.Popen(cmd,cwd=str(BASE),env=env)
                self.out({"ok":True})
            except Exception as e:self.out({"ok":False,"error":repr(e)},500)
            return
        if self.path=="/stop":
            stop_worker(); self.out({"ok":True}); return
        self.send_error(404)
    def log_message(self,*a):pass

def start_server():
    print("LinuxX UI: http://127.0.0.1:8765")
    with socketserver.ThreadingTCPServer(("127.0.0.1",PORT),H) as s:
        try:s.serve_forever()
        except KeyboardInterrupt:pass
        finally:stop_worker()

if __name__=="__main__":
    start_server()
