[app]
title = LinuxX Bot
package.name = linuxxbot
package.domain = com.linuxx
source.dir = .
source.include_exts = py,html,json,txt,db
version = 1.0.0
requirements = python3,kivy,pyjnius,highrise-bot-sdk
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,FOREGROUND_SERVICE,FOREGROUND_SERVICE_DATA_SYNC,POST_NOTIFICATIONS
android.api = 35
android.minapi = 26
android.archs = arm64-v8a, armeabi-v7a
services = LinuxXService:service.py
