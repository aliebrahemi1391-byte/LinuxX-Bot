from pathlib import Path
import shutil

p = Path("main.py")

# بکاپ قبل از تعمیر
backup = Path("main.py.before_repair_new_commands")
shutil.copy2(p, backup)

s = p.read_text(encoding="utf-8")

# ---------------------------------------------
# اصلاح رشته‌های چندخطی خراب
# ---------------------------------------------

replacements = {
'''                    "<#FFD700>فرمت صحیح:
!برو به @id vip"
''':
'''                    "<#FFD700>فرمت صحیح:\\n"
                    "!برو به @id vip"
''',

'''                    "<#FFD700>فرمت صحیح:
!بیا @id"
''':
'''                    "<#FFD700>فرمت صحیح:\\n"
                    "!بیا @id"
''',
}

fixed = 0

for old, new in replacements.items():
    if old in s:
        s = s.replace(old, new)
        fixed += 1

# ---------------------------------------------
# ترمیم حالت احتمالی دیگری که همین رشته‌ها
# به صورت واقعی با newline داخل کوتیشن آمده‌اند
# ---------------------------------------------

lines = s.splitlines()
out = []
i = 0

while i < len(lines):

    line = lines[i]

    # حالت خراب !برو به
    if '"<#FFD700>فرمت صحیح:' in line and i + 1 < len(lines):
        next_line = lines[i + 1]

        if '!برو به @id vip"' in next_line:
            indent = line[:len(line) - len(line.lstrip())]

            out.append(indent + '"<#FFD700>فرمت صحیح:\\n"')
            out.append(indent + '"!برو به @id vip"')

            fixed += 1
            i += 2
            continue

    # حالت خراب !بیا
    if '"<#FFD700>فرمت صحیح:' in line and i + 1 < len(lines):
        next_line = lines[i + 1]

        if '!بیا @id"' in next_line:
            indent = line[:len(line) - len(line.lstrip())]

            out.append(indent + '"<#FFD700>فرمت صحیح:\\n"')
            out.append(indent + '"!بیا @id"')

            fixed += 1
            i += 2
            continue

    out.append(line)
    i += 1

s = "\n".join(out) + "\n"

p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ LINUXX AUTO REPAIR")
print("==============================================")
print(f"✅ موارد اصلاح‌شده: {fixed}")
print("✅ بکاپ ساخته شد:")
print("   main.py.before_repair_new_commands")
print("==============================================")
