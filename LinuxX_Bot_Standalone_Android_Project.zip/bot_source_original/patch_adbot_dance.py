#!/usr/bin/env python3
from pathlib import Path
import re, shutil, py_compile

BASE = Path(__file__).resolve().parent
MAIN = BASE / "main.py"
if not MAIN.exists():
    raise SystemExit("❌ main.py پیدا نشد.")
if not (BASE / "adbot_dance.py").exists():
    raise SystemExit("❌ adbot_dance.py کنار این فایل نیست.")

s = MAIN.read_text(encoding="utf-8")
backup = BASE / "main.py.before_adbot_dance.bak"
shutil.copy2(MAIN, backup)

# Import
imp = "from adbot_dance import EMOTES, EMOTE_DURATIONS, resolve_emote, dance_duration"
if "from adbot_dance import" not in s:
    if "from dance_data import DANCES" in s:
        s = s.replace("from dance_data import DANCES", imp, 1)
    else:
        m = re.search(r"^(?:import .*\n|from .*\n)+", s, re.M)
        if not m:
            raise SystemExit("❌ محل importها پیدا نشد.")
        s = s[:m.end()] + imp + "\n" + s[m.end():]

# State
if "self.adbot_dance_tasks = {}" not in s:
    anchor = "self.floss_task = None"
    if anchor in s:
        s = s.replace(
            anchor,
            anchor + "\n        self.adbot_dance_tasks = {}\n        self.adbot_user_dances = {}\n",
            1,
        )
    else:
        raise SystemExit("❌ self.floss_task = None پیدا نشد.")

# Methods
marker = "    # -----------------------------------------------------\n    # USER JOIN\n"
if "async def start_adbot_dance" not in s:
    methods = """    # -----------------------------------------------------
    # AD-BOT DANCE ENGINE
    # -----------------------------------------------------

    async def stop_adbot_dance(self, user):
        uid = str(user.id)
        self.adbot_user_dances.pop(uid, None)
        task = self.adbot_dance_tasks.pop(uid, None)
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                print("[DANCE STOP ERROR]", e)

    async def start_adbot_dance(self, user, emote_id):
        uid = str(user.id)
        await self.stop_adbot_dance(user)
        self.adbot_user_dances[uid] = emote_id
        sleep_time = dance_duration(emote_id) + 1.0

        async def dance_loop():
            try:
                while self.adbot_user_dances.get(uid) == emote_id:
                    await self.highrise.send_emote(emote_id, uid)
                    await asyncio.sleep(sleep_time)
            except asyncio.CancelledError:
                return
            except Exception as e:
                print("[DANCE ERROR]", emote_id, type(e).__name__, e)

        self.adbot_dance_tasks[uid] = asyncio.create_task(dance_loop())

"""
    if marker not in s:
        raise SystemExit("❌ محل USER JOIN پیدا نشد.")
    s = s.replace(marker, methods + marker, 1)

# Replace existing numeric dance block
start_marker = """        # -----------------------------------------------
        # DANCE
        # -----------------------------------------------
"""
end_marker = """        # -----------------------------------------------
        # TASE
        # -----------------------------------------------
"""
start = s.find(start_marker)
end = s.find(end_marker, start + len(start_marker)) if start >= 0 else -1
if start < 0 or end < 0:
    raise SystemExit("❌ بخش DANCE/TASE فعلی پیدا نشد.")

new_dance = """        # -----------------------------------------------
        # AD-BOT DANCE / EMOTE
        # -----------------------------------------------

        normalized = text.translate(
            str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789",
            )
        )

        emote_id = resolve_emote(normalized)

        if emote_id:
            try:
                await self.start_adbot_dance(user, emote_id)
            except Exception as e:
                print("[DANCE START ERROR]", e)
            return

        if normalized.lower() in (
            "stop",
            "dance stop",
            "!stop",
            "!dance stop",
            "توقف",
            "توقف دنس",
        ):
            await self.stop_adbot_dance(user)
            return

"""
s = s[:start] + new_dance + s[end:]

# Replace fixed floss interval
old = """    async def floss_loop(self):

        while self.running:

            try:
                await self.highrise.send_emote(
                    DANCES["222"]
                )
            except Exception as e:
                print(
                    "[FLOSS ERROR]",
                    e
                )

            await asyncio.sleep(8)
"""
new = """    async def floss_loop(self):

        floss = resolve_emote("222") or "dance-floss"
        sleep_time = dance_duration(floss) + 1.0

        while self.running:

            try:
                await self.highrise.send_emote(floss)
            except Exception as e:
                print(
                    "[FLOSS ERROR]",
                    e
                )

            await asyncio.sleep(sleep_time)
"""
if old in s:
    s = s.replace(old, new, 1)

# Clean up on leave
leave = """    async def on_user_leave(self, user):
        uid = str(user.id)

        self.users.pop(uid, None)
        self.positions.pop(uid, None)
"""
if leave in s and "self.adbot_dance_tasks.pop(uid, None)" not in s:
    s = s.replace(
        leave,
        leave + """
        self.adbot_user_dances.pop(uid, None)
        task = self.adbot_dance_tasks.pop(uid, None)
        if task:
            task.cancel()
""",
        1,
    )

MAIN.write_text(s, encoding="utf-8")

try:
    py_compile.compile(str(MAIN), doraise=True)
except Exception:
    shutil.copy2(backup, MAIN)
    raise

print("✅ AD-BOT Dance Engine نصب شد")
print("✅ 724 emote/alias منتقل شد")
print("✅ تنظیمات Dance از AD-BOT آماده انتقال است")
print("✅ duration + 1.0 فعال شد")
print("✅ دنس قبلی هر کاربر قبل از دنس جدید متوقف می‌شود")
print("✅ backup ساخته شد:", backup.name)
print("✅ py_compile: OK")
