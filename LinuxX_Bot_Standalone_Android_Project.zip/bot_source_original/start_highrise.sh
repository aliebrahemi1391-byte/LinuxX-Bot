#!/data/data/com.termux/files/usr/bin/bash

cd "$HOME/highrise/LinuxXBot" || exit 1

while true; do
    echo "[$(date '+%H:%M:%S')] 🚀 Starting LinuxX Bot..."
    python main.py

    echo "[$(date '+%H:%M:%S')] ⚠️ Bot stopped. Restarting in 5 seconds..."
    sleep 5
done
