from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

start = s.find('        text_normalized = text.strip()')

if start == -1:
    print("❌ بخش text_normalized پیدا نشد")
    raise SystemExit(1)

end = s.find('        # حذف بات', start)

if end == -1:
    print("❌ بخش # حذف بات پیدا نشد")
    raise SystemExit(1)

new_block = r'''        text_normalized = text.strip()

        is_settings_button = text_normalized in (
            "⚙️ تنظیمات بات",
            "تنظیمات بات ⚙️",
            "⚙️ تنظیمات بات ۱",
            "تنظیمات بات",
            "تنظیمات بات ۱",
        )

        is_toggle_button = text_normalized in (
            "🟢 روشن",
            "روشن 🟢",
            "🔴 خاموش",
            "خاموش 🔴",
            "🟢 روشن بات",
            "🔴 خاموش بات",
            "🟢 روشن بات ۱",
            "🔴 خاموش بات ۱",
        )

        # -------------------------------------------------
        # تنظیمات بات
        # -------------------------------------------------

        if is_settings_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است."
                )
                return

            context.user_data.clear()
            context.user_data["settings_bot"] = bot["id"]

            await update.message.reply_text(
                "⚙️ تنظیمات بات\n\n"
                f"🤖 بات #{bot['id']}\n"
                f"🌐 Room: {bot['room_id']}\n"
                f"👤 مدیر: @{bot['owner_username']}\n\n"
                "برای تغییر اطلاعات، گزینه موردنظر را انتخاب کن."
            )

            return

        # -------------------------------------------------
        # روشن / خاموش
        # -------------------------------------------------

        if is_toggle_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است.\n\n"
                    "ابتدا تنظیمات بات را کامل کن."
                )
                return

            token = str(bot["token"] or "").strip()
            room_id = str(bot["room_id"] or "").strip()
            manager_id = str(
                bot["manager_id"] or bot["owner_username"] or ""
            ).strip()

            if not token or not room_id or not manager_id:

                await update.message.reply_text(
                    "⚠️ ابتدا تنظیمات بات را کامل کن.\n\n"
                    "🔑 توکن Highrise\n"
                    "🌐 لینک یا ID روم\n"
                    "👤 ID مدیر"
                )
                return

            new_state = not bool(bot["enabled"])

            if new_state:

                try:
                    set_enabled(bot["id"], True)

                    fresh = get_bot(bot["id"])

                    self.spawn(fresh)

                    await update.message.reply_text(
                        "🟢 بات با موفقیت روشن شد.",
                        reply_markup=self.main_keyboard([fresh]),
                    )

                except Exception as e:

                    set_enabled(bot["id"], False)

                    await update.message.reply_text(
                        "❌ روشن کردن بات ناموفق بود.\n\n"
                        f"خطا: {e}",
                        reply_markup=self.main_keyboard(
                            [get_bot(bot["id"])]
                        ),
                    )

            else:

                set_enabled(bot["id"], False)
                self.stop(bot["id"])

                fresh = get_bot(bot["id"])

                await update.message.reply_text(
                    "🔴 بات خاموش شد.",
                    reply_markup=self.main_keyboard([fresh]),
                )

            return

'''

s = s[:start] + new_block + s[end:]

p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ BOTTOM BLOCK REPAIRED")
print("==============================================")
print("✅ رشته‌های چندخطی خراب اصلاح شدند")
print("✅ تنظیمات بات اصلاح شد")
print("✅ روشن/خاموش اصلاح شد")
print("✅ SyntaxError خط 2501 باید برطرف شود")
print("==============================================")
