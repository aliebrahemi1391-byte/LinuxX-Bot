from pathlib import Path

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# =========================================================
# 1. ADD manager_id TO DATABASE
# =========================================================

old = '''        CREATE TABLE IF NOT EXISTS bots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_user_id INTEGER NOT NULL,
            token TEXT NOT NULL,
            room_id TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
'''

new = '''        CREATE TABLE IF NOT EXISTS bots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_user_id INTEGER NOT NULL,
            token TEXT NOT NULL,
            room_id TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            manager_id TEXT DEFAULT '',
            enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
'''

if old in s:
    s = s.replace(old, new, 1)

# برای دیتابیس فعلی
marker = '''    conn.commit()
    conn.close()


def get_user_bots'''
replacement = '''    # اضافه کردن ستون برای دیتابیس‌های قدیمی
    try:
        conn.execute(
            "ALTER TABLE bots ADD COLUMN manager_id TEXT DEFAULT ''"
        )
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()


def get_user_bots'''

if marker in s and 'ALTER TABLE bots ADD COLUMN manager_id' not in s:
    s = s.replace(marker, replacement, 1)

# =========================================================
# 2. INITIAL SETUP: TOKEN -> ROOM -> MANAGER ID
# =========================================================

s = s.replace(
'''            context.user_data["setup"] = "owner"

            await update.message.reply_text(
                "👤 حالا نام کاربری مالک بات در Highrise را ارسال کن:"
            )
''',
'''            context.user_data["setup"] = "manager"

            await update.message.reply_text(
                "👤 حالا ID مدیر Highrise این بات را ارسال کن:"
            )
''',
1
)

s = s.replace(
'''        if setup == "owner":

            owner = text.lstrip("@").strip()

            if not owner:

                await update.message.reply_text(
                    "❌ نام کاربری معتبر نیست."
                )

                return

            token = context.user_data.get(
                "new_token"
            )

            room_id = context.user_data.get(
                "new_room"
            )

            if not token or not room_id:

                context.user_data.clear()

                await update.message.reply_text(
                    "❌ اطلاعات ناقص است. دوباره /start را بزن."
                )

                return

            try:

                bot_id = create_or_update_bot(
                    user_id,
                    token,
                    room_id,
                    owner,
                )

            except Exception as e:

                context.user_data.clear()

                await update.message.reply_text(
                    f"❌ خطا در ثبت بات:\\n{e}"
                )

                return
''',
'''        if setup == "manager":

            manager_id = text.strip()

            if not manager_id or len(manager_id) < 5:

                await update.message.reply_text(
                    "❌ ID مدیر نامعتبر است. دوباره ارسال کن."
                )

                return

            token = context.user_data.get(
                "new_token"
            )

            room_id = context.user_data.get(
                "new_room"
            )

            if not token or not room_id:

                context.user_data.clear()

                await update.message.reply_text(
                    "❌ اطلاعات ناقص است. دوباره /start را بزن."
                )

                return

            try:

                bot_id = create_or_update_bot(
                    user_id,
                    token,
                    room_id,
                    manager_id,
                )

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET manager_id=?,
                        owner_username=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        manager_id,
                        manager_id,
                        bot_id,
                    ),
                )

                conn.commit()
                conn.close()

            except Exception as e:

                context.user_data.clear()

                await update.message.reply_text(
                    f"❌ خطا در ثبت بات:\\n{e}"
                )

                return
''',
1
)

# =========================================================
# 3. 4 BUTTON MAIN KEYBOARD
# =========================================================

start = s.find('    def main_keyboard(self, bots):')
end = s.find('    def keyboard(self, bot_id):', start)

if start != -1 and end != -1:

    new_keyboard = '''    def main_keyboard(self, bots):

        rows = []

        # بات 1
        bot1 = get_bot(1)

        if bot1:
            status1 = "🟢 روشن" if bot1["enabled"] else "🔴 خاموش"

            rows.append([
                InlineKeyboardButton(
                    "⚙️ تنظیمات بات ۱",
                    callback_data="settings:1"
                ),
                InlineKeyboardButton(
                    f"{status1} بات ۱",
                    callback_data="toggle:1"
                )
            ])

        # بات 2
        bot2 = get_bot(2)

        if bot2:
            status2 = "🟢 روشن" if bot2["enabled"] else "🔴 خاموش"

            rows.append([
                InlineKeyboardButton(
                    "⚙️ تنظیمات بات ۲",
                    callback_data="settings:2"
                ),
                InlineKeyboardButton(
                    f"{status2} بات ۲",
                    callback_data="toggle:2"
                )
            ])

        # اگر هیچ باتی وجود ندارد
        if not bot1 and not bot2:
            rows.append([
                InlineKeyboardButton(
                    "➕ ساخت بات ۱",
                    callback_data="add_bot"
                )
            ])

        # اگر فقط بات ۱ وجود دارد
        elif bot1 and not bot2:
            rows.append([
                InlineKeyboardButton(
                    "➕ ساخت بات ۲",
                    callback_data="add_bot"
                )
            ])

        return InlineKeyboardMarkup(rows)

'''

    s = s[:start] + new_keyboard + s[end:]

# =========================================================
# 4. SETTINGS BUTTONS
# =========================================================

start = s.find('    def settings_keyboard(self, bot_id):')
end = s.find('    # -----------------------------------------------------', start + 20)

if start != -1 and end != -1:

    settings = '''    def settings_keyboard(self, bot_id):

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🔑 تغییر توکن",
                    callback_data=f"token:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "🌐 تغییر لینک/ID روم",
                    callback_data=f"room:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "👤 تغییر ID مدیر",
                    callback_data=f"manager:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "🔙 بازگشت",
                    callback_data=f"panel:{bot_id}"
                )
            ]
        ])

'''

    s = s[:start] + settings + s[end:]

# =========================================================
# 5. MANAGER EDIT SUPPORT
# =========================================================

s = s.replace(
'''        if action in (
            "token",
            "room",
            "owner",
        ):
''',
'''        if action in (
            "token",
            "room",
            "manager",
        ):
''',
1
)

s = s.replace(
'''                "owner":
                    "👤 نام کاربری مالک جدید را ارسال کن:",
''',
'''                "manager":
                    "👤 ID مدیر جدید را ارسال کن:",
''',
1
)

# owner -> manager in edit logic
s = s.replace(
'''            elif edit_type == "owner":

                owner = text.lstrip("@").strip()

                if not owner:

                    await update.message.reply_text(
                        "❌ نام کاربری مالک نمی‌تواند خالی باشد.\\n\\n"
                        "🔒 مالک قبلی حفظ شد."
                    )

                    return

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET owner_username=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        owner,
                        edit_bot,
                    ),
                )

                conn.commit()
                conn.close()
''',
'''            elif edit_type == "manager":

                manager_id = text.strip()

                if not manager_id or len(manager_id) < 5:

                    await update.message.reply_text(
                        "❌ ID مدیر نامعتبر است.\\n\\n"
                        "🔒 مقدار قبلی حفظ شد."
                    )

                    return

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET manager_id=?,
                        owner_username=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        manager_id,
                        manager_id,
                        edit_bot,
                    ),
                )

                conn.commit()
                conn.close()
''',
1
)

# =========================================================
# SAVE
# =========================================================

p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ LinuxX 4-BUTTON FINAL UI PATCH")
print("==============================================")
print("✅ Token")
print("✅ Room ID / Link")
print("✅ Manager ID")
print("✅ Bot 1 settings + toggle")
print("✅ Bot 2 settings + toggle")
print("✅ Existing password system preserved")
print("==============================================")
