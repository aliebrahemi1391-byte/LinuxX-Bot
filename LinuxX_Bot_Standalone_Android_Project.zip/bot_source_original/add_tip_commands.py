from pathlib import Path

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1) اضافه کردن دستورهای Tip به ADMIN CHECK
# ---------------------------------------------------------

old = '''            or text.startswith("!اسپم ")
        )'''

new = '''            or text.startswith("!اسپم ")
            or text == "!موجودی"
            or text.startswith("!تیپ ")
        )'''

if old not in s:
    raise SystemExit("❌ بخش ADMIN CHECK پیدا نشد؛ هیچ تغییری اعمال نشد.")

s = s.replace(old, new, 1)


# ---------------------------------------------------------
# 2) اضافه کردن دستورهای Tip قبل از FIND TARGET
# ---------------------------------------------------------

anchor = '''        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):'''

tip_block = r'''        # -----------------------------------------------
        # LINUXX GOLD TIP SYSTEM
        # -----------------------------------------------

        TIP_BARS = {
            1: "gold_bar_1",
            5: "gold_bar_5",
            10: "gold_bar_10",
            50: "gold_bar_50",
            100: "gold_bar_100",
            500: "gold_bar_500",
            1000: "gold_bar_1k",
            5000: "gold_bar_5000",
            10000: "gold_bar_10k",
        }

        TIP_LABELS = {
            1: "۱",
            5: "۵",
            10: "۱۰",
            50: "۵۰",
            100: "۱۰۰",
            500: "۵۰۰",
            1000: "۱۰۰۰",
            5000: "۵۰۰۰",
            10000: "۱۰۰۰۰",
        }

        def get_gold_amount(wallet_response):
            total = 0

            try:
                content = getattr(
                    wallet_response,
                    "content",
                    []
                )

                for currency in content:
                    ctype = str(
                        getattr(currency, "type", "")
                    ).lower()

                    amount = int(
                        getattr(currency, "amount", 0)
                    )

                    # نسخه‌های مختلف SDK ممکن است نام Gold را
                    # کمی متفاوت برگردانند.
                    if (
                        ctype == "gold"
                        or "gold" in ctype
                    ):
                        total += amount

            except Exception as e:
                print("[TIP WALLET PARSE ERROR]", repr(e))

            return total

        async def get_bot_gold():
            try:
                wallet = await self.highrise.get_wallet()
                return get_gold_amount(wallet)
            except Exception as e:
                print("[TIP WALLET ERROR]", repr(e))
                return None

        # -----------------------------------------------
        # موجودی گلد
        # -----------------------------------------------

        if text == "!موجودی":

            gold = await get_bot_gold()

            if gold is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ دریافت موجودی گلد ناموفق بود."
                )
                return

            await self.highrise.send_whisper(
                uid,
                f"<#FFD700>💰 موجودی گلد بات: {gold}"
            )

            return

        # -----------------------------------------------
        # TIP
        #
        # !تیپ ۱ @id
        # !تیپ ۵ @id
        # !تیپ ۱۰ @id
        # !تیپ همه ۱
        # -----------------------------------------------

        if text.startswith("!تیپ "):

            parts = text.split()

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n"
                    "!تیپ ۱ @id\n"
                    "!تیپ ۵ @id\n"
                    "!تیپ همه ۱"
                )
                return

            # تبدیل اعداد فارسی به انگلیسی
            def normalize_number(value):
                return value.translate(
                    str.maketrans(
                        "۰۱۲۳۴۵۶۷۸۹",
                        "0123456789"
                    )
                )

            # -------------------------------------------
            # TIP ALL
            # -------------------------------------------

            if parts[1] == "همه":

                amount_text = normalize_number(
                    parts[2]
                )

                if not amount_text.isdigit():
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار گلد نامعتبر است."
                    )
                    return

                amount = int(amount_text)

                if amount not in TIP_BARS:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار مجاز:\n"
                        "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                        "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                    )
                    return

                try:
                    room_response = (
                        await self.highrise.get_room_users()
                    )

                    room_users = getattr(
                        room_response,
                        "content",
                        []
                    )

                except Exception as e:
                    print(
                        "[TIP ROOM USERS ERROR]",
                        repr(e)
                    )

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ دریافت کاربران روم ناموفق بود."
                    )
                    return

                sent = 0
                failed = 0

                await self.highrise.chat(
                    f"<#FFD700>💰 شروع تیپ {TIP_LABELS[amount]} گلد به کاربران..."
                )

                for item in room_users:

                    target = getattr(
                        item,
                        "user",
                        item
                    )

                    target_id = getattr(
                        target,
                        "id",
                        None
                    )

                    target_username = getattr(
                        target,
                        "username",
                        "unknown"
                    )

                    if not target_id:
                        continue

                    # خود بات تیپ نشود
                    if str(target_id) == str(
                        getattr(self, "bot_id", "")
                    ):
                        continue

                    try:
                        wallet_gold = await get_bot_gold()

                        if wallet_gold is not None:
                            if wallet_gold < amount:
                                await self.highrise.send_whisper(
                                    uid,
                                    f"<#FF5555>🛑 موجودی تمام شد.\n"
                                    f"<#FFFFFF>تعداد ارسال موفق: {sent}"
                                )
                                return

                        result = await self.highrise.tip_user(
                            str(target_id),
                            TIP_BARS[amount]
                        )

                        if result == "success":

                            sent += 1

                            print(
                                f"[TIP] {amount} -> "
                                f"@{target_username}"
                            )

                            # مطابق منطق AD-BOT:
                            # بین ارسال‌های متوالی فاصله کوتاه
                            await asyncio.sleep(3)

                        elif result == "insufficient_funds":

                            await self.highrise.send_whisper(
                                uid,
                                f"<#FF5555>🛑 موجودی گلد کافی نیست.\n"
                                f"<#FFFFFF>ارسال موفق: {sent}"
                            )

                            return

                        else:

                            failed += 1

                            print(
                                "[TIP ERROR RESULT]",
                                result
                            )

                    except Exception as e:

                        failed += 1

                        print(
                            "[TIP USER ERROR]",
                            target_username,
                            repr(e)
                        )

                        # خطای یک کاربر باعث خراب شدن
                        # کل دستور نشود.
                        continue

                await self.highrise.send_whisper(
                    uid,
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {sent}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return

            # -------------------------------------------
            # TIP ONE USER
            # -------------------------------------------

            amount_text = normalize_number(
                parts[1]
            )

            if not amount_text.isdigit():

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار گلد باید عدد باشد."
                )
                return

            amount = int(amount_text)

            if amount not in TIP_BARS:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return

            target_name = parts[2].strip()

            target = self.find_user(
                target_name
            )

            if not target:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            wallet_gold = await get_bot_gold()

            if wallet_gold is not None and wallet_gold < amount:

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ موجودی کافی نیست.\n"
                    f"<#FFFFFF>موجودی: {wallet_gold}\n"
                    f"<#FFFFFF>مورد نیاز: {amount}"
                )
                return

            try:

                result = await self.highrise.tip_user(
                    str(target.id),
                    TIP_BARS[amount]
                )

                if result == "success":

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>✅ {TIP_LABELS[amount]} گلد "
                        f"به @{target.username} تیپ شد."
                    )

                elif result == "insufficient_funds":

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ موجودی گلد کافی نیست."
                    )

                else:

                    await self.highrise.send_whisper(
                        uid,
                        f"<#FF5555>❌ تیپ انجام نشد.\n"
                        f"نتیجه: {result}"
                    )

            except Exception as e:

                print(
                    "[TIP USER ERROR]",
                    repr(e)
                )

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ خطا هنگام ارسال گلد."
                )

            return

        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):'''

if anchor not in s:
    raise SystemExit(
        "❌ محل FIND TARGET پیدا نشد؛ هیچ تغییری اعمال نشد."
    )

s = s.replace(
    anchor,
    tip_block,
    1
)


# ---------------------------------------------------------
# 3) اضافه کردن Tip به لیست دستورات مدیریتی
# ---------------------------------------------------------

old_help = '''                    "!انموت @id\\n"
                    "!حرکت\\n"'''

new_help = '''                    "!انموت @id\\n"
                    "!موجودی\\n"
                    "!تیپ ۱ @id\\n"
                    "!تیپ ۵ @id\\n"
                    "!تیپ همه ۱\\n"
                    "!تیپ همه ۵\\n"
                    "!حرکت\\n"'''

if old_help in s:
    s = s.replace(old_help, new_help, 1)
else:
    print("⚠️ بخش help پیدا نشد؛ فقط منطق Tip اضافه شد.")


p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ LINUXX TIP SYSTEM ADDED")
print("==============================================")
print("✅ !تیپ ۱ @id")
print("✅ !تیپ ۵ @id")
print("✅ !تیپ ۱۰ @id")
print("✅ !تیپ ۵۰ @id")
print("✅ !تیپ ۱۰۰ @id")
print("✅ !تیپ ۵۰۰ @id")
print("✅ !تیپ ۱۰۰۰ @id")
print("✅ !تیپ ۵۰۰۰ @id")
print("✅ !تیپ ۱۰۰۰۰ @id")
print("✅ !تیپ همه ۱")
print("✅ !تیپ همه ۵")
print("✅ !موجودی")
print("✅ توقف خودکار هنگام insufficient_funds")
print("✅ دستورات قبلی دست‌نخورده")
print("==============================================")
