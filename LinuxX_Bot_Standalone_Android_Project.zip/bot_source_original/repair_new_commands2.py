from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

start_marker = "        # BRING USER TO ADMIN"
end_marker = "        # OUTFIT FROM TARGET"

start = s.find(start_marker)
end = s.find(end_marker)

if start == -1:
    print("❌ شروع بخش دستورات جدید پیدا نشد")
    raise SystemExit(1)

if end == -1:
    print("❌ انتهای بخش دستورات جدید پیدا نشد")
    raise SystemExit(1)

new_block = r'''        # -----------------------------------------------
        # BRING USER TO ADMIN
        # !بیا @id
        # -----------------------------------------------

        if text.startswith("!بیا "):

            target_name = text[len("!بیا "):].strip()

            if not target_name:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح: !بیا @id"
                )
                return

            target = self.find_user(target_name)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            admin_position = self.positions.get(uid)

            if admin_position is None:
                await self.refresh_users()
                admin_position = self.positions.get(uid)

            if admin_position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            try:
                await self.highrise.teleport(
                    str(target.id),
                    admin_position
                )

                await self.highrise.chat(
                    f"<#00FF88>📍 @{target.username} به سمت مدیر منتقل شد."
                )

            except Exception as e:
                print("[BRING USER ERROR]", repr(e))

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ انتقال کاربر انجام نشد."
                )

            return

        # -----------------------------------------------
        # MOVE USER TO SAVED LOCATION
        # !برو به @id vip
        # -----------------------------------------------

        if text.startswith("!برو به "):

            parts = text.split(maxsplit=2)

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n"
                    "<#FFFFFF>!برو به @id vip"
                )
                return

            target_name = parts[1].strip()
            location_name = parts[2].strip()

            target = self.find_user(target_name)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            locations = self._load_locations()

            if location_name not in locations.get("admin", {}):
                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ محل ادمین «{location_name}» پیدا نشد."
                )
                return

            position = self._dict_to_position(
                locations["admin"][location_name]
            )

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مختصات محل معتبر نیست."
                )
                return

            try:
                await self.highrise.teleport(
                    str(target.id),
                    position
                )

                await self.highrise.chat(
                    f"<#00FF88>📍 @{target.username} "
                    f"به محل «{location_name}» منتقل شد."
                )

            except Exception as e:
                print(
                    "[MOVE USER TO LOCATION ERROR]",
                    repr(e)
                )

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ انتقال کاربر به محل انجام نشد."
                )

            return

'''

s = s[:start] + new_block + s[end:]

p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ LINUXX NEW COMMANDS REPAIRED")
print("==============================================")
print("✅ !بیا @id اصلاح شد")
print("✅ !برو به @id vip اصلاح شد")
print("✅ رشته‌های چندخطی خراب حذف شدند")
print("✅ تیپ دست‌نخورده")
print("✅ سیستم روبیکا/تلگرام دست‌نخورده")
print("==============================================")
