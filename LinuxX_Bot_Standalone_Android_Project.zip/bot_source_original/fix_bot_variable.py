from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# فقط داخل text_handler کار می‌کنیم
m = re.search(
    r'(?m)^    async def text_handler\(.*?\n(?=    (?:async )?def |\Z)',
    s,
    re.DOTALL
)

if not m:
    print("❌ text_handler پیدا نشد")
    raise SystemExit(1)

block = m.group(0)

# اگر قبلاً وجود دارد، دوباره اضافه نکن
if "bots = get_user_bots(user_id)" in block and "bot = bots[0] if bots else None" in block:
    print("✅ متغیر bot از قبل وجود دارد")
    raise SystemExit(0)

# محل مناسب: بعد از user_id
pattern = r'(?m)^(\s+user_id\s*=\s*update\.effective_user\.id\s*)$'

match = re.search(pattern, block)

if not match:
    print("❌ خط user_id داخل text_handler پیدا نشد")
    print("باید بخش text_handler را بررسی کنیم.")
    raise SystemExit(1)

indent = re.match(r'\s+', match.group(1)).group(0)

insert = (
    match.group(1)
    + "\n"
    + indent + "# وضعیت فعلی بات کاربر\n"
    + indent + "bots = get_user_bots(user_id)\n"
    + indent + "bot = bots[0] if bots else None\n"
)

new_block = block[:match.start()] + insert + block[match.end():]

s = s[:m.start()] + new_block + s[m.end():]

p.write_text(s, encoding="utf-8")

print("==============================================")
print("✅ BOT VARIABLE FIX")
print("==============================================")
print("✅ bots تعریف شد")
print("✅ bot تعریف شد")
print("✅ text_handler اصلاح شد")
print("==============================================")
