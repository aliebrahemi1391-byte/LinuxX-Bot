from pathlib import Path
import shutil
import re
import py_compile

BASE = Path(__file__).resolve().parent
MAIN = BASE / "main.py"
BACKUP = BASE / "main.py.before_final_panel.bak"

print("=" * 60)
print("      LinuxX FINAL PANEL AUTO FIX")
print("=" * 60)

if not MAIN.exists():
    print("❌ main.py پیدا نشد")
    raise SystemExit(1)

shutil.copy2(MAIN, BACKUP)
print("✅ Backup:", BACKUP.name)

s = MAIN.read_text(encoding="utf-8")

# =========================================================
# 1. فقط یک بات برای هر کاربر
# =========================================================

s = re.sub(
    r"MAX_BOTS_PER_USER\s*=\s*\d+",
    "MAX_BOTS_PER_USER = 1",
    s,
    count=1,
)

print("✅ MAX_BOTS_PER_USER = 1")

# =========================================================
# 2. حذف ReplyKeyboard از import
# =========================================================

s = s.replace(
    "    ReplyKeyboardMarkup,\n",
    "",
)

s = s.replace(
    "    ReplyKeyboardRemove,\n",
    "",
)

# =========================================================
# 3. main_keyboard
# =========================================================

start = s.find("    def main_keyboard(self, bots):")
end = s.find("    def keyboard(self, bot_id):", start)

if start == -1 or end == -1:
    print("❌ main_keyboard پیدا نشد")
    shutil.copy2(BACKUP, MAIN)
    raise SystemExit(1)

new_main_keyboard = '''    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        # -------------------------------------------------
        # فقط دو دکمه شیشه‌ای
        # -------------------------------------------------

        if bot:

            status = (
                "🟢 روشن"
                if bot["enabled"]
                else "🔴 خاموش"
            )

            toggle_text = f"{status} / تغییر وضعیت"

        else:

            toggle_text = "🟢 روشن کردن بات"

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "⚙️ تنظیمات بات",
                    callback_data="settings:1",
                ),
                InlineKeyboardButton(
                    toggle_text,
                    callback_data="toggle:1",
                ),
            ]
        ])

'''

s = s[:start] + new_main_keyboard + s[end:]

print("✅ پنل اصلی به ۲ دکمه Inline تبدیل شد")

# =========================================================
# 4. حذف ReplyKeyboard از پیام‌های قبلی پنل
# =========================================================

# اگر قبلاً main_keyboard در جای دیگری استفاده شده،
# همچنان InlineKeyboardMarkup برمی‌گرداند.

# =========================================================
# 5. اصلاح بخش BUTTON
# =========================================================

marker = '''        row = get_bot(bot_id)

        if not row:

            await query.edit_message_text(
                "❌ بات پیدا نشد."
            )

            return
'''

if marker not in s:
    print("❌ بخش get_bot در button پیدا نشد")
    shutil.copy2(BACKUP, MAIN)
    raise SystemExit(1)

replacement = '''        row = get_bot(bot_id)

        # -------------------------------------------------
        # TOGGLE BEFORE BOT EXISTS
        # -------------------------------------------------

        if action == "toggle" and not row:

            context.user_data.clear()

            context.user_data["setup"] = "token"

            await query.edit_message_text(
                "➕ راه‌اندازی بات ۱\\n\\n"
                "🔑 مرحله ۱ از ۳\\n"
                "توکن Highrise را ارسال کن:"
            )

            return

        if not row:

            await query.edit_message_text(
                "❌ بات هنوز راه‌اندازی نشده است.\\n\\n"
                "ابتدا روی «روشن کردن بات» بزن."
            )

            return
'''

s = s.replace(marker, replacement, 1)

print("✅ دکمه روشن قبل از ساخت بات فعال شد")

# =========================================================
# 6. متن تنظیمات را ساده‌تر کن
# =========================================================

old_settings = '''            await query.edit_message_text(
                "⚙️ تنظیمات بات:",
                reply_markup=self.settings_keyboard(bot_id),
            )
'''

new_settings = '''            await query.edit_message_text(
                "⚙️ تنظیمات بات ۱\\n\\n"
                f"🤖 بات: #{bot_id}\\n"
                f"🌐 Room: {row['room_id']}\\n"
                f"👤 مدیر: @{row['owner_username']}\\n\\n"
                "یکی از گزینه‌ها را انتخاب کن:",
                reply_markup=self.settings_keyboard(bot_id),
            )
'''

if old_settings in s:
    s = s.replace(old_settings, new_settings, 1)
    print("✅ صفحه تنظیمات اصلاح شد")

# =========================================================
# 7. وقتی ساخت بات تمام شد، خودکار روشن شود
# =========================================================

old_create_message = '''            row = get_bot(bot_id)

            await update.message.reply_text(
                "✅ بات با موفقیت ثبت شد.\\n\\n"
                f"🤖 بات #{bot_id}\\n"
                "🔴 وضعیت: خاموش\\n\\n"
                "برای ورود بات به روم، دکمه روشن را بزن.",
                reply_markup=self.keyboard(bot_id),
            )

            return
'''

new_create_message = '''            # -------------------------------------------------
            # AUTO ENABLE AFTER FIRST SETUP
            # -------------------------------------------------

            set_enabled(bot_id, True)

            row = get_bot(bot_id)

            self.spawn(row)

            await update.message.reply_text(
                "✅ اطلاعات بات با موفقیت ثبت شد.\\n\\n"
                f"🤖 بات #{bot_id}\\n"
                "🟢 وضعیت: روشن\\n\\n"
                "بات به‌صورت خودکار وارد روم می‌شود.",
                reply_markup=self.main_keyboard([row]),
            )

            return
'''

if old_create_message in s:
    s = s.replace(old_create_message, new_create_message, 1)
    print("✅ بات بعد از ثبت اطلاعات خودکار روشن می‌شود")
else:
    print("⚠️ پیام ساخت بات با متن مورد انتظار پیدا نشد")

# =========================================================
# 8. بعد از رمز صحیح، فقط پنل اصلی را نمایش بده
# =========================================================

old_auth = '''                await update.message.reply_text(
                    "✅ رمز صحیح است.\\n\\n"
                    "🟢 دسترسی به پنل فعال شد.",
                    reply_markup=self.main_keyboard(bots),
                )
'''

new_auth = '''                await update.message.reply_text(
                    "🟢 LinuxX Highrise Manager\\n\\n"
                    "خوش آمدید 👑\\n"
                    "برای مدیریت بات از دکمه‌های زیر استفاده کن.",
                    reply_markup=self.main_keyboard(bots),
                )
'''

if old_auth in s:
    s = s.replace(old_auth, new_auth, 1)
    print("✅ پنل بعد از احراز هویت اصلاح شد")

# =========================================================
# 9. start_command
# =========================================================

old_start = '''        await update.message.reply_text(
            "🟢 LinuxX Highrise Manager\\n\\n"
            "خوش آمدید 👑\\n"
            "پنل مدیریت بات‌ها آماده است.",
            reply_markup=self.main_keyboard(bots),
        )
'''

new_start = '''        await update.message.reply_text(
            "🟢 LinuxX Highrise Manager\\n\\n"
            "خوش آمدید 👑\\n"
            "برای مدیریت بات از دکمه‌های زیر استفاده کن.",
            reply_markup=self.main_keyboard(bots),
        )
'''

if old_start in s:
    s = s.replace(old_start, new_start, 1)
    print("✅ /start اصلاح شد")

# =========================================================
# 10. حذف دکمه ساخت بات از main_keyboard قدیمی
# =========================================================

# main_keyboard قبلاً کامل جایگزین شده است.

# =========================================================
# 11. ذخیره
# =========================================================

MAIN.write_text(s, encoding="utf-8")

print("✅ main.py ذخیره شد")

# =========================================================
# 12. Compile
# =========================================================

try:
    py_compile.compile(
        str(MAIN),
        doraise=True,
    )
except Exception as e:

    print()
    print("❌ Syntax Error")
    print(e)
    print()
    print("🔄 برگرداندن بکاپ...")

    shutil.copy2(BACKUP, MAIN)

    print("✅ بکاپ برگشت داده شد")
    raise SystemExit(1)

print()
print("=" * 60)
print("✅ LinuxX FINAL PANEL نصب شد")
print("=" * 60)
print("✅ سیستم رمز باقی ماند")
print("✅ ۳ تلاش رمز")
print("✅ هر کاربر فقط ۱ بات")
print("✅ فقط ۲ دکمه شیشه‌ای")
print("✅ تنظیمات بات")
print("✅ روشن / خاموش")
print("✅ اگر بات وجود نداشته باشد → شروع ساخت")
print("✅ توکن → روم → مدیر")
print("✅ بعد از تکمیل → Auto Start")
print("✅ Syntax OK")
print("=" * 60)
