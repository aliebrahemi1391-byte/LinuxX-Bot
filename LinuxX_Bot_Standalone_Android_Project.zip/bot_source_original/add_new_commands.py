from pathlib import Path

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1) اضافه کردن دستورات به ADMIN CHECK
# ---------------------------------------------------------

old = '''            or text.startswith("!اسپم ")
        )'''

new = '''            or text.startswith("!اسپم ")
            or text.startswith("!بیا ")
            or text.startswith("!برو به ")
            or text == "!موجودی"
            or text.startswith("!تیپ ")
        )'''

if old in s and 'or text.startswith("!بیا ")' not in s:
    s = s.replace(old, new, 1)
    print("✅ دستورات جدید به ADMIN CHECK اضافه شد")
else:
    print("ℹ️ ADMIN CHECK قبلاً اصلاح شده یا ساختار متفاوت است")


# ---------------------------------------------------------
# 2) اضافه کردن !بیا و !برو به
# قبل از FIND TARGET
# ---------------------------------------------------------

marker = '''        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):'''

block = '''        # -----------------------------------------------
        # BRING USER TO ADMIN
        # !بیا @id
        # -----------------------------------------------

        if text.startswith("!بیا "):

            target_name = text[len("!بیا "):].strip()

            if not target_name:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح: !بیا @id"
                )
                return

            target = self.find_user(target_name)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            admin_position = self.positions.get(uid)

            if admin_position is None:
                await self.refresh_users()
                admin_position = self.positions.get(uid)

            if admin_position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            try:
                await self.highrise.teleport(
                    str(target.id),
                    admin_position
                )

                await self.highrise.chat(
                    f"<#00FF88>📍 @{target.username} به محل مدیر منتقل شد."
                )

            except Exception as e:
                print("[BRING USER ERROR]", repr(e))

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ انتقال کاربر انجام نشد."
                )

            return


        # -----------------------------------------------
        # MOVE USER TO SAVED LOCATION
        # !برو به @id vip
        # -----------------------------------------------

        if text.startswith("!برو به "):

            parts = text.split(maxsplit=2)

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n"
                    "!برو به @id vip"
                )
                return

            target_name = parts[1].strip()
            location_name = parts[2].strip()

            target = self.find_user(target_name)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            locations = self._load_locations()

            # فقط محل‌های ادمین/ذخیره‌شده
            position_data = locations.get(
                "admin",
                {}
            ).get(location_name)

            if position_data is None:
                # محل عمومی را هم اجازه می‌دهیم
                position_data = locations.get(
                    "public",
                    {}
                ).get(location_name)

            if position_data is None:
                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ محل «{location_name}» پیدا نشد."
                )
                return

            position = self._dict_to_position(
                position_data
            )

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مختصات محل نامعتبر است."
                )
                return

            try:
                await self.highrise.teleport(
                    str(target.id),
                    position
                )

                await self.highrise.chat(
                    f"<#00FF88>📍 @{target.username} "
                    f"به محل «{location_name}» منتقل شد."
                )

            except Exception as e:
                print("[MOVE USER LOCATION ERROR]", repr(e))

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ انتقال کاربر انجام نشد."
                )

            return


        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):'''

if marker in s:
    if 'if text.startswith("!بیا ")' not in s:
        s = s.replace(marker, block, 1)
        print("✅ !بیا و !برو به اضافه شدند")
    else:
        print("ℹ️ !بیا قبلاً وجود دارد")
else:
    print("❌ محل مناسب برای اضافه کردن دستورات پیدا نشد")


# ---------------------------------------------------------
# 3) اضافه کردن به لیست دستورات مدیریتی
# ---------------------------------------------------------

old_help = '''                    "!موجودی\\n"
                    "!تیپ ۱ @id\\n"
                    "!تیپ ۵ @id\\n"
                    "!تیپ همه ۱\\n"
                    "!تیپ همه ۵\\n"'''

new_help = '''                    "!موجودی\\n"
                    "!تیپ ۱ @id\\n"
                    "!تیپ ۵ @id\\n"
                    "!تیپ همه ۱\\n"
                    "!تیپ همه ۵\\n"
                    "!بیا @id\\n"
                    "!برو به @id vip\\n"'''

if old_help in s and '"!بیا @id\\n"' not in s:
    s = s.replace(old_help, new_help, 1)
    print("✅ راهنمای دستورات بروزرسانی شد")


p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ LINUXX NEW COMMANDS INSTALLER")
print("==============================================")
print("✅ !بیا @id")
print("✅ !برو به @id vip")
print("✅ تیپ‌های قبلی دست‌نخورده")
print("✅ سیستم روبیکا/تلگرام دست‌نخورده")
print("==============================================")
