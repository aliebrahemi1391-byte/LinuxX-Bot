from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# =========================================================
# IMPORTS
# =========================================================

# ReplyKeyboard را به import تلگرام اضافه کن
if "ReplyKeyboardMarkup" not in s:
    s = s.replace(
        "from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update",
        "from telegram import ("
        "\n    InlineKeyboardButton,"
        "\n    InlineKeyboardMarkup,"
        "\n    ReplyKeyboardMarkup,"
        "\n    ReplyKeyboardRemove,"
        "\n    Update,"
        "\n)"
    )

# =========================================================
# هر کاربر فقط 1 بات
# =========================================================

s = s.replace(
    "MAX_BOTS_PER_USER = 2",
    "MAX_BOTS_PER_USER = 1"
)

# =========================================================
# Reply keyboard اصلی
# =========================================================

marker = "    # -----------------------------------------------------\n    # KEYBOARDS\n    # -----------------------------------------------------\n"

if marker in s and "def bottom_keyboard" not in s:

    keyboard_code = '''    # -----------------------------------------------------
    # BOTTOM REPLY KEYBOARD
    # -----------------------------------------------------

    def bottom_keyboard(self, bot=None):

        if bot:
            toggle_text = (
                "🔴 خاموش"
                if bot["enabled"]
                else "🟢 روشن"
            )
        else:
            toggle_text = "🟢 روشن"

        return ReplyKeyboardMarkup(
            [
                [
                    "⚙️ تنظیمات بات",
                    toggle_text,
                ]
            ],
            resize_keyboard=True,
            is_persistent=True,
            one_time_keyboard=False,
        )

'''

    s = s.replace(marker, marker + "\n" + keyboard_code)

# =========================================================
# main_keyboard را طوری تغییر بده که دیگر Inline نباشد
# =========================================================

pattern = re.compile(
    r'    def main_keyboard\(self, bots\):.*?'
    r'\n    def keyboard\(self, bot_id\):',
    re.S
)

replacement = '''    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        return self.bottom_keyboard(bot)

    def keyboard(self, bot_id):'''

s, count = pattern.subn(replacement, s, count=1)

if count:
    print("✅ main_keyboard -> ReplyKeyboard شد")

# =========================================================
# keyboard و settings_keyboard قدیمی را نگه می‌داریم
# اما دیگر از آنها برای پنل اصلی استفاده نمی‌شود.
# =========================================================

# =========================================================
# start_command
# =========================================================

start_pattern = re.compile(
    r'    async def start_command\(\n'
    r'.*?'
    r'    # -----------------------------------------------------\n'
    r'    # BUTTONS',
    re.S
)

start_replacement = '''    async def start_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        user_id = update.effective_user.id

        context.user_data.clear()

        if is_blocked(user_id):

            await update.message.reply_text(
                "⛔ دسترسی شما به LinuxX Bot مسدود شده است."
            )

            return

        if not is_authorized(user_id):

            context.user_data["waiting_password"] = True

            await update.message.reply_text(
                "🔐 LinuxX Highrise System\\n\\n"
                "برای ورود به پنل رمز عبور را ارسال کن.\\n"
                "⚠️ فقط ۳ تلاش مجاز است."
            )

            return

        bots = get_user_bots(user_id)
        bot = bots[0] if bots else None

        await update.message.reply_text(
            "🟢 LinuxX Highrise Manager\\n\\n"
            "👑 خوش آمدید\\n"
            "از دکمه‌های پایین صفحه استفاده کن.",
            reply_markup=self.bottom_keyboard(bot),
        )

    # -----------------------------------------------------
    # BUTTONS'''

s, count = start_pattern.subn(start_replacement, s, count=1)

if count:
    print("✅ start_command اصلاح شد")

# =========================================================
# callback button قدیمی را عملاً غیرفعال کن
# =========================================================

button_pattern = re.compile(
    r'    async def button\(\n'
    r'.*?'
    r'    # -----------------------------------------------------\n'
    r'    # TEXT INPUT',
    re.S
)

button_replacement = '''    async def button(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):
        # Inline buttons در نسخه جدید استفاده نمی‌شوند.
        # پنل اصلی کاملاً ReplyKeyboard است.
        return

    # -----------------------------------------------------
    # TEXT INPUT'''

s, count = button_pattern.subn(button_replacement, s, count=1)

if count:
    print("✅ Inline callback panel غیرفعال شد")

# =========================================================
# TEXT HANDLER
# =========================================================

# قسمت password موفق را اصلاح کن
old = '''                await update.message.reply_text(
                    "✅ رمز صحیح است.\\n\\n"
                    "🟢 دسترسی به پنل فعال شد.",
                    reply_markup=self.main_keyboard(bots),
                )'''

new = '''                bot = bots[0] if bots else None

                await update.message.reply_text(
                    "✅ رمز صحیح است.\\n\\n"
                    "🟢 دسترسی به پنل فعال شد.",
                    reply_markup=self.bottom_keyboard(bot),
                )'''

s = s.replace(old, new)

# =========================================================
# قبل از بخش EDIT EXISTING BOT، منطق دو دکمه را اضافه کن
# =========================================================

text_marker = '''        # -----------------------------------------------
        # EDIT EXISTING BOT
        # -----------------------------------------------
'''

reply_logic = '''        # =================================================
        # MAIN BOTTOM BUTTONS
        # =================================================

        bots = get_user_bots(user_id)
        bot = bots[0] if bots else None

        # -----------------------------------------------
        # SETTINGS BUTTON
        # -----------------------------------------------

        if text == "⚙️ تنظیمات بات":

            if not bot:

                context.user_data.clear()
                context.user_data["setup"] = "token"

                await update.message.reply_text(
                    "⚙️ تنظیمات بات\\n\\n"
                    "🔑 مرحله ۱ از ۳\\n"
                    "توکن Highrise را ارسال کن:"
                )

                return

            context.user_data.clear()

            await update.message.reply_text(
                "⚙️ تنظیمات بات\\n\\n"
                f"🤖 بات #{bot['id']}\\n"
                f"🌐 Room: {bot['room_id']}\\n"
                f"👤 مدیر: @{bot['owner_username']}\\n\\n"
                "برای تغییر تنظیمات، گزینه موردنظر را ارسال کن:\\n\\n"
                "🔑 تغییر توکن\\n"
                "🌐 تغییر لینک روم\\n"
                "👤 تغییر ID مدیر",
                reply_markup=self.bottom_keyboard(bot),
            )

            return

        # -----------------------------------------------
        # TOGGLE BUTTON
        # -----------------------------------------------

        if text in ("🟢 روشن", "🔴 خاموش"):

            if not bot:

                await update.message.reply_text(
                    "⚠️ این بات هنوز تنظیم نشده است.\\n\\n"
                    "ابتدا روی «⚙️ تنظیمات بات» بزن و "
                    "توکن، روم و ID مدیر را وارد کن.",
                    reply_markup=self.bottom_keyboard(None),
                )

                return

            # روشن کردن
            if not bool(bot["enabled"]):

                set_enabled(bot["id"], True)

                fresh = get_bot(bot["id"])

                self.spawn(fresh)

                await update.message.reply_text(
                    "🟢 بات با موفقیت روشن شد.",
                    reply_markup=self.bottom_keyboard(fresh),
                )

                return

            # خاموش کردن
            else:

                set_enabled(bot["id"], False)

                self.stop(bot["id"])

                fresh = get_bot(bot["id"])

                await update.message.reply_text(
                    "🔴 بات خاموش شد.",
                    reply_markup=self.bottom_keyboard(fresh),
                )

                return

        # -----------------------------------------------
        # SETTINGS OPTIONS
        # -----------------------------------------------

        if text == "🔑 تغییر توکن":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "token"

            await update.message.reply_text(
                "🔑 توکن جدید Highrise را ارسال کن:",
                reply_markup=self.bottom_keyboard(bot),
            )

            return

        if text == "🌐 تغییر لینک روم":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "room"

            await update.message.reply_text(
                "🌐 لینک یا ID روم جدید را ارسال کن:",
                reply_markup=self.bottom_keyboard(bot),
            )

            return

        if text == "👤 تغییر ID مدیر":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "manager"

            await update.message.reply_text(
                "👤 ID مدیر جدید را ارسال کن:",
                reply_markup=self.bottom_keyboard(bot),
            )

            return

'''

if text_marker in s:
    s = s.replace(text_marker, reply_logic + text_marker, 1)
    print("✅ منطق دو دکمه اصلی اضافه شد")

# =========================================================
# setup manager completion
# =========================================================

# هر جا بعد از ثبت بات main_keyboard استفاده شده
# به ReplyKeyboard تبدیل می‌کنیم.

s = s.replace(
    "reply_markup=self.main_keyboard([row])",
    "reply_markup=self.bottom_keyboard(row)"
)

s = s.replace(
    "reply_markup=self.main_keyboard([fresh])",
    "reply_markup=self.bottom_keyboard(fresh)"
)

s = s.replace(
    "reply_markup=self.main_keyboard(bots)",
    "reply_markup=self.bottom_keyboard(bots[0] if bots else None)"
)

s = s.replace(
    "reply_markup=self.main_keyboard([])",
    "reply_markup=self.bottom_keyboard(None)"
)

# =========================================================
# تمام reply_markup های main_keyboard
# =========================================================

# =========================================================
# ذخیره
# =========================================================

p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ LinuxX REPLY UI FINAL PATCH")
print("==============================================")
print("✅ بعد از رمز فقط ۲ دکمه پایین صفحه")
print("✅ هیچ InlineKeyboard برای پنل اصلی")
print("✅ تنظیمات بات")
print("✅ روشن / خاموش")
print("✅ هر اکانت فقط ۱ بات")
print("✅ قبل از تنظیمات اجازه روشن کردن نمی‌دهد")
print("✅ دکمه روشن هنگام خاموش بودن")
print("✅ دکمه خاموش هنگام روشن بودن")
print("==============================================")
