import os
import re
import sys
import json
import sqlite3
import asyncio
import random
import subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from highrise import BaseBot, Position

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from dance_data import DANCES


BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "bots.db"

MAX_BOTS = 50
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

PV_MESSAGE = "Power taken from @84.42"

WELCOME_MESSAGE = (
    "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
    "<#FFD700>🤖 LinuxX Bot\n"
    "<#00CCFF>به روم خوش آمدید 🌹\n"
    "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
)

BOT_START_MESSAGE = (
    "<#00CCFF>🤖 بات روشن شد\n"
    "<#FFD700>LinuxX Bot"
)

BOT_STOP_MESSAGE = (
    "<#FF5555>🔴 بات خاموش شد\n"
    "<#FFD700>LinuxX Bot"
)


# ---------------------------------------------------------
# DATABASE
# ---------------------------------------------------------

def db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS bots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_user_id INTEGER NOT NULL,
            token TEXT NOT NULL,
            room_id TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            bot_id INTEGER NOT NULL,
            user_id TEXT NOT NULL,
            username TEXT,
            PRIMARY KEY (bot_id, user_id)
        )
    """)

    conn.commit()
    conn.close()


def get_user_bots(tg_user_id):
    conn = db()
    rows = conn.execute(
        "SELECT * FROM bots WHERE telegram_user_id=? ORDER BY id",
        (tg_user_id,),
    ).fetchall()
    conn.close()
    return rows


def get_bot(bot_id):
    conn = db()
    row = conn.execute(
        "SELECT * FROM bots WHERE id=?",
        (bot_id,),
    ).fetchone()
    conn.close()
    return row


def create_or_update_bot(tg_user_id, token, room_id, owner_username):
    conn = db()

    row = conn.execute(
        "SELECT id FROM bots WHERE telegram_user_id=? LIMIT 1",
        (tg_user_id,),
    ).fetchone()

    if row:
        conn.execute("""
            UPDATE bots
            SET token=?,
                room_id=?,
                owner_username=?,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (
            token,
            room_id,
            owner_username,
            row["id"],
        ))
        bot_id = row["id"]
    else:
        count = conn.execute(
            "SELECT COUNT(*) AS c FROM bots"
        ).fetchone()["c"]

        if count >= MAX_BOTS:
            conn.close()
            raise RuntimeError("ظرفیت ۵۰ بات پر شده است.")

        cur = conn.execute("""
            INSERT INTO bots
            (telegram_user_id, token, room_id, owner_username, enabled)
            VALUES (?, ?, ?, ?, 0)
        """, (
            tg_user_id,
            token,
            room_id,
            owner_username,
        ))

        bot_id = cur.lastrowid

    conn.commit()
    conn.close()

    return bot_id


def set_enabled(bot_id, enabled):
    conn = db()
    conn.execute(
        "UPDATE bots SET enabled=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (1 if enabled else 0, bot_id),
    )
    conn.commit()
    conn.close()


def get_enabled_bots():
    conn = db()
    rows = conn.execute(
        "SELECT * FROM bots WHERE enabled=1 ORDER BY id"
    ).fetchall()
    conn.close()
    return rows


def add_admin(bot_id, user_id, username):
    conn = db()
    conn.execute("""
        INSERT OR REPLACE INTO admins(bot_id, user_id, username)
        VALUES (?, ?, ?)
    """, (
        bot_id,
        user_id,
        username,
    ))
    conn.commit()
    conn.close()


def remove_admin(bot_id, user_id):
    conn = db()
    conn.execute(
        "DELETE FROM admins WHERE bot_id=? AND user_id=?",
        (bot_id, user_id),
    )
    conn.commit()
    conn.close()


def get_admin_ids(bot_id):
    conn = db()
    rows = conn.execute(
        "SELECT user_id FROM admins WHERE bot_id=?",
        (bot_id,),
    ).fetchall()
    conn.close()
    return {r["user_id"] for r in rows}


# ---------------------------------------------------------
# ROOM LINK
# ---------------------------------------------------------

def parse_room_id(value):
    value = value.strip()

    if not value:
        return ""

    # مستقیم room id
    if re.fullmatch(r"[A-Za-z0-9]+", value):
        return value

    try:
        parsed = urlparse(value)
        query = parse_qs(parsed.query)

        if "ownedRoomId" in query:
            return query["ownedRoomId"][0]

        if "id" in query:
            return query["id"][0]

        # fallback
        parts = parsed.path.strip("/").split("/")
        if parts:
            return parts[-1]

    except Exception:
        pass

    return value


# ---------------------------------------------------------
# HIGHRISE BOT
# ---------------------------------------------------------

class HighriseBot(BaseBot):

    def __init__(self):
        super().__init__()

        self.bot_id = os.getenv("LINUXX_BOT_ID", "")
        self.owner_username = os.getenv(
            "LINUXX_OWNER_USERNAME",
            "",
        ).strip().lstrip("@")

        self.admin_ids = set()

        self.users = {}
        self.positions = {}

        self.frozen = {}
        self.muted = set()

        self.movement_task = None
        self.floss_task = None

        self.running = True

    # -----------------------------------------------------
    # DATABASE / ADMINS
    # -----------------------------------------------------

    def load_admins(self):
        if not self.bot_id:
            return

        self.admin_ids = get_admin_ids(int(self.bot_id))

    def is_admin(self, user_id):
        if str(user_id) in self.admin_ids:
            return True

        # مالک بات همیشه مدیر اصلی است.
        user = self.users.get(str(user_id))

        if user:
            return (
                user.username.lower().lstrip("@")
                == self.owner_username.lower()
            )

        return False

    # -----------------------------------------------------
    # USER CACHE
    # -----------------------------------------------------

    async def refresh_users(self):
        try:
            response = await self.highrise.get_room_users()

            content = getattr(response, "content", None)

            if not content:
                return

            for item in content:
                try:
                    user = item[0]
                    position = item[1]

                    self.users[str(user.id)] = user

                    if position is not None:
                        self.positions[str(user.id)] = position

                except Exception:
                    continue

            print(
                f"[USERS] loaded {len(self.users)} users"
            )

        except Exception as e:
            print("[USERS ERROR]", e)

    def find_user(self, text):
        text = text.strip()

        if text.startswith("@"):
            text = text[1:]

        # ID مستقیم
        for uid, user in self.users.items():
            if uid == text:
                return user

        # username
        for user in self.users.values():
            if user.username.lower() == text.lower():
                return user

        return None

    # -----------------------------------------------------
    # START
    # -----------------------------------------------------

    async def on_start(self, session_metadata):
        print("[HIGHRISE] connected")

        self.load_admins()

        # مهم:
        # کاربران موجود قبل از ورود بات را هم می‌خوانیم.
        await self.refresh_users()

        try:
            await self.highrise.chat(BOT_START_MESSAGE)
        except Exception:
            pass

        # Floss loop
        if self.floss_task is None:
            self.floss_task = asyncio.create_task(
                self.floss_loop()
            )

    # -----------------------------------------------------
    # USER JOIN
    # -----------------------------------------------------

    async def on_user_join(self, user, position):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = position

        print(
            f"[JOIN] @{user.username} [{uid}]"
        )

        try:
            await self.highrise.chat(
                f"<#00CCFF>👋 خوش آمدی @{user.username}"
            )
        except Exception:
            pass

    # -----------------------------------------------------
    # USER LEAVE
    # -----------------------------------------------------

    async def on_user_leave(self, user):
        uid = str(user.id)

        self.users.pop(uid, None)
        self.positions.pop(uid, None)

        # frozen را پاک نمی‌کنیم تا اگر دوباره برگشت
        # بتوانیم دوباره کنترلش کنیم.

    # -----------------------------------------------------
    # USER MOVE / FREEZE
    # -----------------------------------------------------

    async def on_user_move(self, user, destination):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = destination

        if uid in self.frozen:
            old_position = self.frozen[uid]

            try:
                await self.highrise.teleport(
                    uid,
                    old_position,
                )
            except Exception as e:
                print("[FREEZE ERROR]", e)

    # -----------------------------------------------------
    # CHAT
    # -----------------------------------------------------

    async def on_chat(self, user, message):
        uid = str(user.id)

        self.users[uid] = user

        text = message.strip()

        if not text:
            return

        print(
            f"[CHAT] @{user.username}: {text}"
        )

        # -----------------------------------------------
        # DANCE
        # -----------------------------------------------

        normalized = text.translate(
            str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789",
            )
        )

        if normalized.isdigit():

            number = int(normalized)

            if 1 <= number <= 250:

                emote_id = DANCES.get(
                    str(number)
                )

                if emote_id:

                    try:
                        await self.highrise.send_emote(
                            emote_id,
                            uid,
                        )
                    except Exception as e:
                        print(
                            "[DANCE ERROR]",
                            e,
                        )

                    return

        # -----------------------------------------------
        # TASE
        # -----------------------------------------------

        if text == "!تاس":
            number = random.randint(1, 6)

            await self.highrise.chat(
                f"<#FFD700>🎲 نتیجه تاس: {number}"
            )

            return

        # -----------------------------------------------
        # COMMANDS
        # -----------------------------------------------

        if text == "!دستورات":

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
                "<#FFD700>📖 دستورات عمومی\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\n"
                "<#FFFFFF>!تاس\n"
                "<#FFFFFF>!دستورات\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            if self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "دستورات مدیریتی:\n"
                    "!لباس\n"
                    "!کیک @id\n"
                    "!فریز @id\n"
                    "!انفریز @id\n"
                    "!ادمین @id\n"
                    "!حذف ادمین @id\n"
                    "!موت @id\n"
                    "!انموت @id\n"
                    "!حرکت\n"
                    "!حرکت توقف",
                )

            return

        # -----------------------------------------------
        # ADMIN CHECK
        # -----------------------------------------------

        admin_commands = (
            text.startswith("!لباس")
            or text.startswith("!کیک")
            or text.startswith("!فریز")
            or text.startswith("!انفریز")
            or text.startswith("!ادمین")
            or text.startswith("!حذف ادمین")
            or text.startswith("!موت")
            or text.startswith("!انموت")
            or text == "!حرکت"
            or text == "!حرکت توقف"
        )

        if admin_commands and not self.is_admin(uid):
            await self.highrise.send_whisper(
                uid,
                "<#FF5555>❌ شما مدیر بات نیستید."
            )
            return

        # -----------------------------------------------
        # OUTFIT
        # -----------------------------------------------

        if text == "!لباس":

            try:
                outfit_response = (
                    await self.highrise.get_user_outfit(
                        uid
                    )
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if outfit:
                    result = await self.highrise.set_outfit(
                        list(outfit)
                    )

                    if result is not None:
                        print(
                            "[OUTFIT RESULT]",
                            result,
                        )

                    await self.highrise.chat(
                        "<#00FF88>👕 لباس با موفقیت کپی شد."
                    )

                else:
                    await self.highrise.send_whisper(
                        uid,
                        "لباس کاربر پیدا نشد."
                    )

            except Exception as e:
                print("[OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"خطا در کپی لباس: {e}"
                )

            return

        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):
            parts = command.split(maxsplit=1)

            if len(parts) < 2:
                return None

            return self.find_user(parts[1])

        # -----------------------------------------------
        # KICK
        # -----------------------------------------------

        if text.startswith("!کیک "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "kick",
                )

                await self.highrise.chat(
                    f"<#FF5555>👢 @{target.username} کیک شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # FREEZE
        # -----------------------------------------------

        if text.startswith("!فریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            position = self.positions.get(
                target_id
            )

            if position is None:
                await self.refresh_users()
                position = self.positions.get(
                    target_id
                )

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ موقعیت کاربر پیدا نشد."
                )
                return

            self.frozen[target_id] = position

            await self.highrise.chat(
                f"<#00CCFF>🧊 @{target.username} فریز شد."
            )

            return

        # -----------------------------------------------
        # UNFREEZE
        # -----------------------------------------------

        if text.startswith("!انفریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            self.frozen.pop(
                str(target.id),
                None,
            )

            await self.highrise.chat(
                f"<#00FF88>🔓 @{target.username} انفریز شد."
            )

            return

        # -----------------------------------------------
        # MUTE
        # -----------------------------------------------

        if text.startswith("!موت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "mute",
                )

                self.muted.add(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#FFAA00>🔇 @{target.username} موت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # UNMUTE
        # -----------------------------------------------

        if text.startswith("!انموت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "unmute",
                )

                self.muted.discard(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#00FF88>🔊 @{target.username} انموت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # ADD ADMIN
        # -----------------------------------------------

        if text.startswith("!ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            add_admin(
                int(self.bot_id),
                target_id,
                target.username,
            )

            self.admin_ids.add(
                target_id
            )

            await self.highrise.chat(
                f"<#FFD700>👑 @{target.username} مدیر شد."
            )

            return

        # -----------------------------------------------
        # REMOVE ADMIN
        # -----------------------------------------------

        if text.startswith("!حذف ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            remove_admin(
                int(self.bot_id),
                target_id,
            )

            self.admin_ids.discard(
                target_id
            )

            await self.highrise.chat(
                f"<#FF5555>❌ @{target.username} از مدیریت حذف شد."
            )

            return

        # -----------------------------------------------
        # MOVEMENT
        # -----------------------------------------------

        if text == "!حرکت":

            if self.movement_task:
                await self.highrise.send_whisper(
                    uid,
                    "بات در حال حرکت است."
                )
                return

            self.movement_task = asyncio.create_task(
                self.random_walk()
            )

            await self.highrise.chat(
                "<#00FF88>🚶 حرکت بات شروع شد."
            )

            return

        if text == "!حرکت توقف":

            if self.movement_task:
                self.movement_task.cancel()
                self.movement_task = None

            await self.highrise.chat(
                "<#FFD700>🛑 حرکت بات متوقف شد."
            )

            return

    # -----------------------------------------------------
    # RANDOM WALK
    # -----------------------------------------------------

    async def random_walk(self):

        # چند نقطه نمونه برای حرکت.
        # بعداً می‌توانیم نقاط مخصوص هر روم را از پنل تنظیم کنیم.
        points = [
            Position(0, 0, 0, "FrontRight"),
            Position(2, 0, 2, "FrontRight"),
            Position(-2, 0, 2, "FrontLeft"),
            Position(2, 0, -2, "BackRight"),
            Position(-2, 0, -2, "BackLeft"),
        ]

        try:
            while True:

                destination = random.choice(
                    points
                )

                try:
                    await self.highrise.walk_to(
                        destination
                    )
                except Exception as e:
                    print(
                        "[WALK ERROR]",
                        e
                    )

                await asyncio.sleep(
                    random.uniform(
                        3,
                        7,
                    )
                )

        except asyncio.CancelledError:
            return

    # -----------------------------------------------------
    # FLOSS LOOP
    # -----------------------------------------------------

    async def floss_loop(self):

        while self.running:

            try:
                await self.highrise.send_emote(
                    DANCES["222"]
                )
            except Exception as e:
                print(
                    "[FLOSS ERROR]",
                    e
                )

            await asyncio.sleep(8)

    # -----------------------------------------------------
    # PRIVATE MESSAGE
    # -----------------------------------------------------

    async def on_message(
        self,
        user_id,
        conversation_id,
        is_new_conversation,
    ):

        try:
            await self.highrise.send_message(
                conversation_id,
                PV_MESSAGE,
            )
        except Exception as e:
            print(
                "[PV ERROR]",
                e
            )


# ---------------------------------------------------------
# TELEGRAM MANAGER
# ---------------------------------------------------------

class TelegramManager:

    def __init__(self):
        self.processes = {}

    def keyboard(self, bot_id):

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🟢 روشن / 🔴 خاموش",
                    callback_data=f"toggle:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "⚙️ تنظیمات",
                    callback_data=f"settings:{bot_id}",
                )
            ],
        ])

    def settings_keyboard(self, bot_id):

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🔑 تغییر توکن",
                    callback_data=f"token:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🌐 تغییر لینک روم",
                    callback_data=f"room:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "👤 تغییر نام کاربری مالک",
                    callback_data=f"owner:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🔙 بازگشت",
                    callback_data=f"back:{bot_id}",
                )
            ],
        ])

    async def start(self):

        if not TELEGRAM_TOKEN:
            print(
                "ERROR: TELEGRAM_BOT_TOKEN is not set."
            )
            print(
                "Example:"
            )
            print(
                'export TELEGRAM_BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"'
            )
            return

        init_db()

        application = (
            Application.builder()
            .token(TELEGRAM_TOKEN)
            .build()
        )

        application.add_handler(
            CommandHandler(
                "start",
                self.start_command,
            )
        )

        application.add_handler(
            CallbackQueryHandler(
                self.button,
            )
        )

        application.add_handler(
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                self.text_handler,
            )
        )

        # بات‌هایی که قبل از خاموش شدن فعال بودند
        # دوباره اجرا می‌شوند.
        for row in get_enabled_bots():
            self.spawn(row)

        print(
            "[TELEGRAM] manager started"
        )

        await application.initialize()
        await application.start()
        await application.updater.start_polling()

        try:
            while True:
                await asyncio.sleep(3600)
        finally:
            await application.updater.stop()
            await application.stop()
            await application.shutdown()

    async def start_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        user_id = update.effective_user.id

        bots = get_user_bots(user_id)

        if not bots:

            await update.message.reply_text(
                "🤖 هنوز باتی برای شما ثبت نشده.\n\n"
                "اول اطلاعات بات را به صورت زیر ارسال کنید:\n\n"
                "توکن Highrise\n"
                "سپس لینک روم\n"
                "سپس نام کاربری مالک"
            )

            context.user_data["setup"] = "token"

            return

        row = bots[0]

        await update.message.reply_text(
            "پنل مدیریت بات:",
            reply_markup=self.keyboard(
                row["id"]
            ),
        )

    # -----------------------------------------------------
    # BUTTONS
    # -----------------------------------------------------

    async def button(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        query = update.callback_query

        await query.answer()

        data = query.data

        action, bot_id = data.split(
            ":",
            1,
        )

        bot_id = int(bot_id)

        row = get_bot(bot_id)

        if not row:
            await query.edit_message_text(
                "بات پیدا نشد."
            )
            return

        if row["telegram_user_id"] != update.effective_user.id:
            await query.answer(
                "این بات متعلق به شما نیست.",
                show_alert=True,
            )
            return

        if action == "toggle":

            new_state = not bool(
                row["enabled"]
            )

            set_enabled(
                bot_id,
                new_state,
            )

            if new_state:
                row = get_bot(bot_id)
                self.spawn(row)
            else:
                self.stop(bot_id)

            status = (
                "🟢 روشن"
                if new_state
                else "🔴 خاموش"
            )

            await query.edit_message_text(
                f"وضعیت: {status}",
                reply_markup=self.keyboard(
                    bot_id
                ),
            )

            return

        if action == "settings":

            await query.edit_message_text(
                "⚙️ تنظیمات بات:",
                reply_markup=self.settings_keyboard(
                    bot_id
                ),
            )

            return

        if action == "back":

            await query.edit_message_text(
                "پنل مدیریت بات:",
                reply_markup=self.keyboard(
                    bot_id
                ),
            )

            return

        if action in (
            "token",
            "room",
            "owner",
        ):

            context.user_data[
                "edit_bot"
            ] = bot_id

            context.user_data[
                "edit_type"
            ] = action

            labels = {
                "token": "توکن جدید Highrise را بفرست:",
                "room": "لینک روم جدید را بفرست:",
                "owner": "نام کاربری مالک جدید را بفرست:",
            }

            await query.edit_message_text(
                labels[action]
            )

            return

    # -----------------------------------------------------
    # TEXT INPUT
    # -----------------------------------------------------

    async def text_handler(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        text = (
            update.message.text.strip()
        )

        user_id = update.effective_user.id

        # -----------------------------------------------
        # EDIT EXISTING BOT
        # -----------------------------------------------

        edit_bot = context.user_data.get(
            "edit_bot"
        )

        edit_type = context.user_data.get(
            "edit_type"
        )

        if edit_bot and edit_type:

            row = get_bot(edit_bot)

            if not row:
                context.user_data.clear()
                return

            if row["telegram_user_id"] != user_id:
                context.user_data.clear()
                return

            conn = db()

            if edit_type == "token":

                conn.execute(
                    "UPDATE bots SET token=? WHERE id=?",
                    (text, edit_bot),
                )

            elif edit_type == "room":

                room_id = parse_room_id(text)

                conn.execute(
                    "UPDATE bots SET room_id=? WHERE id=?",
                    (room_id, edit_bot),
                )

            elif edit_type == "owner":

                owner = text.lstrip("@").strip()

                conn.execute(
                    "UPDATE bots SET owner_username=? WHERE id=?",
                    (owner, edit_bot),
                )

            conn.commit()
            conn.close()

            context.user_data.clear()

            await update.message.reply_text(
                "✅ تنظیمات ذخیره شد.",
                reply_markup=self.keyboard(
                    edit_bot
                ),
            )

            return

        # -----------------------------------------------
        # NEW BOT SETUP
        # -----------------------------------------------

        setup = context.user_data.get(
            "setup"
        )

        if setup == "token":

            context.user_data[
                "new_token"
            ] = text

            context.user_data[
                "setup"
            ] = "room"

            await update.message.reply_text(
                "🌐 حالا لینک روم Highrise را بفرست:"
            )

            return

        if setup == "room":

            room_id = parse_room_id(text)

            if not room_id:
                await update.message.reply_text(
                    "❌ لینک/کد روم نامعتبر است."
                )
                return

            context.user_data[
                "new_room"
            ] = room_id

            context.user_data[
                "setup"
            ] = "owner"

            await update.message.reply_text(
                "👤 حالا نام کاربری مالک بات در Highrise را بفرست:"
            )

            return

        if setup == "owner":

            owner = text.lstrip("@").strip()

            token = context.user_data.get(
                "new_token"
            )

            room_id = context.user_data.get(
                "new_room"
            )

            try:

                bot_id = create_or_update_bot(
                    user_id,
                    token,
                    room_id,
                    owner,
                )

            except Exception as e:

                await update.message.reply_text(
                    f"❌ خطا: {e}"
                )

                context.user_data.clear()
                return

            context.user_data.clear()

            await update.message.reply_text(
                "✅ بات ثبت شد.\n"
                "از دکمه زیر می‌توانی آن را روشن کنی:",
                reply_markup=self.keyboard(
                    bot_id
                ),
            )

            return

    # -----------------------------------------------------
    # PROCESS MANAGEMENT
    # -----------------------------------------------------

    def spawn(self, row):

        bot_id = int(row["id"])

        if bot_id in self.processes:

            process = self.processes[
                bot_id
            ]

            if process.poll() is None:
                return

        env = os.environ.copy()

        env[
            "LINUXX_BOT_ID"
        ] = str(bot_id)

        env[
            "LINUXX_OWNER_USERNAME"
        ] = row["owner_username"]

        env[
            "HIGHRISE_WORKER"
        ] = "1"

        python = sys.executable

        cmd = [
            python,
            "-m",
            "highrise",
            "main:HighriseBot",
            row["room_id"],
            row["token"],
        ]

        print(
            "[START BOT]",
            bot_id,
        )

        try:

            process = subprocess.Popen(
                cmd,
                cwd=str(BASE_DIR),
                env=env,
            )

            self.processes[
                bot_id
            ] = process

        except Exception as e:

            print(
                "[START ERROR]",
                e,
            )

    def stop(self, bot_id):

        process = self.processes.get(
            bot_id
        )

        if not process:
            return

        if process.poll() is None:

            try:
                process.terminate()

                try:
                    process.wait(
                        timeout=5
                    )
                except subprocess.TimeoutExpired:
                    process.kill()

            except Exception as e:

                print(
                    "[STOP ERROR]",
                    e,
                )

        self.processes.pop(
            bot_id,
            None,
        )


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

def run_worker():

    # این تابع فقط برای وضوح ساختاری است.
    # highrise CLI خودش HighriseBot را اجرا می‌کند.
    pass


async def run_telegram():

    manager = TelegramManager()
    await manager.start()


if __name__ == "__main__":

    init_db()

    # وقتی highrise CLI این فایل را import می‌کند،
    # نباید پنل تلگرام دوم ساخته شود.
    if os.getenv("HIGHRISE_WORKER") == "1":
        pass

    else:
        asyncio.run(
            run_telegram()
        )
