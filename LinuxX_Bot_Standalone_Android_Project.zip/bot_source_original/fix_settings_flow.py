from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# ---------------------------------------------------------
# تنظیمات: اگر بات وجود ندارد، شروع ساخت بات
# ---------------------------------------------------------

old = '''        # تنظیمات
        if text == "⚙️ تنظیمات بات ۱":

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است.",
                    reply_markup=self.main_keyboard(bots),
                )
                return
'''

new = '''        # تنظیمات
        if text == "⚙️ تنظیمات بات":

            # اگر هنوز باتی ساخته نشده، تنظیمات اولیه را شروع کن
            if not bot:

                context.user_data.clear()
                context.user_data["setup"] = "token"

                await update.message.reply_text(
                    "⚙️ تنظیمات بات ۱\\n\\n"
                    "🔐 برای راه‌اندازی بات، اطلاعات زیر را به ترتیب ارسال کن.\\n\\n"
                    "🔑 مرحله ۱ از ۳\\n"
                    "توکن Highrise را ارسال کن:"
                )

                return
'''

if old in s:
    s = s.replace(old, new, 1)
    print("✅ مسیر تنظیمات اولیه اصلاح شد")
else:
    # نسخه‌های مختلف متن را پیدا کن
    pattern = r'        # تنظیمات\\s+if text == "⚙️ تنظیمات بات ۱":.*?            return\\n'
    m = re.search(pattern, s, re.DOTALL)

    if not m:
        print("❌ بخش تنظیمات پیدا نشد")
        raise SystemExit(1)

    s = s[:m.start()] + new + s[m.end():]
    print("✅ بخش تنظیمات با الگوی جایگزین اصلاح شد")

# ---------------------------------------------------------
# دکمه روشن: قبل از ساخت بات اجازه روشن شدن نده
# ---------------------------------------------------------

old_toggle = '''        # روشن / خاموش
        if text in ("🟢 روشن بات ۱", "🔴 خاموش بات ۱"):

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز باتی ساخته نشده است.",
                    reply_markup=self.main_keyboard(bots),
                )
                return
'''

new_toggle = '''        # روشن / خاموش
        if text in (
            "🟢 روشن",
            "🔴 خاموش",
            "🟢 روشن بات ۱",
            "🔴 خاموش بات ۱",
        ):

            if not bot:

                await update.message.reply_text(
                    "❌ بات هنوز تنظیم نشده است.\\n\\n"
                    "⚙️ ابتدا روی «تنظیمات بات» بزن و "
                    "توکن، روم و ID مدیر را وارد کن."
                )

                return
'''

if old_toggle in s:
    s = s.replace(old_toggle, new_toggle, 1)
    print("✅ منطق روشن/خاموش اصلاح شد")
else:
    print("⚠️ بخش روشن/خاموش دقیقاً پیدا نشد؛ تغییری در آن ندادم")

p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ LINUXX SETTINGS FLOW FIX")
print("==============================================")
print("✅ تنظیمات بدون بات → شروع ساخت بات")
print("✅ مرحله توکن")
print("✅ مرحله روم")
print("✅ مرحله ID مدیر")
print("✅ روشن کردن بدون تنظیمات ممنوع")
print("✅ دکمه‌ها پایین صفحه باقی می‌مانند")
print("==============================================")
