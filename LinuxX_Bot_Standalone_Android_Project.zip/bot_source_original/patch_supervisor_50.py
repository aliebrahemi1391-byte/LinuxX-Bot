from pathlib import Path

p = Path("main.py")
s = p.read_text(encoding="utf-8")

old = '''    def spawn(self, row):

        bot_id = int(row["id"])

        process = self.processes.get(bot_id)

        if process:

            if process.poll() is None:
                print(
                    "[ALREADY RUNNING]",
                    bot_id,
                )
                return

        env = os.environ.copy()

        env["LINUXX_BOT_ID"] = str(bot_id)

        env["LINUXX_OWNER_USERNAME"] = (
            row["owner_username"]
        )

        env["HIGHRISE_WORKER"] = "1"

        python = sys.executable

        cmd = [
            python,
            "-m",
            "highrise",
            "main:HighriseBot",
            row["room_id"],
            row["token"],
        ]

        print(
            "[START BOT]",
            bot_id,
        )

        try:

            process = subprocess.Popen(
                cmd,
                cwd=str(BASE_DIR),
                env=env,
            )

            self.processes[bot_id] = process

        except Exception as e:

            print(
                "[START ERROR]",
                bot_id,
                e,
            )
'''

new = '''    def spawn(self, row):

        bot_id = int(row["id"])

        process = self.processes.get(bot_id)

        if process and process.poll() is None:
            print("[ALREADY RUNNING]", bot_id)
            return

        env = os.environ.copy()

        env["LINUXX_BOT_ID"] = str(bot_id)

        env["LINUXX_OWNER_USERNAME"] = (
            row["owner_username"]
        )

        env["HIGHRISE_WORKER"] = "1"

        python = sys.executable

        cmd = [
            python,
            "-m",
            "highrise",
            "main:HighriseBot",
            row["room_id"],
            row["token"],
        ]

        print("[START BOT]", bot_id)

        try:

            process = subprocess.Popen(
                cmd,
                cwd=str(BASE_DIR),
                env=env,
                stdout=None,
                stderr=None,
            )

            self.processes[bot_id] = process

            print(
                "[BOT PROCESS STARTED]",
                bot_id,
                "PID=",
                process.pid,
            )

        except Exception as e:

            print(
                "[START ERROR]",
                bot_id,
                repr(e),
            )


    async def monitor_processes(self):

        print("[SUPERVISOR] started")

        restart_delay = {}

        while True:

            try:

                enabled_rows = get_enabled_bots()

                enabled_ids = {
                    int(row["id"])
                    for row in enabled_rows
                }

                # -----------------------------------------
                # بررسی بات‌های فعال
                # -----------------------------------------

                for row in enabled_rows:

                    bot_id = int(row["id"])

                    process = self.processes.get(bot_id)

                    # هنوز process ساخته نشده
                    if process is None:

                        delay = restart_delay.get(
                            bot_id,
                            0
                        )

                        if delay > 0:

                            restart_delay[bot_id] = max(
                                0,
                                delay - 2
                            )

                            continue

                        print(
                            "[SUPERVISOR] starting missing bot",
                            bot_id,
                        )

                        self.spawn(row)

                        restart_delay[bot_id] = 5

                        continue

                    # process هنوز زنده است
                    if process.poll() is None:

                        restart_delay[bot_id] = 0

                        continue

                    # process مرده
                    exit_code = process.returncode

                    print(
                        "[SUPERVISOR] bot stopped",
                        bot_id,
                        "exit=",
                        exit_code,
                    )

                    self.processes.pop(
                        bot_id,
                        None,
                    )

                    delay = restart_delay.get(
                        bot_id,
                        5
                    )

                    print(
                        "[SUPERVISOR] restarting bot",
                        bot_id,
                        "in",
                        delay,
                        "seconds",
                    )

                    restart_delay[bot_id] = min(
                        max(delay * 2, 5),
                        60
                    )

                # -----------------------------------------
                # پاک کردن processهای غیرفعال
                # -----------------------------------------

                for bot_id in list(
                    self.processes.keys()
                ):

                    if bot_id not in enabled_ids:

                        process = self.processes.get(
                            bot_id
                        )

                        if process:

                            if process.poll() is None:

                                print(
                                    "[SUPERVISOR] bot disabled",
                                    bot_id,
                                )

                                try:
                                    process.terminate()
                                except Exception:
                                    pass

                        self.processes.pop(
                            bot_id,
                            None,
                        )

                        restart_delay.pop(
                            bot_id,
                            None,
                        )

            except Exception as e:

                print(
                    "[SUPERVISOR ERROR]",
                    repr(e),
                )

            # مهم:
            # خطای یک بات نباید supervisor را متوقف کند.
            await asyncio.sleep(2)
'''

if old not in s:
    raise SystemExit(
        "❌ بخش spawn در main.py پیدا نشد؛ هیچ تغییری انجام نشد."
    )

s = s.replace(old, new, 1)

old_start = '''        for row in get_enabled_bots():

            print(
                "[AUTO START]",
                row["id"],
            )

            self.spawn(row)

        print("[TELEGRAM] manager started")
'''

new_start = '''        for row in get_enabled_bots():

            print(
                "[AUTO START]",
                row["id"],
            )

            self.spawn(row)

        # -----------------------------------------------
        # SUPERVISOR
        # -----------------------------------------------
        # هر بات process مستقل دارد.
        # اگر یکی قطع شود، فقط همان بات restart می‌شود.

        asyncio.create_task(
            self.monitor_processes()
        )

        print("[TELEGRAM] manager started")
        print("[SUPERVISOR] monitoring enabled")
'''

if old_start not in s:
    raise SystemExit(
        "❌ بخش AUTO START پیدا نشد؛ هیچ تغییری انجام نشد."
    )

s = s.replace(old_start, new_start, 1)

p.write_text(s, encoding="utf-8")

print("========================================")
print("✅ LinuxX 50-BOT SUPERVISOR نصب شد")
print("========================================")
print("✅ مانیتور مستقل برای بات‌ها")
print("✅ restart فقط همان بات")
print("✅ تأخیر بین restart ها")
print("✅ حداکثر 60 ثانیه backoff")
print("✅ خطای یک بات کل سیستم را نمی‌خواباند")
print("✅ بات‌های غیرفعال دوباره اجرا نمی‌شوند")
print("========================================")
