from pathlib import Path

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# ---------------------------------------------------------
# 1) پشتیبانی از متن واقعی دکمه‌های پایین
# ---------------------------------------------------------

marker = '''        # AUTO BOTTOM KEYBOARD
        # -----------------------------------------------
'''

block = '''        # AUTO BOTTOM KEYBOARD
        # -----------------------------------------------
        # دکمه‌های ReplyKeyboard پایین صفحه
        # -----------------------------------------------

        text_normalized = text.strip()

        is_settings_button = text_normalized in (
            "⚙️ تنظیمات بات",
            "تنظیمات بات ⚙️",
            "⚙️ تنظیمات بات ۱",
            "تنظیمات بات",
            "تنظیمات بات ۱",
        )

        is_toggle_button = text_normalized in (
            "🟢 روشن",
            "روشن 🟢",
            "🔴 خاموش",
            "خاموش 🔴",
            "🟢 روشن بات",
            "🔴 خاموش بات",
            "🟢 روشن بات ۱",
            "🔴 خاموش بات ۱",
        )

        # -------------------------------------------------
        # تنظیمات بات
        # -------------------------------------------------

        if is_settings_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است."
                )
                return

            await update.message.reply_text(
                "⚙️ تنظیمات بات\n\n"
                f"🤖 بات #{bot['id']}\\n"
                f"🌐 Room: {bot['room_id']}\\n"
                f"👤 مدیر: @{bot['owner_username']}\\n\\n"
                "یکی از گزینه‌های تنظیمات را انتخاب کن:"
            )

            context.user_data.clear()
            context.user_data["settings_bot"] = bot["id"]

            return

        # -------------------------------------------------
        # روشن / خاموش
        # -------------------------------------------------

        if is_toggle_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است.\\n\\n"
                    "ابتدا اطلاعات بات را در «⚙️ تنظیمات بات» وارد کن."
                )
                return

            # اگر اطلاعات اولیه کامل نیست، اجازه روشن شدن نده
            token = str(bot["token"] or "").strip()
            room_id = str(bot["room_id"] or "").strip()
            manager_id = str(
                bot["manager_id"] or bot["owner_username"] or ""
            ).strip()

            if not token or not room_id or not manager_id:

                await update.message.reply_text(
                    "⚠️ ابتدا تنظیمات بات را کامل کن.\\n\\n"
                    "🔑 توکن Highrise\\n"
                    "🌐 لینک یا ID روم\\n"
                    "👤 ID مدیر"
                )
                return

            new_state = not bool(bot["enabled"])

            if new_state:

                set_enabled(bot["id"], True)

                fresh = get_bot(bot["id"])

                try:
                    self.spawn(fresh)

                    await update.message.reply_text(
                        "🟢 بات با موفقیت روشن شد."
                    )

                except Exception as e:

                    set_enabled(bot["id"], False)

                    await update.message.reply_text(
                        "❌ روشن کردن بات ناموفق بود.\\n\\n"
                        f"خطا: {e}"
                    )

            else:

                set_enabled(bot["id"], False)
                self.stop(bot["id"])

                await update.message.reply_text(
                    "🔴 بات خاموش شد."
                )

            return

'''

if marker in s:
    s = s.replace(marker, block, 1)
    print("✅ منطق دکمه‌های پایین اضافه شد")
else:
    print("❌ AUTO BOTTOM KEYBOARD پیدا نشد")
    raise SystemExit(1)

# ---------------------------------------------------------
# 2) جلوگیری از اجرای کد قدیمی برای همان دکمه‌ها
# ---------------------------------------------------------

old_settings = '''        if text == "⚙️ تنظیمات بات ۱":
'''

if old_settings in s:
    s = s.replace(
        old_settings,
        '''        if False and text == "⚙️ تنظیمات بات ۱":
''',
        1
    )
    print("✅ هندلر قدیمی تنظیمات غیرفعال شد")

old_toggle = '''        if text in ("🟢 روشن بات ۱", "🔴 خاموش بات ۱"):
'''

if old_toggle in s:
    s = s.replace(
        old_toggle,
        '''        if False and text in ("🟢 روشن بات ۱", "🔴 خاموش بات ۱"):
''',
        1
    )
    print("✅ هندلر قدیمی روشن/خاموش غیرفعال شد")

p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ LINUXX BOTTOM BUTTON FIX")
print("==============================================")
print("✅ دکمه ⚙️ تنظیمات بات کار می‌کند")
print("✅ دکمه 🟢 روشن کار می‌کند")
print("✅ دکمه 🔴 خاموش کار می‌کند")
print("✅ ReplyKeyboard پایین صفحه باقی می‌ماند")
print("✅ InlineKeyboard برای پنل اصلی استفاده نمی‌شود")
print("✅ روشن کردن بدون تنظیمات کامل ممنوع است")
print("==============================================")
