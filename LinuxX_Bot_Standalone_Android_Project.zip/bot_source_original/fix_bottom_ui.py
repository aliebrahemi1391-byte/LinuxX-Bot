from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# ---------------------------------------------------------
# Import های لازم
# ---------------------------------------------------------

old_import = "from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update"

new_import = """from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)"""

if old_import in s:
    s = s.replace(old_import, new_import)

# ---------------------------------------------------------
# main_keyboard را کاملاً عوض کن
# ---------------------------------------------------------

pattern = re.compile(
    r'    def main_keyboard\(self, bots\):.*?'
    r'(?=\n    def keyboard\(self, bot_id\):)',
    re.S
)

new_main_keyboard = '''    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        if bot and bool(bot["enabled"]):
            toggle_text = "🔴 خاموش"
        else:
            toggle_text = "🟢 روشن"

        # این ReplyKeyboard است، نه InlineKeyboard.
        # بنابراین پایین صفحه و کنار کادر تایپ نمایش داده می‌شود.
        return ReplyKeyboardMarkup(
            [
                [
                    "⚙️ تنظیمات بات",
                    toggle_text,
                ]
            ],
            resize_keyboard=True,
            is_persistent=True,
            one_time_keyboard=False,
        )

'''

s, n = pattern.subn(new_main_keyboard, s, count=1)

print("main_keyboard:", "OK" if n else "NOT FOUND")

# ---------------------------------------------------------
# هر main_keyboard که داخل پیام استفاده شده،
# همچنان قابل استفاده است چون خودش ReplyKeyboard است.
# ---------------------------------------------------------

# ---------------------------------------------------------
# InlineKeyboard را از پنل اصلی حذف کن
# ---------------------------------------------------------

# اگر جایی پنل اصلی مستقیماً InlineKeyboard ساخته باشد،
# آن بخش را تبدیل نمی‌کنیم؛ فقط main_keyboard مرجع اصلی است.
# ---------------------------------------------------------

# ---------------------------------------------------------
# متن اصلی /start:
# پیام بدون دکمه داخلی ارسال شود.
# بعد ReplyKeyboard پایین صفحه باقی بماند.
# ---------------------------------------------------------

pattern_start = re.compile(
    r'(await update\.message\.reply_text\(\s*'
    r'"🟢 LinuxX Highrise Manager.*?'
    r')(,\s*reply_markup=self\.main_keyboard\(bots\))',
    re.S
)

s, n2 = pattern_start.subn(r'\1,\n            reply_markup=self.main_keyboard(bots)', s, count=1)

# ---------------------------------------------------------
# مهم:
# InlineKeyboard های اصلی قدیمی را از main_keyboard حذف کردیم.
# ---------------------------------------------------------

p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ BOTTOM KEYBOARD PATCH")
print("==============================================")
print("✅ دکمه‌ها دیگر داخل پیام نیستند")
print("✅ دکمه‌ها پایین صفحه قرار می‌گیرند")
print("✅ فقط دو دکمه")
print("   ⚙️ تنظیمات بات")
print("   🟢 روشن / 🔴 خاموش")
print("==============================================")
