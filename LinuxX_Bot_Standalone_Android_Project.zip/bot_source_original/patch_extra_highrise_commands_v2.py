from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

if "LINUXX_EXTRA_COMMANDS_V2" in s:
    print("⚠️ این پچ قبلاً نصب شده است.")
    raise SystemExit

# ---------------------------------------------------------
# 1. اضافه کردن import
# ---------------------------------------------------------

if "import json" not in s:
    s = s.replace(
        "import os\n",
        "import os\nimport json\n",
        1
    )

# ---------------------------------------------------------
# 2. توابع کمکی داخل HighriseBot
# ---------------------------------------------------------

marker = "    # -----------------------------------------------------\n    # RANDOM WALK"

helpers = r'''
    # -----------------------------------------------------
    # LINUXX_EXTRA_COMMANDS_V2
    # SAVED LOCATIONS
    # -----------------------------------------------------

    def _locations_file(self):
        return BASE_DIR / f"locations_{self.bot_id}.json"

    def _load_locations(self):
        path = self._locations_file()

        try:
            if path.exists():
                data = json.loads(
                    path.read_text(encoding="utf-8")
                )
            else:
                data = {}
        except Exception:
            data = {}

        if not isinstance(data, dict):
            data = {}

        data.setdefault("admin", {})
        data.setdefault("public", {})

        return data

    def _save_locations(self, data):
        try:
            self._locations_file().write_text(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            return True
        except Exception as e:
            print("[LOCATION SAVE ERROR]", e)
            return False

    def _position_to_dict(self, position):
        if position is None:
            return None

        return {
            "x": getattr(position, "x", 0),
            "y": getattr(position, "y", 0),
            "z": getattr(position, "z", 0),
            "facing": getattr(position, "facing", "FrontRight"),
        }

    def _dict_to_position(self, data):
        if not data:
            return None

        try:
            return Position(
                float(data["x"]),
                float(data["y"]),
                float(data["z"]),
                data.get("facing", "FrontRight"),
            )
        except Exception as e:
            print("[LOCATION POSITION ERROR]", e)
            return None

    def _set_pending_loop(self, text):
        self.pending_loop_text = text
        self.pending_loop_user = None

    async def _start_loop(self, text, delay):
        if hasattr(self, "loop_task") and self.loop_task:
            self.loop_task.cancel()
            try:
                await self.loop_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_text = text
        self.loop_delay = delay

        async def loop_runner():
            try:
                while True:
                    await self.highrise.chat(self.loop_text)
                    await asyncio.sleep(self.loop_delay)

            except asyncio.CancelledError:
                return

            except Exception as e:
                print("[LOOP ERROR]", e)

        self.loop_task = asyncio.create_task(loop_runner())

    async def _stop_loop(self):
        task = getattr(self, "loop_task", None)

        if task:
            task.cancel()

            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_task = None

    # -----------------------------------------------------
    # EXTRA COMMANDS V2
    # -----------------------------------------------------

'''

if marker not in s:
    print("❌ محل RANDOM WALK پیدا نشد.")
    raise SystemExit(1)

s = s.replace(marker, helpers + marker, 1)

# ---------------------------------------------------------
# 3. اضافه کردن متغیرهای اولیه بعد از self.users
# ---------------------------------------------------------

init_candidates = [
    "        self.users = {}\n",
    "        self.users = dict()\n",
]

init_added = False

for candidate in init_candidates:
    if candidate in s:
        addition = candidate + """
        self.loop_task = None
        self.loop_text = None
        self.loop_delay = None
        self.pending_loop_text = None
        self.pending_loop_user = None
"""
        s = s.replace(candidate, addition, 1)
        init_added = True
        break

if not init_added:
    print("⚠️ self.users پیدا نشد؛ متغیرهای لوپ به‌صورت خودکار ساخته می‌شوند.")

# ---------------------------------------------------------
# 4. اضافه کردن command handling
# ---------------------------------------------------------

command_marker = """        # -----------------------------------------------
        # MOVEMENT
        # -----------------------------------------------
"""

commands = r'''        # -----------------------------------------------
        # EXTRA LOCATION / LOOP / SPAM / OUTFIT COMMANDS
        # -----------------------------------------------

        # !ایده و اجرا
        if text == "!ایده و اجرا":
            await self.highrise.chat(
                "<#FFD700>💡 Idea and implementation by "
                "<#00CCFF>@84.43 "
                "<#FFFFFF>and "
                "<#00CCFF>@55._65"
            )
            return

        # ------------------------------------------------
        # !دستورات
        # ------------------------------------------------

        if text == "!دستورات":

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
                "<#FFD700>📖 دستورات عمومی\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\n"
                "<#FFFFFF>!تاس\n"
                "<#FFFFFF>!دستورات\n"
                "<#FFFFFF>!ایده و اجرا\n"
                "<#FFFFFF>محل‌های عمومی: نام محل\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            if self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>👑 دستورات مدیریتی\n"
                    "!لباس\n"
                    "!لباس @id\n"
                    "!کیک @id\n"
                    "!فریز @id\n"
                    "!انفریز @id\n"
                    "!ادمین @id\n"
                    "!حذف ادمین @id\n"
                    "!موت @id\n"
                    "!انموت @id\n"
                    "!حرکت\n"
                    "!حرکت توقف\n"
                    "!بات\n\n"
                    "📍 محل ادمین:\n"
                    "!محل ذخیره ادمین t1\n"
                    "t1\n\n"
                    "🌍 محل عمومی:\n"
                    "!ذخیره محل عمومی a1\n"
                    "a1\n\n"
                    "🔁 لوپ:\n"
                    "!لوپ سلام\n"
                    "!لوپ 1\n"
                    "!لوپ توقف\n\n"
                    "📢 اسپم:\n"
                    "!اسپم 100 سلام"
                )

            return

        # ------------------------------------------------
        # LOOP STOP
        # ------------------------------------------------

        if text == "!لوپ توقف":

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ را متوقف کند."
                )
                return

            await self._stop_loop()

            await self.highrise.chat(
                "<#FFD700>🛑 لوپ متوقف شد."
            )
            return

        # ------------------------------------------------
        # LOOP TEXT
        # ------------------------------------------------

        if text.startswith("!لوپ "):

            value = text[5:].strip()

            if not value:
                return

            # اگر فقط عدد باشد یعنی تعیین تأخیر
            if value.isdigit():

                if not self.is_admin(uid):
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ تنظیم کند."
                    )
                    return

                if not self.pending_loop_text:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FFD700>ابتدا بنویس:\n!لوپ متن دلخواه\n"
                        "مثال: !لوپ سلام"
                    )
                    return

                delay = float(value)

                if delay < 1:
                    delay = 1

                if delay > 3600:
                    delay = 3600

                loop_text = self.pending_loop_text
                self.pending_loop_text = None

                await self._start_loop(
                    loop_text,
                    delay,
                )

                await self.highrise.chat(
                    f"<#00FF88>🔁 لوپ شروع شد\n"
                    f"<#FFFFFF>متن: {loop_text}\n"
                    f"<#FFFFFF>تأخیر: {delay:g} ثانیه"
                )

                return

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ بسازد."
                )
                return

            self.pending_loop_text = value
            self.pending_loop_user = uid

            await self.highrise.send_whisper(
                uid,
                "<#FFD700>⏱ تأخیر لوپ را وارد کن.\n"
                "<#FFFFFF>مثال:\n"
                "!لوپ 1\n\n"
                "<#FFFFFF>برای ارسال هر ۱ ثانیه."
            )

            return

        # ------------------------------------------------
        # SPAM
        # ------------------------------------------------

        if text.startswith("!اسپم "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند اسپم ارسال کند."
                )
                return

            parts = text.split(maxsplit=2)

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n!اسپم 100 سلام"
                )
                return

            try:
                count = int(
                    parts[1].translate(
                        str.maketrans(
                            "۰۱۲۳۴۵۶۷۸۹",
                            "0123456789",
                        )
                    )
                )
            except Exception:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ تعداد پیام باید عدد باشد."
                )
                return

            spam_text = parts[2].strip()

            if count < 1:
                count = 1

            # جلوگیری از مقدارهای بسیار بزرگ
            if count > 500:
                count = 500

            for _ in range(count):
                try:
                    await self.highrise.chat(spam_text)
                except Exception as e:
                    print("[SPAM ERROR]", e)
                    break

            return

        # ------------------------------------------------
        # ADMIN SAVED LOCATION
        # !محل ذخیره ادمین t1
        # ------------------------------------------------

        if text.startswith("!محل ذخیره ادمین "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند محل ادمین ذخیره کند."
                )
                return

            name = text[len("!محل ذخیره ادمین "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["admin"] and len(locations["admin"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل ادمین قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["admin"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>📍 محل ادمین «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # PUBLIC SAVED LOCATION
        # !ذخیره محل عمومی a1
        # ------------------------------------------------

        if text.startswith("!ذخیره محل عمومی "):

            # فقط مدیر اصلی
            if str(user.username).lower() != "84.43":
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر اصلی بات می‌تواند محل عمومی ذخیره کند."
                )
                return

            name = text[len("!ذخیره محل عمومی "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["public"] and len(locations["public"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل عمومی قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["public"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>🌍 محل عمومی «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # TELEPORT TO SAVED LOCATION
        # ------------------------------------------------

        locations = self._load_locations()

        # محل ادمین فقط برای ادمین‌ها
        if text in locations["admin"]:

            if not self.is_admin(uid):
                return

            position = self._dict_to_position(
                locations["admin"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>📍 به محل ادمین «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[ADMIN TELEPORT ERROR]", e)

            return

        # محل عمومی برای همه
        if text in locations["public"]:

            position = self._dict_to_position(
                locations["public"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>🌍 به محل «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[PUBLIC TELEPORT ERROR]", e)

            return

        # ------------------------------------------------
        # OUTFIT FROM TARGET
        # !لباس @id
        # ------------------------------------------------

        if text.startswith("!لباس "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ شما مدیر بات نیستید."
                )
                return

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                outfit_response = await self.highrise.get_user_outfit(
                    str(target.id)
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if not outfit:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ لباس کاربر پیدا نشد."
                    )
                    return

                result = await self.highrise.set_outfit(
                    list(outfit)
                )

                await self.highrise.chat(
                    f"<#00FF88>👕 لباس @{target.username} روی بات اعمال شد."
                )

            except Exception as e:
                print("[COPY OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ خطا در کپی لباس: {e}"
                )

            return

'''

if command_marker not in s:
    print("❌ بخش MOVEMENT پیدا نشد.")
    raise SystemExit(1)

s = s.replace(
    command_marker,
    commands + command_marker,
    1
)

# ---------------------------------------------------------
# 5. اصلاح admin_commands تا دستورات جدید قبل از
#    ADMIN CHECK گیر نکنند
# ---------------------------------------------------------

old_admin = '''            or text == "!بات"
        )
'''

new_admin = '''            or text == "!بات"
            or text.startswith("!محل ذخیره ادمین ")
            or text.startswith("!ذخیره محل عمومی ")
            or text.startswith("!لوپ ")
            or text.startswith("!اسپم ")
        )
'''

# فقط اولین مورد
if old_admin in s:
    s = s.replace(old_admin, new_admin, 1)

# ---------------------------------------------------------
# 6. جلوگیری از تداخل !دستورات قبلی
# ---------------------------------------------------------

# چون نسخه جدید !دستورات قبل از admin check اضافه شده،
# دستور قبلی ممکن است همچنان بعداً وجود داشته باشد.
# آن را حذف نمی‌کنیم تا ساختار فعلی خراب نشود.

p.write_text(s, encoding="utf-8")

print("========================================")
print("✅ LINUXX_EXTRA_COMMANDS_V2 نصب شد")
print("========================================")
print("✅ محل ادمین: حداکثر 5")
print("✅ محل عمومی: حداکثر 5")
print("✅ لوپ")
print("✅ اسپم")
print("✅ لباس @id")
print("✅ ایده و اجرا")
print("✅ دستورات جدید")
print("========================================")
