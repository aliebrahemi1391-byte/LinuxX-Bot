from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# =========================================================
# AUTH CONSTANTS + STORAGE
# =========================================================

anchor = "class TelegramManager:\n"

auth_code = r'''
# =========================================================
# LINUXX AUTH SYSTEM
# =========================================================

AUTH_PASSWORD = "python botOrder.py"
AUTH_FILE = BASE_DIR / "telegram_auth.json"

def load_auth():
    import json

    if not AUTH_FILE.exists():
        return {}

    try:
        return json.loads(
            AUTH_FILE.read_text(encoding="utf-8")
        )
    except Exception:
        return {}

def save_auth(data):
    import json

    AUTH_FILE.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2
        ),
        encoding="utf-8"
    )

def auth_status(user_id):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    return user

def is_authorized(user_id):
    user = auth_status(user_id)

    return (
        user.get("authorized", False)
        and not user.get("blocked", False)
    )

def is_blocked(user_id):
    return auth_status(user_id).get(
        "blocked",
        False
    )

def check_password(user_id, password):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    if user.get("blocked"):
        return "blocked"

    if password == AUTH_PASSWORD:

        user["authorized"] = True
        user["attempts"] = 0
        user["blocked"] = False

        data[key] = user
        save_auth(data)

        return "ok"

    user["attempts"] = int(
        user.get("attempts", 0)
    ) + 1

    if user["attempts"] >= 3:

        user["blocked"] = True
        user["authorized"] = False

        data[key] = user
        save_auth(data)

        return "blocked"

    data[key] = user
    save_auth(data)

    return 3 - user["attempts"]

'''

if "AUTH_PASSWORD = \"python botOrder.py\"" not in s:
    if anchor not in s:
        raise SystemExit("❌ class TelegramManager پیدا نشد")

    s = s.replace(
        anchor,
        auth_code + "\n\n" + anchor,
        1
    )

# =========================================================
# REPLACE MAIN KEYBOARD
# =========================================================

start = s.find("    def main_keyboard(self, bots):")
end = s.find("    def keyboard(self, bot_id):", start)

if start == -1 or end == -1:
    raise SystemExit("❌ main_keyboard پیدا نشد")

new_keyboard = '''    def main_keyboard(self, bots):

        rows = []

        bot_ids = [1, 2]

        for bot_id in bot_ids:

            row = get_bot(bot_id)

            if row:

                status = (
                    "🟢 روشن"
                    if row["enabled"]
                    else "🔴 خاموش"
                )

                rows.append([
                    InlineKeyboardButton(
                        f"⚙️ تنظیمات بات {bot_id}",
                        callback_data=f"settings:{bot_id}"
                    ),
                    InlineKeyboardButton(
                        f"{status} بات {bot_id}",
                        callback_data=f"toggle:{bot_id}"
                    ),
                ])

        rows.append([
            InlineKeyboardButton(
                "➕ افزودن بات",
                callback_data="add_bot"
            )
        ])

        return InlineKeyboardMarkup(rows)

'''

s = s[:start] + new_keyboard + s[end:]

# =========================================================
# REPLACE /START
# =========================================================

start = s.find("    async def start_command(")
end = s.find("    # -----------------------------------------------------\n    # BUTTONS", start)

if start == -1 or end == -1:
    raise SystemExit("❌ start_command پیدا نشد")

new_start = '''    async def start_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        user_id = update.effective_user.id

        context.user_data.clear()

        if is_blocked(user_id):

            await update.message.reply_text(
                "⛔ دسترسی شما به LinuxX Bot مسدود شده است."
            )

            return

        if not is_authorized(user_id):

            context.user_data["waiting_password"] = True

            await update.message.reply_text(
                "🔐 LinuxX Highrise System\\n\\n"
                "برای ورود به پنل رمز عبور را ارسال کن.\\n"
                "⚠️ فقط ۳ تلاش مجاز است."
            )

            return

        bots = get_user_bots(user_id)

        await update.message.reply_text(
            "🟢 LinuxX Highrise Manager\\n\\n"
            "خوش آمدید 👑\\n"
            "پنل مدیریت بات‌ها آماده است.",
            reply_markup=self.main_keyboard(bots),
        )

'''

s = s[:start] + new_start + s[end:]

# =========================================================
# AUTH AT START OF BUTTON
# =========================================================

button_marker = '''        query = update.callback_query
        await query.answer()

        data = query.data
'''

replacement = '''        query = update.callback_query
        await query.answer()

        user_id = update.effective_user.id

        if is_blocked(user_id):

            await query.answer(
                "⛔ دسترسی شما مسدود شده است.",
                show_alert=True,
            )

            return

        if not is_authorized(user_id):

            await query.answer(
                "🔐 ابتدا رمز عبور را وارد کنید.",
                show_alert=True,
            )

            return

        data = query.data
'''

if button_marker not in s:
    raise SystemExit("❌ بخش button پیدا نشد")

s = s.replace(
    button_marker,
    replacement,
    1
)

# =========================================================
# AUTH AT START OF TEXT HANDLER
# =========================================================

text_marker = '''        user_id = update.effective_user.id

        # -----------------------------------------------
        # EDIT EXISTING BOT
'''

text_replacement = '''        user_id = update.effective_user.id

        # -----------------------------------------------
        # PASSWORD AUTH
        # -----------------------------------------------

        if is_blocked(user_id):

            await update.message.reply_text(
                "⛔ دسترسی شما به LinuxX Bot مسدود شده است."
            )

            return

        if context.user_data.get("waiting_password"):

            result = check_password(
                user_id,
                text,
            )

            context.user_data.clear()

            if result == "ok":

                bots = get_user_bots(user_id)

                await update.message.reply_text(
                    "✅ رمز صحیح است.\\n\\n"
                    "🟢 دسترسی به پنل فعال شد.",
                    reply_markup=self.main_keyboard(bots),
                )

                return

            if result == "blocked":

                await update.message.reply_text(
                    "⛔ ۳ بار رمز اشتباه وارد شد.\\n\\n"
                    "دسترسی شما مسدود شد."
                )

                return

            await update.message.reply_text(
                f"❌ رمز اشتباه است.\\n"
                f"⚠️ {result} تلاش باقی مانده."
            )

            context.user_data["waiting_password"] = True

            return

        if not is_authorized(user_id):

            context.user_data["waiting_password"] = True

            await update.message.reply_text(
                "🔐 ابتدا رمز عبور را وارد کن."
            )

            return

        # -----------------------------------------------
        # EDIT EXISTING BOT
'''

if text_marker not in s:
    raise SystemExit("❌ text_handler marker پیدا نشد")

s = s.replace(
    text_marker,
    text_replacement,
    1
)

# =========================================================
# SAVE
# =========================================================

p.write_text(
    s,
    encoding="utf-8"
)

print("")
print("==============================================")
print("✅ LinuxX AUTH + 4 BUTTON UI نصب شد")
print("==============================================")
print("🔐 Password: python botOrder.py")
print("🚫 3 wrong attempts = BLOCK")
print("💾 Auth data: telegram_auth.json")
print("🎛️ 4-button main panel")
print("🤖 Bot 1 settings/toggle")
print("🤖 Bot 2 settings/toggle")
print("==============================================")
