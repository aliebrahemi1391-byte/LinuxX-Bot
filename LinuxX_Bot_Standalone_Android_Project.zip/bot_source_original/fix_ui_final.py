from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# =========================================================
# 1) فقط یک بات برای هر اکانت
# =========================================================

s = s.replace(
    "MAX_BOTS_PER_USER = 2",
    "MAX_BOTS_PER_USER = 1"
)

# =========================================================
# 2) حذف ReplyKeyboardMarkup از import
# =========================================================

s = s.replace(
    "    ReplyKeyboardMarkup,\n",
    ""
)

# =========================================================
# 3) حذف ReplyKeyboardMarkup از کل فایل
#    هر بلاک reply keyboard که برای منوی پایین بوده
# =========================================================

s = re.sub(
    r'\n\s*reply_markup=ReplyKeyboardMarkup\(\s*'
    r'\[\s*'
    r'\["🔑 تغییر توکن"\],\s*'
    r'\["🌐 تغییر لینک روم"\],\s*'
    r'\["👤 تغییر ID مدیر"\],\s*'
    r'\["🔙 بازگشت"\],\s*'
    r'\],\s*'
    r'resize_keyboard=True,\s*'
    r'is_persistent=True,\s*'
    r'one_time_keyboard=False,\s*'
    r'\),',
    "",
    s,
    flags=re.S
)

# =========================================================
# 4) بخش تنظیمات متنی را بعد از انتخاب تنظیمات
#    فقط Inline Keyboard نشان بدهد
# =========================================================

old = '''            await update.message.reply_text(
                "⚙️ تنظیمات بات ۱\\n\\n"
                f"🤖 بات #{bot['id']}\\n"
                f"🌐 Room: {bot['room_id']}\\n"
                f"👤 مدیر: @{bot['owner_username']}\\n\\n"
                "یکی از گزینه‌ها را انتخاب کن:",
                reply_markup=ReplyKeyboardMarkup(
                    [
                        ["🔑 تغییر توکن"],
                        ["🌐 تغییر لینک روم"],
                        ["👤 تغییر ID مدیر"],
                        ["🔙 بازگشت"],
                    ],
                    resize_keyboard=True,
                    is_persistent=True,
                    one_time_keyboard=False,
                ),
            )
'''

new = '''            await update.message.reply_text(
                "⚙️ تنظیمات بات ۱\\n\\n"
                f"🤖 بات #{bot['id']}\\n"
                f"🌐 Room: {bot['room_id']}\\n"
                f"👤 مدیر: @{bot['owner_username']}\\n\\n"
                "یکی از گزینه‌ها را انتخاب کن:",
                reply_markup=self.settings_keyboard(bot["id"]),
            )
'''

if old in s:
    s = s.replace(old, new)
else:
    print("⚠️ بلاک تنظیمات ReplyKeyboard پیدا نشد؛ ادامه داده شد.")

# =========================================================
# 5) حذف منوی پایین ReplyKeyboard از بخش TEXT INPUT
# =========================================================

start_marker = "        # -----------------------------------------------\n        # AUTO BOTTOM KEYBOARD\n"

if start_marker in s:
    start = s.index(start_marker)

    end_marker = "        # -----------------------------------------------\n        # EDIT EXISTING BOT\n"

    end = s.find(end_marker, start)

    if end != -1:
        s = s[:start] + s[end:]
        print("✅ AUTO BOTTOM KEYBOARD حذف شد.")
    else:
        print("⚠️ پایان AUTO BOTTOM KEYBOARD پیدا نشد.")
else:
    print("ℹ️ AUTO BOTTOM KEYBOARD قبلاً حذف شده یا وجود ندارد.")

# =========================================================
# 6) حذف هر ReplyKeyboardMarkup باقی‌مانده
# =========================================================

s = re.sub(
    r'\s*reply_markup\s*=\s*ReplyKeyboardMarkup\(.*?\),',
    "",
    s,
    flags=re.S
)

# =========================================================
# 7) جلوگیری از خطای Query is too old
# =========================================================

old_answer = '''        query = update.callback_query
        await query.answer()

        user_id = update.effective_user.id
'''

new_answer = '''        query = update.callback_query

        try:
            await query.answer()
        except Exception:
            # callback قدیمی/منقضی شده؛ پردازش دکمه متوقف نشود
            pass

        user_id = update.effective_user.id
'''

if old_answer in s:
    s = s.replace(old_answer, new_answer, 1)
    print("✅ خطای Query is too old اصلاح شد.")
else:
    print("ℹ️ query.answer قبلاً اصلاح شده یا الگوی آن متفاوت است.")

# =========================================================
# 8) main_keyboard نهایی:
#    فقط دو دکمه Inline
# =========================================================

pattern = re.compile(
    r'    def main_keyboard\(self, bots\):.*?'
    r'\n    def keyboard\(self, bot_id\):',
    re.S
)

replacement = '''    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        if bot:
            status = (
                "🟢 روشن"
                if bot["enabled"]
                else "🔴 خاموش"
            )

            toggle_text = f"{status} / تغییر وضعیت"

        else:
            toggle_text = "🔴 خاموش / 🟢 روشن"

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "⚙️ تنظیمات بات",
                    callback_data="settings:1",
                ),
                InlineKeyboardButton(
                    toggle_text,
                    callback_data="toggle:1",
                ),
            ]
        ])

    def keyboard(self, bot_id):'''

s, count = pattern.subn(replacement, s, count=1)

if count:
    print("✅ main_keyboard نهایی شد.")
else:
    print("⚠️ main_keyboard پیدا نشد.")

# =========================================================
# 9) ذخیره
# =========================================================

p.write_text(s, encoding="utf-8")

print()
print("==============================================")
print("✅ LinuxX FINAL UI PATCH نصب شد")
print("==============================================")
print("✅ فقط Inline Keyboard")
print("✅ هیچ Reply Keyboard پایین صفحه باقی نمی‌ماند")
print("✅ هر اکانت فقط ۱ بات")
print("✅ تنظیمات بات")
print("✅ روشن / خاموش")
print("✅ خطای callback قدیمی کنترل شد")
print("✅ رمز عبور دست‌نخورده")
print("✅ Supervisor دست‌نخورده")
print("==============================================")
