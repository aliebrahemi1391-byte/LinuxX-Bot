from pathlib import Path
import re
import shutil
import py_compile
from datetime import datetime

P = Path("main.py")
if not P.exists():
    raise SystemExit("❌ main.py پیدا نشد")

# =========================
# BACKUP
# =========================
backup = P.with_name(
    f"main.py.before_command_fix_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
)
shutil.copy2(P, backup)
print(f"💾 بکاپ: {backup.name}")

s = P.read_text(encoding="utf-8")

# =========================
# IMPORT Position
# =========================
if "from highrise.models import Position" not in s:
    lines = s.splitlines()
    insert_at = 0

    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            insert_at = i + 1

    lines.insert(insert_at, "from highrise.models import Position")
    s = "\n".join(lines) + "\n"

# =========================
# HELPERS
# =========================
helper_marker = "# === LINUXX_COMMAND_FIX_V4 ==="

if helper_marker not in s:

    helper = r'''
# === LINUXX_COMMAND_FIX_V4 ===

    async def _lx_room_users(self):
        try:
            result = await self.highrise.get_room_users()
            return getattr(result, "content", []) or []
        except Exception as e:
            print("[ROOM USERS ERROR]", repr(e))
            return []

    async def _lx_find_user(self, username):
        username = username.strip().lstrip("@").lower()

        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if str(u.username).lower() == username:
                    return u, pos
            except Exception:
                continue

        return None, None

    async def _lx_my_position(self, user_id):
        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if u.id == user_id:
                    return pos
            except Exception:
                continue

        return None

    async def _lx_send(self, text):
        try:
            await self.highrise.chat(text)
        except Exception as e:
            print("[CHAT ERROR]", repr(e))

    async def _lx_command_fix(self, user, message):

        msg = str(message).strip()
        parts = msg.split()

        if not parts:
            return False

        low = msg.lower()

        # ============================================================
        # !بیا @id
        # ============================================================
        if low.startswith("!بیا "):

            if len(parts) < 2:
                await self._lx_send("❌ فرمت: !بیا @id")
                return True

            target, _ = await self._lx_find_user(parts[1])

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            my_pos = await self._lx_my_position(user.id)

            if my_pos is None:
                await self._lx_send("❌ موقعیت شما پیدا نشد.")
                return True

            try:
                await self.highrise.teleport(target.id, my_pos)

                await self._lx_send(
                    f"✅ @{target.username} به موقعیت شما منتقل شد."
                )

            except Exception as e:
                print("[BRING ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !برو به @id نام محل
        # ============================================================
        if low.startswith("!برو به "):

            if len(parts) < 3:
                await self._lx_send(
                    "❌ فرمت: !برو به @id نام محل"
                )
                return True

            target_name = parts[2]
            location_name = " ".join(parts[3:]).strip().lower()

            if not location_name:
                await self._lx_send(
                    "❌ نام محل را وارد کن."
                )
                return True

            target, _ = await self._lx_find_user(target_name)

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            locations = getattr(self, "admin_locations", {})

            position = locations.get(location_name)

            # پشتیبانی از حروف بزرگ/کوچک
            if position is None:
                for key, value in locations.items():
                    if str(key).lower() == location_name:
                        position = value
                        break

            if position is None:
                await self._lx_send(
                    f"❌ موقعیت «{location_name}» پیدا نشد."
                )
                return True

            try:
                await self.highrise.teleport(
                    target.id,
                    position
                )

                await self._lx_send(
                    f"✅ @{target.username} به «{location_name}» منتقل شد."
                )

            except Exception as e:
                print("[GOTO ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !تیپ
        #
        # پشتیبانی:
        # !تیپ ۱ @id
        # !تیپ ۱ همه
        # !تیپ همه ۱
        # ============================================================
        if low.startswith("!تیپ "):

            args = parts[1:]

            if len(args) < 2:
                await self._lx_send(
                    "❌ فرمت:\n!تیپ ۱ @id\n!تیپ ۱ همه\n!تیپ همه ۱"
                )
                return True

            # تبدیل اعداد فارسی
            trans = str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789"
            )

            def number(x):
                try:
                    return int(str(x).translate(trans))
                except Exception:
                    return None

            amount = None
            target_arg = None

            # !تیپ همه ۱
            if str(args[0]).lower() == "همه":
                amount = number(args[1])
                target_arg = "همه"

            # !تیپ ۱ همه
            else:
                amount = number(args[0])
                target_arg = args[1]

            allowed = {
                1: "gold_bar_1",
                5: "gold_bar_5",
                10: "gold_bar_10",
                50: "gold_bar_50",
                100: "gold_bar_100",
                500: "gold_bar_500",
                1000: "gold_bar_1k",
                5000: "gold_bar_5000",
                10000: "gold_bar_10k",
            }

            if amount not in allowed:
                await self._lx_send(
                    "❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return True

            gold_bar = allowed[amount]

            # ========================================================
            # TIP ALL
            # ========================================================
            if str(target_arg).lower() == "همه":

                users = await self._lx_room_users()

                success = 0
                failed = 0

                for item in users:

                    try:
                        target = item[0]

                        # خود بات
                        if getattr(self, "bot_id", None):
                            if target.id == self.bot_id:
                                continue

                        # مالک/دستوردهنده هم طبق دستور تیپ می‌گیرد
                        try:
                            await self.highrise.tip_user(
                                target.id,
                                gold_bar
                            )
                            success += 1

                        except Exception as e:
                            failed += 1
                            print(
                                f"[TIP ALL ERROR] "
                                f"@{target.username}: {e}"
                            )

                    except Exception:
                        failed += 1

                await self._lx_send(
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {success}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return True

            # ========================================================
            # TIP ONE
            # ========================================================
            target, _ = await self._lx_find_user(target_arg)

            if target is None:
                await self._lx_send(
                    "❌ کاربر پیدا نشد."
                )
                return True

            try:
                await self.highrise.tip_user(
                    target.id,
                    gold_bar
                )

                await self._lx_send(
                    f"💰 {amount} تیپ به "
                    f"@{target.username} ارسال شد."
                )

            except Exception as e:
                print("[TIP ERROR]", repr(e))
                await self._lx_send(
                    "❌ ارسال تیپ انجام نشد."
                )

            return True

        return False

'''

    # helper را قبل از on_chat وارد کلاس کن
    m = re.search(
        r"(?m)^    async def on_chat\(self, user, message\):",
        s
    )

    if not m:
        raise SystemExit(
            "❌ on_chat(self, user, message) پیدا نشد."
        )

    s = s[:m.start()] + helper + "\n" + s[m.start():]

# =========================
# INSERT HANDLER
# =========================
handler_marker = "# === LINUXX_COMMAND_FIX_CALL ==="

if handler_marker not in s:

    pattern = (
        r"(?m)^    async def on_chat\(self, user, message\):\n"
    )

    replacement = (
        "    async def on_chat(self, user, message):\n"
        "        # === LINUXX_COMMAND_FIX_CALL ===\n"
        "        try:\n"
        "            if await self._lx_command_fix(user, message):\n"
        "                return\n"
        "        except Exception as e:\n"
        "            print('[COMMAND FIX ERROR]', repr(e))\n"
    )

    s, count = re.subn(
        pattern,
        replacement,
        s,
        count=1
    )

    if count != 1:
        raise SystemExit(
            "❌ محل on_chat برای نصب پچ پیدا نشد."
        )

# =========================
# WRITE
# =========================
P.write_text(s, encoding="utf-8")

# =========================
# SYNTAX CHECK
# =========================
try:
    py_compile.compile(
        str(P),
        doraise=True
    )
except Exception as e:
    shutil.copy2(backup, P)
    print("❌ Syntax Error؛ فایل به بکاپ برگردانده شد.")
    print(e)
    raise SystemExit(1)

print()
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("✅ LINUXX COMMAND FIX V4 نصب شد")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("✅ !بیا @id")
print("✅ !برو به @id نام محل")
print("✅ !تیپ ۱ @id")
print("✅ !تیپ ۱ همه")
print("✅ !تیپ همه ۱")
print("✅ بکاپ ساخته شد")
print("✅ Syntax OK")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
