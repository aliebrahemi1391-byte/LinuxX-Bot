import os
import re
import sys
import json
import sqlite3
import asyncio
import random
import subprocess
from pathlib import Path

TOKEN_RE = re.compile(r"^[a-z0-9]{64}$")
ROOM_ID_RE = re.compile(r'^[A-Za-z0-9]{20,64}$')
from urllib.parse import urlparse, parse_qs

from highrise import BaseBot, Position

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)

from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from adbot_dance import EMOTES, EMOTE_DURATIONS, resolve_emote, dance_duration
from highrise.models import Position


BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "bots.db"

MAX_BOTS = 50
MAX_BOTS_PER_USER = 1
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

PV_MESSAGE = "Power taken from @84.43"

WELCOME_MESSAGE = (
    "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
    "<#FFD700>🤖 LinuxX Bot\n"
    "<#00CCFF>به روم خوش آمدید 🌹\n"
    "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
)

BOT_START_MESSAGE = (
    "<#00CCFF>🤖 بات روشن شد\n"
    "<#FFD700>LinuxX Bot"
)

BOT_STOP_MESSAGE = (
    "<#FF5555>🔴 بات خاموش شد\n"
    "<#FFD700>LinuxX Bot"
)


# ---------------------------------------------------------
# DATABASE
# ---------------------------------------------------------

def db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS bots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_user_id INTEGER NOT NULL,
            token TEXT NOT NULL,
            room_id TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            manager_id TEXT DEFAULT '',
            enabled INTEGER NOT NULL DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            bot_id INTEGER NOT NULL,
            user_id TEXT NOT NULL,
            username TEXT,
            PRIMARY KEY (bot_id, user_id)
        )
    """)

    # اضافه کردن ستون برای دیتابیس‌های قدیمی
    try:
        conn.execute(
            "ALTER TABLE bots ADD COLUMN manager_id TEXT DEFAULT ''"
        )
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()


def get_user_bots(tg_user_id):
    conn = db()
    rows = conn.execute(
        "SELECT * FROM bots WHERE telegram_user_id=? ORDER BY id",
        (tg_user_id,),
    ).fetchall()
    conn.close()
    return rows


def get_bot(bot_id):
    conn = db()
    row = conn.execute(
        "SELECT * FROM bots WHERE id=?",
        (bot_id,),
    ).fetchone()
    conn.close()
    return row


def create_or_update_bot(tg_user_id, token, room_id, owner_username):
    conn = db()

    # -------------------------------------------------
    # بررسی بات‌های همین کاربر
    # حداکثر ۲ بات برای هر کاربر
    # -------------------------------------------------
    rows = conn.execute(
        "SELECT id FROM bots WHERE telegram_user_id=? ORDER BY id",
        (tg_user_id,),
    ).fetchall()

    # اگر همین اطلاعات قبلاً وجود دارد، همان بات را بروزرسانی کن
    existing = conn.execute("""
        SELECT id
        FROM bots
        WHERE telegram_user_id=?
          AND token=?
          AND room_id=?
        LIMIT 1
    """, (
        tg_user_id,
        token,
        room_id,
    )).fetchone()

    if existing:
        bot_id = existing["id"]

        conn.execute("""
            UPDATE bots
            SET owner_username=?,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (
            owner_username,
            bot_id,
        ))

        conn.commit()
        conn.close()

        return bot_id

    # -------------------------------------------------
    # محدودیت کلی سیستم
    # -------------------------------------------------
    total = conn.execute(
        "SELECT COUNT(*) AS c FROM bots"
    ).fetchone()["c"]

    if total >= MAX_BOTS:
        conn.close()
        raise RuntimeError(
            "ظرفیت کل سیستم (۵۰ بات) پر شده است."
        )

    # -------------------------------------------------
    # محدودیت هر کاربر
    # -------------------------------------------------
    if len(rows) >= MAX_BOTS_PER_USER:
        conn.close()
        raise RuntimeError(
            f"هر کاربر حداکثر {MAX_BOTS_PER_USER} بات می‌تواند بسازد."
        )

    # -------------------------------------------------
    # ساخت بات جدید
    # -------------------------------------------------
    cur = conn.execute("""
        INSERT INTO bots
        (
            telegram_user_id,
            token,
            room_id,
            owner_username,
            enabled
        )
        VALUES (?, ?, ?, ?, 0)
    """, (
        tg_user_id,
        token,
        room_id,
        owner_username,
    ))

    bot_id = cur.lastrowid

    conn.commit()
    conn.close()

    return bot_id

def set_enabled(bot_id, enabled):
    conn = db()
    conn.execute(
        "UPDATE bots SET enabled=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (1 if enabled else 0, bot_id),
    )
    conn.commit()
    conn.close()


def get_enabled_bots():
    conn = db()
    rows = conn.execute(
        "SELECT * FROM bots WHERE enabled=1 ORDER BY id"
    ).fetchall()
    conn.close()
    return rows


def add_admin(bot_id, user_id, username):
    conn = db()
    conn.execute("""
        INSERT OR REPLACE INTO admins(bot_id, user_id, username)
        VALUES (?, ?, ?)
    """, (
        bot_id,
        user_id,
        username,
    ))
    conn.commit()
    conn.close()


def remove_admin(bot_id, user_id):
    conn = db()
    conn.execute(
        "DELETE FROM admins WHERE bot_id=? AND user_id=?",
        (bot_id, user_id),
    )
    conn.commit()
    conn.close()


def get_admin_ids(bot_id):
    conn = db()
    rows = conn.execute(
        "SELECT user_id FROM admins WHERE bot_id=?",
        (bot_id,),
    ).fetchall()
    conn.close()
    return {r["user_id"] for r in rows}


# ---------------------------------------------------------
# ROOM LINK
# ---------------------------------------------------------

def parse_room_id(value):
    value = value.strip()

    if not value:
        return ""

    # ---------------------------------------------
    # لینک رسمی Highrise
    # ---------------------------------------------
    if value.startswith("https://high.rs/") or value.startswith("http://high.rs/"):

        try:
            parsed = urlparse(value)
            query = parse_qs(parsed.query)

            # ownedRoomId اولویت دارد
            if "ownedRoomId" in query:
                room_id = query["ownedRoomId"][0].strip()

                if ROOM_ID_RE.fullmatch(room_id):
                    return room_id

                return ""

            # بعضی لینک‌ها فقط id دارند
            if "id" in query:
                room_id = query["id"][0].strip()

                if ROOM_ID_RE.fullmatch(room_id):
                    return room_id

                return ""

        except Exception:
            return ""

    # ---------------------------------------------
    # خود Room ID
    # ---------------------------------------------
    if ROOM_ID_RE.fullmatch(value):
        return value

    return ""


# ---------------------------------------------------------
# HIGHRISE BOT
# ---------------------------------------------------------

class HighriseBot(BaseBot):

    def __init__(self):
        super().__init__()

        self.bot_id = os.getenv("LINUXX_BOT_ID", "")
        self.owner_username = os.getenv(
            "LINUXX_OWNER_USERNAME",
            "",
        ).strip().lstrip("@")

        self.admin_ids = set()

        self.users = {}

        self.loop_task = None
        self.loop_text = None
        self.loop_delay = None
        self.pending_loop_text = None
        self.pending_loop_user = None
        self.positions = {}

        self.frozen = {}
        self.muted = set()

        self.movement_task = None
        self.floss_task = None
        self.adbot_dance_tasks = {}
        self.adbot_user_dances = {}


        self.running = True

    # -----------------------------------------------------
    # DATABASE / ADMINS
    # -----------------------------------------------------

    def load_admins(self):
        if not self.bot_id:
            return

        self.admin_ids = get_admin_ids(int(self.bot_id))

    def is_admin(self, user_id):
        if str(user_id) in self.admin_ids:
            return True

        # مالک بات همیشه مدیر اصلی است.
        user = self.users.get(str(user_id))

        if user:
            return (
                user.username.lower().lstrip("@")
                == self.owner_username.lower()
            )

        return False

    # -----------------------------------------------------
    # USER CACHE
    # -----------------------------------------------------

    async def refresh_users(self):
        try:
            response = await self.highrise.get_room_users()

            content = getattr(response, "content", None)

            if not content:
                return

            for item in content:
                try:
                    user = item[0]
                    position = item[1]

                    self.users[str(user.id)] = user

                    if position is not None:
                        self.positions[str(user.id)] = position

                except Exception:
                    continue

            print(
                f"[USERS] loaded {len(self.users)} users"
            )

        except Exception as e:
            print("[USERS ERROR]", e)

    def find_user(self, text):
        text = text.strip()

        if text.startswith("@"):
            text = text[1:]

        # ID مستقیم
        for uid, user in self.users.items():
            if uid == text:
                return user

        # username
        for user in self.users.values():
            if user.username.lower() == text.lower():
                return user

        return None

    # -----------------------------------------------------
    # START
    # -----------------------------------------------------

    # محل‌های ذخیره‌شده ادمین
    def _ensure_locations(self):
        if not hasattr(self, "admin_locations"):
            self.admin_locations = {}

    async def on_start(self, session_metadata):
        print("[HIGHRISE] connected")

        self.load_admins()

        # مهم:
        # کاربران موجود قبل از ورود بات را هم می‌خوانیم.
        await self.refresh_users()

        try:
            await self.highrise.chat(BOT_START_MESSAGE)
        except Exception:
            pass

        # Floss loop
        if self.floss_task is None:
            self.floss_task = asyncio.create_task(
                self.floss_loop()
            )

    # -----------------------------------------------------
    # AD-BOT DANCE ENGINE
    # -----------------------------------------------------

    async def stop_adbot_dance(self, user):
        uid = str(user.id)
        self.adbot_user_dances.pop(uid, None)
        task = self.adbot_dance_tasks.pop(uid, None)
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                print("[DANCE STOP ERROR]", e)

    async def start_adbot_dance(self, user, emote_id):
        uid = str(user.id)
        await self.stop_adbot_dance(user)
        self.adbot_user_dances[uid] = emote_id
        sleep_time = dance_duration(emote_id) + 1.0

        async def dance_loop():
            try:
                while self.adbot_user_dances.get(uid) == emote_id:
                    await self.highrise.send_emote(emote_id, uid)
                    await asyncio.sleep(sleep_time)
            except asyncio.CancelledError:
                return
            except Exception as e:
                print("[DANCE ERROR]", emote_id, type(e).__name__, e)

        self.adbot_dance_tasks[uid] = asyncio.create_task(dance_loop())

    # -----------------------------------------------------
    # USER JOIN
    # -----------------------------------------------------

    async def on_user_join(self, user, position):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = position

        print(
            f"[JOIN] @{user.username} [{uid}]"
        )

        try:
            await self.highrise.chat(
                f"<#00CCFF>👋 خوش آمدی @{user.username}"
            )
        except Exception:
            pass

    # -----------------------------------------------------
    # USER LEAVE
    # -----------------------------------------------------

    async def on_user_leave(self, user):
        uid = str(user.id)

        self.users.pop(uid, None)
        self.positions.pop(uid, None)

        # frozen را پاک نمی‌کنیم تا اگر دوباره برگشت
        # بتوانیم دوباره کنترلش کنیم.

    # -----------------------------------------------------
    # USER MOVE / FREEZE
    # -----------------------------------------------------

    async def on_user_move(self, user, destination):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = destination

        if uid in self.frozen:
            old_position = self.frozen[uid]

            try:
                await self.highrise.teleport(
                    uid,
                    old_position,
                )
            except Exception as e:
                print("[FREEZE ERROR]", e)

    # -----------------------------------------------------
    # CHAT
    # -----------------------------------------------------


# === LINUXX_COMMAND_FIX_V4 ===

    async def _lx_room_users(self):
        try:
            result = await self.highrise.get_room_users()
            return getattr(result, "content", []) or []
        except Exception as e:
            print("[ROOM USERS ERROR]", repr(e))
            return []

    async def _lx_find_user(self, username):
        username = username.strip().lstrip("@").lower()

        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if str(u.username).lower() == username:
                    return u, pos
            except Exception:
                continue

        return None, None

    async def _lx_my_position(self, user_id):
        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if u.id == user_id:
                    return pos
            except Exception:
                continue

        return None

    async def _lx_send(self, text):
        try:
            await self.highrise.chat(text)
        except Exception as e:
            print("[CHAT ERROR]", repr(e))

    async def _lx_command_fix(self, user, message):

        msg = str(message).strip()
        parts = msg.split()

        if not parts:
            return False

        low = msg.lower()

        # ============================================================
        # !بیا @id
        # ============================================================
        if low.startswith("!بیا "):

            if len(parts) < 2:
                await self._lx_send("❌ فرمت: !بیا @id")
                return True

            target, _ = await self._lx_find_user(parts[1])

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            my_pos = await self._lx_my_position(user.id)

            if my_pos is None:
                await self._lx_send("❌ موقعیت شما پیدا نشد.")
                return True

            try:
                await self.highrise.teleport(target.id, my_pos)

                await self._lx_send(
                    f"✅ @{target.username} به موقعیت شما منتقل شد."
                )

            except Exception as e:
                print("[BRING ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !برو به @id نام محل
        # ============================================================
        if low.startswith("!برو به "):

            if len(parts) < 3:
                await self._lx_send(
                    "❌ فرمت: !برو به @id نام محل"
                )
                return True

            target_name = parts[2]
            location_name = self._normalize_location_name(" ".join(parts[3:]))

            if not location_name:
                await self._lx_send(
                    "❌ نام محل را وارد کن."
                )
                return True

            target, _ = await self._lx_find_user(target_name)

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            locations = getattr(self, "admin_locations", {})

            position = locations.get(self._normalize_location_name(location_name))

            # اگر کلید دقیق نبود، مقایسه نرمال‌شده
            if position is None:
                for _name, _pos in locations.items():
                    if self._normalize_location_name(_name) == self._normalize_location_name(location_name):
                        position = _pos
                        break

            # پشتیبانی از حروف بزرگ/کوچک
            if position is None:
                for key, value in locations.items():
                    if str(key).lower() == location_name:
                        position = value
                        break

            if position is None:
                await self._lx_send(
                    f"<#FF4444>❌ موقعیت <#FFD700>«{location_name}» <#FF4444>پیدا نشد."
                )
                return True

            try:
                await self.highrise.teleport(
                    target.id,
                    position
                )

                await self._lx_send(
                    f"✅ @{target.username} به «{location_name}» منتقل شد."
                )

            except Exception as e:
                print("[GOTO ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !تیپ
        #
        # پشتیبانی:
        # !تیپ ۱ @id
        # !تیپ ۱ همه
        # !تیپ همه ۱
        # ============================================================
        if low.startswith("!تیپ "):

            args = parts[1:]

            if len(args) < 2:
                await self._lx_send(
                    "❌ فرمت:\n!تیپ ۱ @id\n!تیپ ۱ همه\n!تیپ همه ۱"
                )
                return True

            # تبدیل اعداد فارسی
            trans = str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789"
            )

            def number(x):
                try:
                    return int(str(x).translate(trans))
                except Exception:
                    return None

            amount = None
            target_arg = None

            # !تیپ همه ۱
            if str(args[0]).lower() == "همه":
                amount = number(args[1])
                target_arg = "همه"

            # !تیپ ۱ همه
            else:
                amount = number(args[0])
                target_arg = args[1]

            allowed = {
                1: "gold_bar_1",
                5: "gold_bar_5",
                10: "gold_bar_10",
                50: "gold_bar_50",
                100: "gold_bar_100",
                500: "gold_bar_500",
                1000: "gold_bar_1k",
                5000: "gold_bar_5000",
                10000: "gold_bar_10k",
            }

            if amount not in allowed:
                await self._lx_send(
                    "❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return True

            gold_bar = allowed[amount]

            # ========================================================
            # TIP ALL
            # ========================================================
            if str(target_arg).lower() == "همه":

                users = await self._lx_room_users()

                success = 0
                failed = 0

                for item in users:

                    try:
                        target = item[0]

                        # خود بات
                        if getattr(self, "bot_id", None):
                            if target.id == self.bot_id:
                                continue

                        # مالک/دستوردهنده هم طبق دستور تیپ می‌گیرد
                        try:
                            await self.highrise.tip_user(
                                target.id,
                                gold_bar
                            )
                            success += 1

                        except Exception as e:
                            failed += 1
                            print(
                                f"[TIP ALL ERROR] "
                                f"@{target.username}: {e}"
                            )

                    except Exception:
                        failed += 1

                await self._lx_send(
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {success}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return True

            # ========================================================
            # TIP ONE
            # ========================================================
            target, _ = await self._lx_find_user(target_arg)

            if target is None:
                await self._lx_send(
                    "❌ کاربر پیدا نشد."
                )
                return True

            try:
                await self.highrise.tip_user(
                    target.id,
                    gold_bar
                )

                await self._lx_send(
                    f"💰 {amount} تیپ به "
                    f"@{target.username} ارسال شد."
                )

            except Exception as e:
                print("[TIP ERROR]", repr(e))
                await self._lx_send(
                    "❌ ارسال تیپ انجام نشد."
                )

            return True

        return False



    def _normalize_location_name(self, name):
        if not name:
            return ""
        return " ".join(str(name).strip().lower().split())

    async def on_chat(self, user, message):
        # === LINUXX_COMMAND_FIX_CALL ===
        try:
            if await self._lx_command_fix(user, message):
                return
        except Exception as e:
            print('[COMMAND FIX ERROR]', repr(e))
        uid = str(user.id)

        self.users[uid] = user

        text = message.strip()

        if not text:
            return

        print(
            f"[CHAT] @{user.username}: {text}"
        )

        # -----------------------------------------------
        # AD-BOT DANCE / EMOTE
        # -----------------------------------------------

        normalized = text.translate(
            str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789",
            )
        )

        emote_id = resolve_emote(normalized)

        if emote_id:
            try:
                await self.start_adbot_dance(user, emote_id)
            except Exception as e:
                print("[DANCE START ERROR]", e)
            return

        if normalized.lower() in (
            "stop",
            "dance stop",
            "!stop",
            "!dance stop",
            "توقف",
            "توقف دنس",
        ):
            await self.stop_adbot_dance(user)
            return

        # -----------------------------------------------
        # TASE
        # -----------------------------------------------

        if text == "!تاس":
            number = random.randint(1, 6)

            await self.highrise.chat(
                f"<#FFD700>🎲 نتیجه تاس: {number}"
            )

            return

        # -----------------------------------------------
        # COMMANDS
        # -----------------------------------------------

        if text == "!دستورات":

            # -------------------------------------------
            # دستورات عمومی — برای همه کاربران
            # -------------------------------------------

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\\n"
                "<#FFD700>📖 دستورات عمومی\\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\\n"
                "<#FFFFFF>!تاس\\n"
                "<#FFFFFF>!دستورات\\n"
                "<#FFFFFF>!ایده و اجرا\\n"
                "<#FFFFFF>نام محل عمومی = تلپورت به محل\\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            # -------------------------------------------
            # دستورات مدیریتی — فقط مدیر و ادمین
            # -------------------------------------------

            if self.is_admin(uid):

                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>━━━━━━━━━━━━━━━━━━━━\\n"
                    "<#FFD700>👑 دستورات مدیریتی\\n"
                    "<#FFFFFF>!لباس\\n"
                    "<#FFFFFF>!لباس @id\\n"
                    "<#FFFFFF>!کیک @id\\n"
                    "<#FFFFFF>!فریز @id\\n"
                    "<#FFFFFF>!انفریز @id\\n"
                    "<#FFFFFF>!ادمین @id\\n"
                    "<#FFFFFF>!حذف ادمین @id\\n"
                    "<#FFFFFF>!موت @id\\n"
                    "<#FFFFFF>!انموت @id\\n"
                    "<#FFFFFF>!حرکت\\n"
                    "<#FFFFFF>!حرکت توقف\\n"
                    "<#FFFFFF>!بات\\n"
                    "<#FFFFFF>!محل ذخیره ادمین نام\\n"
                    "<#FFFFFF>!ذخیره محل عمومی نام\\n"
                    "<#FFFFFF>!لوپ متن\\n"
                    "<#FFFFFF>!لوپ ثانیه\\n"
                    "<#FFFFFF>!اسپم تعداد متن\\n"
                    "<#FFD700>━━━━━━━━━━━━━━━━━━━━"
                )

            return

        # -----------------------------------------------
        # ADMIN CHECK
        # -----------------------------------------------

        admin_commands = (
            text.startswith("!لباس")
            or text.startswith("!کیک")
            or text.startswith("!فریز")
            or text.startswith("!انفریز")
            or text.startswith("!ادمین")
            or text.startswith("!حذف ادمین")
            or text.startswith("!موت")
            or text.startswith("!انموت")
            or text == "!حرکت"
            or text == "!حرکت توقف"
            or text == "!بات"
            or text.startswith("!محل ذخیره ادمین ")
            or text.startswith("!ذخیره محل عمومی ")
            or text.startswith("!لوپ ")
            or text.startswith("!اسپم ")
            or text == "!موجودی"
            or text.startswith("!تیپ ")
        )

        if admin_commands and not self.is_admin(uid):
            await self.highrise.send_whisper(
                uid,
                "<#FF5555>❌ شما مدیر بات نیستید."
            )
            return

        # -----------------------------------------------
        # BOT - COME TO ADMIN
        # -----------------------------------------------

        if text == "!بات":

            position = self.positions.get(uid)

            if position is None:
                await self.highrise.chat(
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            try:
                await self.highrise.walk_to(position)

                await self.highrise.chat(
                    "<#00FF88>🤖 بات به محل شما آمد."
                )

            except Exception as e:
                print("[BOT MOVE ERROR]", repr(e))

                await self.highrise.chat(
                    "<#FF5555>❌ خطا در حرکت بات."
                )

            return

        # -----------------------------------------------
        # OUTFIT
        # -----------------------------------------------

        if text == "!لباس":

            try:
                outfit_response = (
                    await self.highrise.get_user_outfit(
                        uid
                    )
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if outfit:
                    result = await self.highrise.set_outfit(
                        list(outfit)
                    )

                    if result is not None:
                        print(
                            "[OUTFIT RESULT]",
                            result,
                        )

                    await self.highrise.chat(
                        "<#00FF88>👕 لباس با موفقیت کپی شد."
                    )

                else:
                    await self.highrise.send_whisper(
                        uid,
                        "لباس کاربر پیدا نشد."
                    )

            except Exception as e:
                print("[OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"خطا در کپی لباس: {e}"
                )

            return

        # -----------------------------------------------
        # LINUXX GOLD TIP SYSTEM
        # -----------------------------------------------

        TIP_BARS = {
            1: "gold_bar_1",
            5: "gold_bar_5",
            10: "gold_bar_10",
            50: "gold_bar_50",
            100: "gold_bar_100",
            500: "gold_bar_500",
            1000: "gold_bar_1k",
            5000: "gold_bar_5000",
            10000: "gold_bar_10k",
        }

        TIP_LABELS = {
            1: "۱",
            5: "۵",
            10: "۱۰",
            50: "۵۰",
            100: "۱۰۰",
            500: "۵۰۰",
            1000: "۱۰۰۰",
            5000: "۵۰۰۰",
            10000: "۱۰۰۰۰",
        }

        def get_gold_amount(wallet_response):
            total = 0

            try:
                content = getattr(
                    wallet_response,
                    "content",
                    []
                )

                for currency in content:
                    ctype = str(
                        getattr(currency, "type", "")
                    ).lower()

                    amount = int(
                        getattr(currency, "amount", 0)
                    )

                    # نسخه‌های مختلف SDK ممکن است نام Gold را
                    # کمی متفاوت برگردانند.
                    if (
                        ctype == "gold"
                        or "gold" in ctype
                    ):
                        total += amount

            except Exception as e:
                print("[TIP WALLET PARSE ERROR]", repr(e))

            return total

        async def get_bot_gold():
            try:
                wallet = await self.highrise.get_wallet()
                return get_gold_amount(wallet)
            except Exception as e:
                print("[TIP WALLET ERROR]", repr(e))
                return None

        # -----------------------------------------------
        # موجودی گلد
        # -----------------------------------------------

        if text == "!موجودی":

            gold = await get_bot_gold()

            if gold is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ دریافت موجودی گلد ناموفق بود."
                )
                return

            await self.highrise.send_whisper(
                uid,
                f"<#FFD700>💰 موجودی گلد بات: {gold}"
            )

            return

        # -----------------------------------------------
        # TIP
        #
        # !تیپ ۱ @id
        # !تیپ ۵ @id
        # !تیپ ۱۰ @id
        # !تیپ همه ۱
        # -----------------------------------------------

        if text.startswith("!تیپ "):

            parts = text.split()

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n"
                    "!تیپ ۱ @id\n"
                    "!تیپ ۵ @id\n"
                    "!تیپ همه ۱"
                )
                return

            # تبدیل اعداد فارسی به انگلیسی
            def normalize_number(value):
                return value.translate(
                    str.maketrans(
                        "۰۱۲۳۴۵۶۷۸۹",
                        "0123456789"
                    )
                )

            # -------------------------------------------
            # TIP ALL
            # -------------------------------------------

            if parts[1] == "همه":

                amount_text = normalize_number(
                    parts[2]
                )

                if not amount_text.isdigit():
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار گلد نامعتبر است."
                    )
                    return

                amount = int(amount_text)

                if amount not in TIP_BARS:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار مجاز:\n"
                        "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                        "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                    )
                    return

                try:
                    room_response = (
                        await self.highrise.get_room_users()
                    )

                    room_users = getattr(
                        room_response,
                        "content",
                        []
                    )

                except Exception as e:
                    print(
                        "[TIP ROOM USERS ERROR]",
                        repr(e)
                    )

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ دریافت کاربران روم ناموفق بود."
                    )
                    return

                sent = 0
                failed = 0

                await self.highrise.chat(
                    f"<#FFD700>💰 شروع تیپ {TIP_LABELS[amount]} گلد به کاربران..."
                )

                for item in room_users:

                    target = getattr(
                        item,
                        "user",
                        item
                    )

                    target_id = getattr(
                        target,
                        "id",
                        None
                    )

                    target_username = getattr(
                        target,
                        "username",
                        "unknown"
                    )

                    if not target_id:
                        continue

                    # خود بات تیپ نشود
                    if str(target_id) == str(
                        getattr(self, "bot_id", "")
                    ):
                        continue

                    try:
                        wallet_gold = await get_bot_gold()

                        if wallet_gold is not None:
                            if wallet_gold < amount:
                                await self.highrise.send_whisper(
                                    uid,
                                    f"<#FF5555>🛑 موجودی تمام شد.\n"
                                    f"<#FFFFFF>تعداد ارسال موفق: {sent}"
                                )
                                return

                        result = await self.highrise.tip_user(
                            str(target_id),
                            TIP_BARS[amount]
                        )

                        if result == "success":

                            sent += 1

                            print(
                                f"[TIP] {amount} -> "
                                f"@{target_username}"
                            )

                            # مطابق منطق AD-BOT:
                            # بین ارسال‌های متوالی فاصله کوتاه
                            await asyncio.sleep(3)

                        elif result == "insufficient_funds":

                            await self.highrise.send_whisper(
                                uid,
                                f"<#FF5555>🛑 موجودی گلد کافی نیست.\n"
                                f"<#FFFFFF>ارسال موفق: {sent}"
                            )

                            return

                        else:

                            failed += 1

                            print(
                                "[TIP ERROR RESULT]",
                                result
                            )

                    except Exception as e:

                        failed += 1

                        print(
                            "[TIP USER ERROR]",
                            target_username,
                            repr(e)
                        )

                        # خطای یک کاربر باعث خراب شدن
                        # کل دستور نشود.
                        continue

                await self.highrise.send_whisper(
                    uid,
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {sent}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return

            # -------------------------------------------
            # TIP ONE USER
            # -------------------------------------------

            amount_text = normalize_number(
                parts[1]
            )

            if not amount_text.isdigit():

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار گلد باید عدد باشد."
                )
                return

            amount = int(amount_text)

            if amount not in TIP_BARS:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return

            target_name = parts[2].strip()

            target = self.find_user(
                target_name
            )

            if not target:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            wallet_gold = await get_bot_gold()

            if wallet_gold is not None and wallet_gold < amount:

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ موجودی کافی نیست.\n"
                    f"<#FFFFFF>موجودی: {wallet_gold}\n"
                    f"<#FFFFFF>مورد نیاز: {amount}"
                )
                return

            try:

                result = await self.highrise.tip_user(
                    str(target.id),
                    TIP_BARS[amount]
                )

                if result == "success":

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>✅ {TIP_LABELS[amount]} گلد "
                        f"به @{target.username} تیپ شد."
                    )

                elif result == "insufficient_funds":

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ موجودی گلد کافی نیست."
                    )

                else:

                    await self.highrise.send_whisper(
                        uid,
                        f"<#FF5555>❌ تیپ انجام نشد.\n"
                        f"نتیجه: {result}"
                    )

            except Exception as e:

                print(
                    "[TIP USER ERROR]",
                    repr(e)
                )

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ خطا هنگام ارسال گلد."
                )

            return

        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):
            parts = command.split(maxsplit=1)

            if len(parts) < 2:
                return None

            return self.find_user(parts[1])

        # -----------------------------------------------
        # KICK
        # -----------------------------------------------

        if text.startswith("!کیک "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "kick",
                )

                await self.highrise.chat(
                    f"<#FF5555>👢 @{target.username} کیک شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # FREEZE
        # -----------------------------------------------

        if text.startswith("!فریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            position = self.positions.get(
                target_id
            )

            if position is None:
                await self.refresh_users()
                position = self.positions.get(
                    target_id
                )

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ موقعیت کاربر پیدا نشد."
                )
                return

            self.frozen[target_id] = position

            await self.highrise.chat(
                f"<#00CCFF>🧊 @{target.username} فریز شد."
            )

            return

        # -----------------------------------------------
        # UNFREEZE
        # -----------------------------------------------

        if text.startswith("!انفریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            self.frozen.pop(
                str(target.id),
                None,
            )

            await self.highrise.chat(
                f"<#00FF88>🔓 @{target.username} انفریز شد."
            )

            return

        # -----------------------------------------------
        # MUTE
        # -----------------------------------------------

        if text.startswith("!موت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "mute",
                )

                self.muted.add(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#FFAA00>🔇 @{target.username} موت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # UNMUTE
        # -----------------------------------------------

        if text.startswith("!انموت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "unmute",
                )

                self.muted.discard(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#00FF88>🔊 @{target.username} انموت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # ADD ADMIN
        # -----------------------------------------------

        if text.startswith("!ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            add_admin(
                int(self.bot_id),
                target_id,
                target.username,
            )

            self.admin_ids.add(
                target_id
            )

            await self.highrise.chat(
                f"<#FFD700>👑 @{target.username} مدیر شد."
            )

            return

        # -----------------------------------------------
        # REMOVE ADMIN
        # -----------------------------------------------

        if text.startswith("!حذف ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            remove_admin(
                int(self.bot_id),
                target_id,
            )

            self.admin_ids.discard(
                target_id
            )

            await self.highrise.chat(
                f"<#FF5555>❌ @{target.username} از مدیریت حذف شد."
            )

            return

        # -----------------------------------------------
        # EXTRA LOCATION / LOOP / SPAM / OUTFIT COMMANDS
        # -----------------------------------------------

        # !ایده و اجرا
        if text == "!ایده و اجرا":
            await self.highrise.chat(
                "<#FFD700>💡 Idea and implementation by "
                "<#00CCFF>@84.43 "
                "<#FFFFFF>and "
                "<#00CCFF>@55._65"
            )
            return

        # ------------------------------------------------
        # !دستورات
        # ------------------------------------------------

        if text == "!دستورات":

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
                "<#FFD700>📖 دستورات عمومی\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\n"
                "<#FFFFFF>!تاس\n"
                "<#FFFFFF>!دستورات\n"
                "<#FFFFFF>!ایده و اجرا\n"
                "<#FFFFFF>محل‌های عمومی: نام محل\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            if self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>👑 دستورات مدیریتی\n"
                    "!لباس\n"
                    "!لباس @id\n"
                    "!کیک @id\n"
                    "!فریز @id\n"
                    "!انفریز @id\n"
                    "!ادمین @id\n"
                    "!حذف ادمین @id\n"
                    "!موت @id\n"
                    "!انموت @id\n"
                    "!موجودی\n"
                    "!تیپ ۱ @id\n"
                    "!تیپ ۵ @id\n"
                    "!تیپ همه ۱\n"
                    "!تیپ همه ۵\n"
                    "!حرکت\n"
                    "!حرکت توقف\n"
                    "!بات\n\n"
                    "📍 محل ادمین:\n"
                    "!محل ذخیره ادمین t1\n"
                    "t1\n\n"
                    "🌍 محل عمومی:\n"
                    "!ذخیره محل عمومی a1\n"
                    "a1\n\n"
                    "🔁 لوپ:\n"
                    "!لوپ سلام\n"
                    "!لوپ 1\n"
                    "!لوپ توقف\n\n"
                    "📢 اسپم:\n"
                    "!اسپم 100 سلام"
                )

            return

        # ------------------------------------------------
        # LOOP STOP
        # ------------------------------------------------

        if text == "!لوپ توقف":

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ را متوقف کند."
                )
                return

            await self._stop_loop()

            await self.highrise.chat(
                "<#FFD700>🛑 لوپ متوقف شد."
            )
            return

        # ------------------------------------------------
        # LOOP TEXT
        # ------------------------------------------------

        if text.startswith("!لوپ "):

            value = text[5:].strip()

            if not value:
                return

            # اگر فقط عدد باشد یعنی تعیین تأخیر
            if value.isdigit():

                if not self.is_admin(uid):
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ تنظیم کند."
                    )
                    return

                if not self.pending_loop_text:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FFD700>ابتدا بنویس:\n!لوپ متن دلخواه\n"
                        "مثال: !لوپ سلام"
                    )
                    return

                delay = float(value)

                if delay < 1:
                    delay = 1

                if delay > 3600:
                    delay = 3600

                loop_text = self.pending_loop_text
                self.pending_loop_text = None

                await self._start_loop(
                    loop_text,
                    delay,
                )

                await self.highrise.chat(
                    f"<#00FF88>🔁 لوپ شروع شد\n"
                    f"<#FFFFFF>متن: {loop_text}\n"
                    f"<#FFFFFF>تأخیر: {delay:g} ثانیه"
                )

                return

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ بسازد."
                )
                return

            self.pending_loop_text = value
            self.pending_loop_user = uid

            await self.highrise.send_whisper(
                uid,
                "<#FFD700>⏱ تأخیر لوپ را وارد کن.\n"
                "<#FFFFFF>مثال:\n"
                "!لوپ 1\n\n"
                "<#FFFFFF>برای ارسال هر ۱ ثانیه."
            )

            return

        # ------------------------------------------------
        # SPAM
        # ------------------------------------------------

        if text.startswith("!اسپم "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند اسپم ارسال کند."
                )
                return

            parts = text.split(maxsplit=2)

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n!اسپم 100 سلام"
                )
                return

            try:
                count = int(
                    parts[1].translate(
                        str.maketrans(
                            "۰۱۲۳۴۵۶۷۸۹",
                            "0123456789",
                        )
                    )
                )
            except Exception:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ تعداد پیام باید عدد باشد."
                )
                return

            spam_text = parts[2].strip()

            if count < 1:
                count = 1

            # جلوگیری از مقدارهای بسیار بزرگ
            if count > 500:
                count = 500

            for _ in range(count):
                try:
                    await self.highrise.chat(spam_text)
                except Exception as e:
                    print("[SPAM ERROR]", e)
                    break

            return

        # ------------------------------------------------
        # ADMIN SAVED LOCATION
        # !محل ذخیره ادمین t1
        # ------------------------------------------------

        if text.startswith("!محل ذخیره ادمین "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند محل ادمین ذخیره کند."
                )
                return

            name = text[len("!محل ذخیره ادمین "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["admin"] and len(locations["admin"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل ادمین قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["admin"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>📍 محل ادمین «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # PUBLIC SAVED LOCATION
        # !ذخیره محل عمومی a1
        # ------------------------------------------------

        if text.startswith("!ذخیره محل عمومی "):

            # فقط مدیر اصلی
            if str(user.username).lower() != "84.43":
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر اصلی بات می‌تواند محل عمومی ذخیره کند."
                )
                return

            name = text[len("!ذخیره محل عمومی "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["public"] and len(locations["public"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل عمومی قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["public"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>🌍 محل عمومی «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # TELEPORT TO SAVED LOCATION
        # ------------------------------------------------

        locations = self._load_locations()

        # محل ادمین فقط برای ادمین‌ها
        if text in locations["admin"]:

            if not self.is_admin(uid):
                return

            position = self._dict_to_position(
                locations["admin"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>📍 به محل ادمین «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[ADMIN TELEPORT ERROR]", e)

            return

        # محل عمومی برای همه
        if text in locations["public"]:

            position = self._dict_to_position(
                locations["public"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>🌍 به محل «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[PUBLIC TELEPORT ERROR]", e)

            return

        # ------------------------------------------------
        # OUTFIT FROM TARGET
        # !لباس @id
        # ------------------------------------------------

        if text.startswith("!لباس "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ شما مدیر بات نیستید."
                )
                return

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                outfit_response = await self.highrise.get_user_outfit(
                    str(target.id)
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if not outfit:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ لباس کاربر پیدا نشد."
                    )
                    return

                result = await self.highrise.set_outfit(
                    list(outfit)
                )

                await self.highrise.chat(
                    f"<#00FF88>👕 لباس @{target.username} روی بات اعمال شد."
                )

            except Exception as e:
                print("[COPY OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ خطا در کپی لباس: {e}"
                )

            return

        # -----------------------------------------------
        # MOVEMENT
        # -----------------------------------------------

        if text == "!حرکت":

            if self.movement_task:
                await self.highrise.send_whisper(
                    uid,
                    "بات در حال حرکت است."
                )
                return

            self.movement_task = asyncio.create_task(
                self.random_walk()
            )

            await self.highrise.chat(
                "<#00FF88>🚶 حرکت بات شروع شد."
            )

            return

        if text == "!حرکت توقف":

            if self.movement_task:
                self.movement_task.cancel()
                self.movement_task = None

            await self.highrise.chat(
                "<#FFD700>🛑 حرکت بات متوقف شد."
            )

            return


    # -----------------------------------------------------
    # LINUXX_EXTRA_COMMANDS_V2
    # SAVED LOCATIONS
    # -----------------------------------------------------

    def _locations_file(self):
        return BASE_DIR / f"locations_{self.bot_id}.json"

    def _load_locations(self):
        path = self._locations_file()

        try:
            if path.exists():
                data = json.loads(
                    path.read_text(encoding="utf-8")
                )
            else:
                data = {}
        except Exception:
            data = {}

        if not isinstance(data, dict):
            data = {}

        data.setdefault("admin", {})
        data.setdefault("public", {})

        return data

    def _save_locations(self, data):
        try:
            self._locations_file().write_text(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            return True
        except Exception as e:
            print("[LOCATION SAVE ERROR]", e)
            return False

    def _position_to_dict(self, position):
        if position is None:
            return None

        return {
            "x": getattr(position, "x", 0),
            "y": getattr(position, "y", 0),
            "z": getattr(position, "z", 0),
            "facing": getattr(position, "facing", "FrontRight"),
        }

    def _dict_to_position(self, data):
        if not data:
            return None

        try:
            return Position(
                float(data["x"]),
                float(data["y"]),
                float(data["z"]),
                data.get("facing", "FrontRight"),
            )
        except Exception as e:
            print("[LOCATION POSITION ERROR]", e)
            return None

    def _set_pending_loop(self, text):
        self.pending_loop_text = text
        self.pending_loop_user = None

    async def _start_loop(self, text, delay):
        if hasattr(self, "loop_task") and self.loop_task:
            self.loop_task.cancel()
            try:
                await self.loop_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_text = text
        self.loop_delay = delay

        async def loop_runner():
            try:
                while True:
                    await self.highrise.chat(self.loop_text)
                    await asyncio.sleep(self.loop_delay)

            except asyncio.CancelledError:
                return

            except Exception as e:
                print("[LOOP ERROR]", e)

        self.loop_task = asyncio.create_task(loop_runner())

    async def _stop_loop(self):
        task = getattr(self, "loop_task", None)

        if task:
            task.cancel()

            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_task = None

    # -----------------------------------------------------
    # EXTRA COMMANDS V2
    # -----------------------------------------------------

    # -----------------------------------------------------
    # RANDOM WALK
    # -----------------------------------------------------

    async def random_walk(self):

        # چند نقطه نمونه برای حرکت.
        # بعداً می‌توانیم نقاط مخصوص هر روم را از پنل تنظیم کنیم.
        points = [
            Position(0, 0, 0, "FrontRight"),
            Position(2, 0, 2, "FrontRight"),
            Position(-2, 0, 2, "FrontLeft"),
            Position(2, 0, -2, "BackRight"),
            Position(-2, 0, -2, "BackLeft"),
        ]

        try:
            while True:

                destination = random.choice(
                    points
                )

                try:
                    await self.highrise.walk_to(
                        destination
                    )
                except Exception as e:
                    print(
                        "[WALK ERROR]",
                        e
                    )

                await asyncio.sleep(
                    random.uniform(
                        3,
                        7,
                    )
                )

        except asyncio.CancelledError:
            return

    # -----------------------------------------------------
    # FLOSS LOOP
    # -----------------------------------------------------

    async def floss_loop(self):

        floss = resolve_emote("222") or "dance-floss"
        sleep_time = dance_duration(floss) + 1.0

        while self.running:

            try:
                await self.highrise.send_emote(floss)

            except asyncio.CancelledError:
                return

            except Exception as e:
                print("[FLOSS ERROR]", e)

                # صبر برای reconnect شدن Highrise
                await asyncio.sleep(5)
                continue

            await asyncio.sleep(sleep_time)

    # -----------------------------------------------------
    # PRIVATE MESSAGE
    # -----------------------------------------------------

    async def on_message(
        self,
        user_id,
        conversation_id,
        is_new_conversation,
    ):

        try:
            await self.highrise.send_message(
                conversation_id,
                PV_MESSAGE,
            )
        except Exception as e:
            print(
                "[PV ERROR]",
                e
            )


# ---------------------------------------------------------
# TELEGRAM MANAGER
# ---------------------------------------------------------



# =========================================================
# LINUXX AUTH SYSTEM
# =========================================================

AUTH_PASSWORD = "python botOrder.py"
AUTH_FILE = BASE_DIR / "telegram_auth.json"

def load_auth():
    import json

    if not AUTH_FILE.exists():
        return {}

    try:
        return json.loads(
            AUTH_FILE.read_text(encoding="utf-8")
        )
    except Exception:
        return {}

def save_auth(data):
    import json

    AUTH_FILE.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2
        ),
        encoding="utf-8"
    )

def auth_status(user_id):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    return user

def is_authorized(user_id):
    user = auth_status(user_id)

    return (
        user.get("authorized", False)
        and not user.get("blocked", False)
    )

def is_blocked(user_id):
    return auth_status(user_id).get(
        "blocked",
        False
    )

def check_password(user_id, password):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    if user.get("blocked"):
        return "blocked"

    if password == AUTH_PASSWORD:

        user["authorized"] = True
        user["attempts"] = 0
        user["blocked"] = False

        data[key] = user
        save_auth(data)

        return "ok"

    user["attempts"] = int(
        user.get("attempts", 0)
    ) + 1

    if user["attempts"] >= 3:

        user["blocked"] = True
        user["authorized"] = False

        data[key] = user
        save_auth(data)

        return "blocked"

    data[key] = user
    save_auth(data)

    return 3 - user["attempts"]



class TelegramManager:

    def __init__(self):
        self.processes = {}

    # -----------------------------------------------------
    # KEYBOARDS
    # -----------------------------------------------------

    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        if bot and bool(bot["enabled"]):
            toggle_text = "🔴 خاموش"
        else:
            toggle_text = "🟢 روشن"

        # این ReplyKeyboard است، نه InlineKeyboard.
        # بنابراین پایین صفحه و کنار کادر تایپ نمایش داده می‌شود.
        return ReplyKeyboardMarkup(
            [
                [
                    "⚙️ تنظیمات بات",
                    toggle_text,
                ]
            ],
            resize_keyboard=True,
            is_persistent=True,
            one_time_keyboard=False,
        )


    def keyboard(self, bot_id):
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🟢 روشن / 🔴 خاموش",
                    callback_data=f"toggle:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "⚙️ تنظیمات",
                    callback_data=f"settings:{bot_id}",
                )
            ],
            [
                InlineKeyboardButton(
                    "🔙 لیست بات‌ها",
                    callback_data="list",
                )
            ],
        ])

    def settings_keyboard(self, bot_id):

        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🔑 تغییر توکن",
                    callback_data=f"token:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "🌐 تغییر لینک/ID روم",
                    callback_data=f"room:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "👤 تغییر ID مدیر",
                    callback_data=f"manager:{bot_id}"
                )
            ],
            [
                InlineKeyboardButton(
                    "🔙 بازگشت",
                    callback_data=f"panel:{bot_id}"
                )
            ]
        ])

    # -----------------------------------------------------
    # TEXTS
    # -----------------------------------------------------

    def panel_text(self, row):
        status = "🟢 روشن" if row["enabled"] else "🔴 خاموش"

        return (
            "🤖 LinuxX Highrise Manager\n\n"
            f"بات #{row['id']}\n"
            f"وضعیت: {status}\n\n"
            f"🌐 Room: {row['room_id']}\n"
            f"👤 مالک: @{row['owner_username']}\n\n"
            "یکی از گزینه‌ها را انتخاب کن:"
        )

    def list_text(self, bots):
        if not bots:
            return (
                "🤖 LinuxX Highrise Manager\n\n"
                "هنوز هیچ باتی برای شما ثبت نشده است.\n\n"
                "برای ساخت اولین بات روی دکمه زیر بزن."
            )

        text = (
            "🤖 LinuxX Highrise Manager\n\n"
            f"ظرفیت بات‌ها: {len(bots)}/{MAX_BOTS}\n\n"
        )

        for row in bots:
            status = "🟢 روشن" if row["enabled"] else "🔴 خاموش"
            text += (
                f"بات #{row['id']} — {status}\n"
                f"مالک: @{row['owner_username']}\n\n"
            )

        return text

    # -----------------------------------------------------
    # START
    # -----------------------------------------------------

    async def start(self):

        if not TELEGRAM_TOKEN:
            print("ERROR: TELEGRAM_BOT_TOKEN is not set.")
            print(
                'export TELEGRAM_BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"'
            )
            return

        init_db()

        from telegram.request import HTTPXRequest

        # اتصال پایدارتر Telegram در Termux
        request = HTTPXRequest(
            connection_pool_size=20,
            connect_timeout=30.0,
            read_timeout=30.0,
            write_timeout=30.0,
            pool_timeout=30.0,
            http_version="1.1",
            httpx_kwargs={
                "transport": __import__("httpx").AsyncHTTPTransport(
                    retries=2
                )
            },
        )

        application = (
            Application.builder()
            .token(TELEGRAM_TOKEN)
            .request(request)
            .get_updates_request(request)
            .build()
        )

        application.add_handler(
            CommandHandler(
                "start",
                self.start_command,
            )
        )

        application.add_handler(
            CallbackQueryHandler(
                self.button,
            )
        )

        application.add_handler(
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                self.text_handler,
            )
        )

        # -------------------------------------------------
        # AUTO START
        # -------------------------------------------------

        for row in get_enabled_bots():

            print(
                "[AUTO START]",
                row["id"],
            )

            self.spawn(row)

        # -----------------------------------------------
        # SUPERVISOR
        # -----------------------------------------------
        # هر بات process مستقل دارد.
        # اگر یکی قطع شود، فقط همان بات restart می‌شود.

        asyncio.create_task(
            self.monitor_processes()
        )

        print("[TELEGRAM] manager started")
        print("[SUPERVISOR] monitoring enabled")

        await application.initialize()
        await application.start()
        await application.updater.start_polling()

        try:
            while True:
                await asyncio.sleep(3600)

        finally:
            await application.updater.stop()
            await application.stop()
            await application.shutdown()

    # -----------------------------------------------------
    # /START
    # -----------------------------------------------------

    async def start_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        user_id = update.effective_user.id

        context.user_data.clear()

        if is_blocked(user_id):

            await update.message.reply_text(
                "⛔ دسترسی شما به LinuxX Bot مسدود شده است."
            )

            return

        if not is_authorized(user_id):

            context.user_data["waiting_password"] = True

            await update.message.reply_text(
                "🔐 LinuxX Highrise System\n\n"
                "برای ورود به پنل رمز عبور را ارسال کن.\n"
                "⚠️ فقط ۳ تلاش مجاز است."
            )

            return

        bots = get_user_bots(user_id)

        await update.message.reply_text(
            "🟢 LinuxX Highrise Manager\n\n"
            "خوش آمدید 👑\n"
            "برای مدیریت بات از دکمه‌های زیر استفاده کن.",
            reply_markup=self.main_keyboard(bots),
        )

    # -----------------------------------------------------
    # BUTTONS
    # -----------------------------------------------------

    async def button(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        query = update.callback_query

        # -----------------------------------------------
        # SAFE CALLBACK ANSWER
        # جلوگیری از کرش برای Query قدیمی
        # -----------------------------------------------
        try:
            await query.answer()
        except BadRequest as e:
            if "Query is too old" in str(e) or "query id is invalid" in str(e):
                print("[CALLBACK] old/expired query ignored")
            else:
                print("[CALLBACK ERROR]", e)

        user_id = update.effective_user.id

        if is_blocked(user_id):

            await query.answer(
                "⛔ دسترسی شما مسدود شده است.",
                show_alert=True,
            )

            return

        if not is_authorized(user_id):

            await query.answer(
                "🔐 ابتدا رمز عبور را وارد کنید.",
                show_alert=True,
            )

            return

        data = query.data

        # -----------------------------------------------
        # LIST
        # -----------------------------------------------

        if data == "list":

            context.user_data.clear()

            bots = get_user_bots(
                update.effective_user.id
            )

            await query.edit_message_text(
                self.list_text(bots),
                reply_markup=self.main_keyboard(bots),
            )

            return

        # -----------------------------------------------
        # ADD BOT
        # -----------------------------------------------

        if data == "add_bot":

            bots = get_user_bots(
                update.effective_user.id
            )

            if len(bots) >= MAX_BOTS:

                await query.answer(
                    "ظرفیت ۵۰ بات پر شده است.",
                    show_alert=True,
                )

                return

            context.user_data.clear()

            context.user_data["setup"] = "token"

            await query.edit_message_text(
                "➕ افزودن بات\n\n"
                "🔑 توکن Highrise را ارسال کن:"
            )

            return

        # -----------------------------------------------
        # BOT PANEL
        # -----------------------------------------------

        if ":" not in data:
            return

        action, value = data.split(":", 1)

        try:
            bot_id = int(value)
        except ValueError:
            return

        row = get_bot(bot_id)

        # -------------------------------------------------
        # TOGGLE BEFORE BOT EXISTS
        # -------------------------------------------------

        if action == "toggle" and not row:

            context.user_data.clear()

            context.user_data["setup"] = "token"

            await query.edit_message_text(
                "➕ راه‌اندازی بات ۱\n\n"
                "🔑 مرحله ۱ از ۳\n"
                "توکن Highrise را ارسال کن:"
            )

            return

        if not row:

            await query.edit_message_text(
                "❌ بات هنوز راه‌اندازی نشده است.\n\n"
                "ابتدا روی «روشن کردن بات» بزن."
            )

            return

        # فقط مالک تلگرام همان بات اجازه مدیریت دارد.

        if (
            row["telegram_user_id"]
            != update.effective_user.id
        ):

            await query.answer(
                "⛔ این بات متعلق به شما نیست.",
                show_alert=True,
            )

            return

        # -----------------------------------------------
        # PANEL
        # -----------------------------------------------

        if action == "panel":

            context.user_data.clear()

            await query.edit_message_text(
                self.panel_text(row),
                reply_markup=self.keyboard(bot_id),
            )

            return

        # -----------------------------------------------
        # TOGGLE
        # -----------------------------------------------

        if action == "toggle":

            new_state = not bool(
                row["enabled"]
            )

            if new_state:

                set_enabled(
                    bot_id,
                    True,
                )

                fresh = get_bot(bot_id)

                self.spawn(fresh)

            else:

                set_enabled(
                    bot_id,
                    False,
                )

                self.stop(bot_id)

            fresh = get_bot(bot_id)

            status = (
                "🟢 روشن"
                if new_state
                else "🔴 خاموش"
            )

            await query.edit_message_text(
                f"وضعیت بات #{bot_id}: {status}",
                reply_markup=self.keyboard(bot_id),
            )

            return

        # -----------------------------------------------
        # SETTINGS
        # -----------------------------------------------

        if action == "settings":

            context.user_data.clear()

            await query.edit_message_text(
                "⚙️ تنظیمات بات ۱\n\n"
                f"🤖 بات: #{bot_id}\n"
                f"🌐 Room: {row['room_id']}\n"
                f"👤 مدیر: @{row['owner_username']}\n\n"
                "یکی از گزینه‌ها را انتخاب کن:",
                reply_markup=self.settings_keyboard(bot_id),
            )

            return

        # -----------------------------------------------
        # BACK FROM SETTINGS
        # -----------------------------------------------

        if action == "back":

            context.user_data.clear()

            fresh = get_bot(bot_id)

            await query.edit_message_text(
                self.panel_text(fresh),
                reply_markup=self.keyboard(bot_id),
            )

            return

        # -----------------------------------------------
        # EDIT TOKEN / ROOM / OWNER
        # -----------------------------------------------

        if action in (
            "token",
            "room",
            "manager",
        ):

            context.user_data.clear()

            context.user_data["edit_bot"] = bot_id
            context.user_data["edit_type"] = action

            labels = {

                "token":
                    "🔑 توکن جدید Highrise را ارسال کن:",

                "room":
                    "🌐 لینک یا کد روم جدید را ارسال کن:",

                "manager":
                    "👤 ID مدیر جدید را ارسال کن:",
            }

            await query.edit_message_text(
                labels[action]
            )

            return

    # -----------------------------------------------------
    # TEXT INPUT
    # -----------------------------------------------------

    async def text_handler(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ):

        if not update.message:
            return

        text = update.message.text.strip()

        if not text:
            return

        user_id = update.effective_user.id


        # وضعیت فعلی بات کاربر

        bots = get_user_bots(user_id)

        bot = bots[0] if bots else None

        # -----------------------------------------------
        # PASSWORD AUTH
        # -----------------------------------------------

        if is_blocked(user_id):

            await update.message.reply_text(
                "⛔ دسترسی شما به LinuxX Bot مسدود شده است."
            )

            return

        if context.user_data.get("waiting_password"):

            result = check_password(
                user_id,
                text,
            )

            context.user_data.clear()

            if result == "ok":

                bots = get_user_bots(user_id)

                await update.message.reply_text(
                    "🟢 LinuxX Highrise Manager\n\n"
                    "خوش آمدید 👑\n"
                    "برای مدیریت بات از دکمه‌های زیر استفاده کن.",
                    reply_markup=self.main_keyboard(bots),
                )

                return

            if result == "blocked":

                await update.message.reply_text(
                    "⛔ ۳ بار رمز اشتباه وارد شد.\n\n"
                    "دسترسی شما مسدود شد."
                )

                return

            await update.message.reply_text(
                f"❌ رمز اشتباه است.\n"
                f"⚠️ {result} تلاش باقی مانده."
            )

            context.user_data["waiting_password"] = True

            return

        if not is_authorized(user_id):

            context.user_data["waiting_password"] = True

            await update.message.reply_text(
                "🔐 ابتدا رمز عبور را وارد کن."
            )

            return

        # -----------------------------------------------
        # AUTO BOTTOM KEYBOARD
        # -----------------------------------------------
        # دکمه‌های ReplyKeyboard پایین صفحه
        # -----------------------------------------------

        text_normalized = text.strip()

        is_settings_button = text_normalized in (
            "⚙️ تنظیمات بات",
            "تنظیمات بات ⚙️",
            "⚙️ تنظیمات بات ۱",
            "تنظیمات بات",
            "تنظیمات بات ۱",
        )

        is_toggle_button = text_normalized in (
            "🟢 روشن",
            "روشن 🟢",
            "🔴 خاموش",
            "خاموش 🔴",
            "🟢 روشن بات",
            "🔴 خاموش بات",
            "🟢 روشن بات ۱",
            "🔴 خاموش بات ۱",
        )

        # -------------------------------------------------
        # تنظیمات بات
        # -------------------------------------------------

        if is_settings_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است."
                )
                return

            context.user_data.clear()
            context.user_data["settings_bot"] = bot["id"]

            await update.message.reply_text(
                "⚙️ تنظیمات بات\n\n"
                f"🤖 بات #{bot['id']}\n"
                f"🌐 Room: {bot['room_id']}\n"
                f"👤 مدیر: @{bot['owner_username']}\n\n"
                "برای تغییر اطلاعات، گزینه موردنظر را انتخاب کن."
            )

            return

        # -------------------------------------------------
        # روشن / خاموش
        # -------------------------------------------------

        if is_toggle_button:

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است.\n\n"
                    "ابتدا تنظیمات بات را کامل کن."
                )
                return

            token = str(bot["token"] or "").strip()
            room_id = str(bot["room_id"] or "").strip()
            manager_id = str(
                bot["manager_id"] or bot["owner_username"] or ""
            ).strip()

            if not token or not room_id or not manager_id:

                await update.message.reply_text(
                    "⚠️ ابتدا تنظیمات بات را کامل کن.\n\n"
                    "🔑 توکن Highrise\n"
                    "🌐 لینک یا ID روم\n"
                    "👤 ID مدیر"
                )
                return

            new_state = not bool(bot["enabled"])

            if new_state:

                try:
                    set_enabled(bot["id"], True)

                    fresh = get_bot(bot["id"])

                    self.spawn(fresh)

                    await update.message.reply_text(
                        "🟢 بات با موفقیت روشن شد.",
                        reply_markup=self.main_keyboard([fresh]),
                    )

                except Exception as e:

                    set_enabled(bot["id"], False)

                    await update.message.reply_text(
                        "❌ روشن کردن بات ناموفق بود.\n\n"
                        f"خطا: {e}",
                        reply_markup=self.main_keyboard(
                            [get_bot(bot["id"])]
                        ),
                    )

            else:

                set_enabled(bot["id"], False)
                self.stop(bot["id"])

                fresh = get_bot(bot["id"])

                await update.message.reply_text(
                    "🔴 بات خاموش شد.",
                    reply_markup=self.main_keyboard([fresh]),
                )

            return

        # حذف بات
        if text == "🗑 حذف بات ۱":

            if not bot:
                await update.message.reply_text(
                    "❌ باتی برای حذف وجود ندارد.",
                    reply_markup=self.main_keyboard([]),
                )
                return

            self.stop(bot["id"])

            conn = db()

            conn.execute(
                "DELETE FROM admins WHERE bot_id=?",
                (bot["id"],),
            )

            conn.execute(
                "DELETE FROM bots WHERE id=? AND telegram_user_id=?",
                (bot["id"], user_id),
            )

            conn.commit()
            conn.close()

            await update.message.reply_text(
                "🗑 بات ۱ حذف شد.\n\n"
                "اکنون می‌توانی یک بات جدید بسازی.",
                reply_markup=self.main_keyboard([]),
            )
            return

        # بروزرسانی
        if text == "🔄 بروزرسانی":

            bots = get_user_bots(user_id)

            await update.message.reply_text(
                "🔄 پنل بروزرسانی شد.",
                reply_markup=self.main_keyboard(bots),
            )
            return

        # بازگشت
        if text == "🔙 بازگشت":

            bots = get_user_bots(user_id)

            await update.message.reply_text(
                "🤖 LinuxX Highrise Manager",
                reply_markup=self.main_keyboard(bots),
            )
            return

        # تغییر توکن
        if text == "🔑 تغییر توکن":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "token"

            await update.message.reply_text(
                "🔑 توکن جدید Highrise را ارسال کن:"
            )
            return

        # تغییر روم
        if text == "🌐 تغییر لینک روم":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "room"

            await update.message.reply_text(
                "🌐 لینک یا کد روم جدید را ارسال کن:"
            )
            return

        # تغییر مدیر
        if text == "👤 تغییر ID مدیر":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "owner"

            await update.message.reply_text(
                "👤 ID یا نام کاربری مدیر جدید را ارسال کن:"
            )
            return

        # -----------------------------------------------
        # EDIT EXISTING BOT
        # -----------------------------------------------

        edit_bot = context.user_data.get(
            "edit_bot"
        )

        edit_type = context.user_data.get(
            "edit_type"
        )

        if edit_bot and edit_type:

            row = get_bot(edit_bot)

            if not row:
                context.user_data.clear()
                return

            if row["telegram_user_id"] != user_id:
                context.user_data.clear()
                return

            # -----------------------------------------------
            # TOKEN
            # -----------------------------------------------

            if edit_type == "token":

                if not TOKEN_RE.fullmatch(text):

                    await update.message.reply_text(
                        "❌ توکن نامعتبر است.\n\n"
                        "توکن Highrise باید دقیقاً ۶۴ کاراکتر "
                        "و فقط شامل a-z و 0-9 باشد.\n\n"
                        "🔒 توکن قبلی حفظ شد."
                    )

                    return

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET token=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        text,
                        edit_bot,
                    ),
                )

                conn.commit()
                conn.close()

            # -----------------------------------------------
            # ROOM
            # -----------------------------------------------

            elif edit_type == "room":

                room_id = parse_room_id(text)

                if (
                    not room_id
                    or not ROOM_ID_RE.fullmatch(room_id)
                ):

                    await update.message.reply_text(
                        "❌ لینک یا کد روم نامعتبر است.\n\n"
                        "لینک Highrise معتبر یا Room ID صحیح "
                        "ارسال کن.\n\n"
                        "🔒 روم قبلی حفظ شد."
                    )

                    return

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET room_id=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        room_id,
                        edit_bot,
                    ),
                )

                conn.commit()
                conn.close()

            # -----------------------------------------------
            # OWNER
            # -----------------------------------------------

            elif edit_type == "manager":

                manager_id = text.strip()

                if not manager_id or len(manager_id) < 5:

                    await update.message.reply_text(
                        "❌ ID مدیر نامعتبر است.\n\n"
                        "🔒 مقدار قبلی حفظ شد."
                    )

                    return

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET manager_id=?,
                        owner_username=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        manager_id,
                        manager_id,
                        edit_bot,
                    ),
                )

                conn.commit()
                conn.close()

            else:

                context.user_data.clear()
                return

            # -----------------------------------------------
            # RESTART IF BOT IS RUNNING
            # -----------------------------------------------

            fresh = get_bot(edit_bot)

            if fresh and fresh["enabled"]:

                self.stop(edit_bot)

                await asyncio.sleep(1)

                fresh = get_bot(edit_bot)

                self.spawn(fresh)

            context.user_data.clear()

            await update.message.reply_text(
                "✅ تنظیمات با موفقیت ذخیره شد.",
                reply_markup=self.keyboard(edit_bot),
            )

            return

        # -----------------------------------------------
        # NEW BOT SETUP
        # -----------------------------------------------

        setup = context.user_data.get(
            "setup"
        )

        if setup == "token":

            context.user_data["new_token"] = text
            context.user_data["setup"] = "room"

            await update.message.reply_text(
                "🌐 حالا لینک یا کد روم Highrise را ارسال کن:"
            )

            return

        if setup == "room":

            room_id = parse_room_id(text)

            if not room_id:

                await update.message.reply_text(
                    "❌ لینک/کد روم نامعتبر است."
                )

                return

            context.user_data["new_room"] = room_id
            context.user_data["setup"] = "manager"

            await update.message.reply_text(
                "👤 حالا ID مدیر Highrise این بات را ارسال کن:"
            )

            return

        if setup == "manager":

            manager_id = text.strip()

            if not manager_id or len(manager_id) < 5:

                await update.message.reply_text(
                    "❌ ID مدیر نامعتبر است. دوباره ارسال کن."
                )

                return

            token = context.user_data.get(
                "new_token"
            )

            room_id = context.user_data.get(
                "new_room"
            )

            if not token or not room_id:

                context.user_data.clear()

                await update.message.reply_text(
                    "❌ اطلاعات ناقص است. دوباره /start را بزن."
                )

                return

            try:

                bot_id = create_or_update_bot(
                    user_id,
                    token,
                    room_id,
                    manager_id,
                )

                conn = db()

                conn.execute(
                    """
                    UPDATE bots
                    SET manager_id=?,
                        owner_username=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                    """,
                    (
                        manager_id,
                        manager_id,
                        bot_id,
                    ),
                )

                conn.commit()
                conn.close()

            except Exception as e:

                context.user_data.clear()

                await update.message.reply_text(
                    f"❌ خطا در ثبت بات:\n{e}"
                )

                return

            context.user_data.clear()

            # -------------------------------------------------
            # AUTO ENABLE AFTER FIRST SETUP
            # -------------------------------------------------

            set_enabled(bot_id, True)

            row = get_bot(bot_id)

            self.spawn(row)

            await update.message.reply_text(
                "✅ اطلاعات بات با موفقیت ثبت شد.\n\n"
                f"🤖 بات #{bot_id}\n"
                "🟢 وضعیت: روشن\n\n"
                "بات به‌صورت خودکار وارد روم می‌شود.",
                reply_markup=self.main_keyboard([row]),
            )

            return

    # -----------------------------------------------------
    # PROCESS MANAGEMENT
    # -----------------------------------------------------

    def spawn(self, row):

        bot_id = int(row["id"])

        process = self.processes.get(bot_id)

        if process and process.poll() is None:
            print("[ALREADY RUNNING]", bot_id)
            return

        env = os.environ.copy()

        env["LINUXX_BOT_ID"] = str(bot_id)

        env["LINUXX_OWNER_USERNAME"] = (
            row["owner_username"]
        )

        env["HIGHRISE_WORKER"] = "1"

        python = sys.executable

        cmd = [
            python,
            "-m",
            "highrise",
            "main:HighriseBot",
            row["room_id"],
            row["token"],
        ]

        print("[START BOT]", bot_id)

        try:

            process = subprocess.Popen(
                cmd,
                cwd=str(BASE_DIR),
                env=env,
                stdout=None,
                stderr=None,
            )

            self.processes[bot_id] = process

            print(
                "[BOT PROCESS STARTED]",
                bot_id,
                "PID=",
                process.pid,
            )

        except Exception as e:

            print(
                "[START ERROR]",
                bot_id,
                repr(e),
            )


    async def monitor_processes(self):

        print("[SUPERVISOR] started")

        restart_delay = {}

        while True:

            try:

                enabled_rows = get_enabled_bots()

                enabled_ids = {
                    int(row["id"])
                    for row in enabled_rows
                }

                # -----------------------------------------
                # بررسی بات‌های فعال
                # -----------------------------------------

                for row in enabled_rows:

                    bot_id = int(row["id"])

                    process = self.processes.get(bot_id)

                    # هنوز process ساخته نشده
                    if process is None:

                        delay = restart_delay.get(
                            bot_id,
                            0
                        )

                        if delay > 0:

                            restart_delay[bot_id] = max(
                                0,
                                delay - 2
                            )

                            continue

                        print(
                            "[SUPERVISOR] starting missing bot",
                            bot_id,
                        )

                        self.spawn(row)

                        restart_delay[bot_id] = 5

                        continue

                    # process هنوز زنده است
                    if process.poll() is None:

                        restart_delay[bot_id] = 0

                        continue

                    # process مرده
                    exit_code = process.returncode

                    print(
                        "[SUPERVISOR] bot stopped",
                        bot_id,
                        "exit=",
                        exit_code,
                    )

                    self.processes.pop(
                        bot_id,
                        None,
                    )

                    delay = restart_delay.get(
                        bot_id,
                        5
                    )

                    print(
                        "[SUPERVISOR] restarting bot",
                        bot_id,
                        "in",
                        delay,
                        "seconds",
                    )

                    restart_delay[bot_id] = min(
                        max(delay * 2, 5),
                        60
                    )

                # -----------------------------------------
                # پاک کردن processهای غیرفعال
                # -----------------------------------------

                for bot_id in list(
                    self.processes.keys()
                ):

                    if bot_id not in enabled_ids:

                        process = self.processes.get(
                            bot_id
                        )

                        if process:

                            if process.poll() is None:

                                print(
                                    "[SUPERVISOR] bot disabled",
                                    bot_id,
                                )

                                try:
                                    process.terminate()
                                except Exception:
                                    pass

                        self.processes.pop(
                            bot_id,
                            None,
                        )

                        restart_delay.pop(
                            bot_id,
                            None,
                        )

            except Exception as e:

                print(
                    "[SUPERVISOR ERROR]",
                    repr(e),
                )

            # مهم:
            # خطای یک بات نباید supervisor را متوقف کند.
            await asyncio.sleep(2)

    def stop(self, bot_id):

        process = self.processes.get(bot_id)

        if not process:
            return

        if process.poll() is None:

            try:

                process.terminate()

                try:

                    process.wait(
                        timeout=5
                    )

                except subprocess.TimeoutExpired:

                    process.kill()

            except Exception as e:

                print(
                    "[STOP ERROR]",
                    bot_id,
                    e,
                )

        self.processes.pop(
            bot_id,
            None,
        )



async def run_telegram():

    manager = TelegramManager()
    await manager.start()


if __name__ == "__main__":

    init_db()

    # وقتی highrise CLI این فایل را import می‌کند،
    # نباید پنل تلگرام دوم ساخته شود.
    if os.getenv("HIGHRISE_WORKER") == "1":
        pass

    else:
        asyncio.run(
            run_telegram()
        )
