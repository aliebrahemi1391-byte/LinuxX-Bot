from pathlib import Path
import re
import shutil

BASE = Path(__file__).resolve().parent
MAIN = BASE / "main.py"

if not MAIN.exists():
    print("❌ main.py پیدا نشد")
    raise SystemExit(1)

# ---------------------------------------------------------
# BACKUP
# ---------------------------------------------------------

backup = BASE / "main.py.before_auto_ui_fix.bak"
shutil.copy2(MAIN, backup)

s = MAIN.read_text(encoding="utf-8")

print("=" * 55)
print(" LinuxX AUTO UI FIX")
print("=" * 55)
print("📦 Backup:", backup.name)

# ---------------------------------------------------------
# 1. MAX BOTS PER USER = 1
# ---------------------------------------------------------

old = re.search(
    r"MAX_BOTS_PER_USER\s*=\s*\d+",
    s
)

if old:
    s = (
        s[:old.start()]
        + "MAX_BOTS_PER_USER = 1"
        + s[old.end():]
    )
    print("✅ حداکثر بات هر کاربر = 1")
else:
    print("⚠️ MAX_BOTS_PER_USER پیدا نشد")

# ---------------------------------------------------------
# 2. TELEGRAM IMPORT
# ---------------------------------------------------------

old_import = (
    "from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update"
)

new_import = """from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)"""

if old_import in s:
    s = s.replace(old_import, new_import, 1)
    print("✅ Telegram imports اصلاح شد")
elif "ReplyKeyboardMarkup" in s:
    print("ℹ️ ReplyKeyboardMarkup قبلاً وجود دارد")
else:
    print("❌ import تلگرام پیدا نشد")

# ---------------------------------------------------------
# 3. REPLACE main_keyboard
# ---------------------------------------------------------

start = s.find("    def main_keyboard(self, bots):")
end = s.find("    def keyboard(self, bot_id):", start)

if start == -1 or end == -1:
    print("❌ main_keyboard پیدا نشد")
    raise SystemExit(1)

new_keyboard = '''    def main_keyboard(self, bots):

        bot = bots[0] if bots else None

        if bot:

            status = (
                "🟢 روشن"
                if bot["enabled"]
                else "🔴 خاموش"
            )

            rows = [
                [
                    "⚙️ تنظیمات بات ۱",
                    f"{status} بات ۱",
                ],
                [
                    "🗑 حذف بات ۱",
                    "🔄 بروزرسانی",
                ],
            ]

        else:

            rows = [
                ["➕ ساخت بات ۱"]
            ]

        return ReplyKeyboardMarkup(
            rows,
            resize_keyboard=True,
            is_persistent=True,
            one_time_keyboard=False,
        )

'''

s = s[:start] + new_keyboard + s[end:]

print("✅ کیبورد پایین صفحه نصب شد")

# ---------------------------------------------------------
# 4. INSERT BOTTOM KEYBOARD HANDLER
# ---------------------------------------------------------

marker = '''        # -----------------------------------------------
        # EDIT EXISTING BOT
        # -----------------------------------------------
'''

if marker not in s:
    print("❌ محل text_handler پیدا نشد")
    raise SystemExit(1)

# جلوگیری از دوباره اضافه شدن
if "AUTO BOTTOM KEYBOARD" in s:
    print("ℹ️ بخش Bottom Keyboard قبلاً نصب شده")
else:

    handler = '''        # -----------------------------------------------
        # AUTO BOTTOM KEYBOARD
        # -----------------------------------------------

        bots = get_user_bots(user_id)
        bot = bots[0] if bots else None

        # ساخت بات
        if text == "➕ ساخت بات ۱":

            if bot:
                await update.message.reply_text(
                    "⚠️ شما قبلاً یک بات ساخته‌اید.\\n\\n"
                    "هر اکانت فقط اجازه ساخت ۱ بات را دارد.",
                    reply_markup=self.main_keyboard(bots),
                )
                return

            context.user_data.clear()
            context.user_data["setup"] = "token"

            await update.message.reply_text(
                "➕ ساخت بات ۱\\n\\n"
                "🔑 توکن Highrise را ارسال کن:"
            )
            return

        # تنظیمات
        if text == "⚙️ تنظیمات بات ۱":

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز هیچ باتی ساخته نشده است.",
                    reply_markup=self.main_keyboard(bots),
                )
                return

            await update.message.reply_text(
                "⚙️ تنظیمات بات ۱\\n\\n"
                f"🤖 بات #{bot['id']}\\n"
                f"🌐 Room: {bot['room_id']}\\n"
                f"👤 مدیر: @{bot['owner_username']}\\n\\n"
                "یکی از گزینه‌ها را انتخاب کن:",
                reply_markup=ReplyKeyboardMarkup(
                    [
                        ["🔑 تغییر توکن"],
                        ["🌐 تغییر لینک روم"],
                        ["👤 تغییر ID مدیر"],
                        ["🔙 بازگشت"],
                    ],
                    resize_keyboard=True,
                    is_persistent=True,
                    one_time_keyboard=False,
                ),
            )
            return

        # روشن / خاموش
        if text in ("🟢 روشن بات ۱", "🔴 خاموش بات ۱"):

            if not bot:
                await update.message.reply_text(
                    "❌ هنوز باتی ساخته نشده است.",
                    reply_markup=self.main_keyboard(bots),
                )
                return

            new_state = not bool(bot["enabled"])

            set_enabled(bot["id"], new_state)

            if new_state:
                fresh = get_bot(bot["id"])
                self.spawn(fresh)
            else:
                self.stop(bot["id"])

            fresh = get_bot(bot["id"])

            status = (
                "🟢 روشن"
                if fresh["enabled"]
                else "🔴 خاموش"
            )

            await update.message.reply_text(
                f"🤖 وضعیت بات ۱: {status}",
                reply_markup=self.main_keyboard([fresh]),
            )
            return

        # حذف بات
        if text == "🗑 حذف بات ۱":

            if not bot:
                await update.message.reply_text(
                    "❌ باتی برای حذف وجود ندارد.",
                    reply_markup=self.main_keyboard([]),
                )
                return

            self.stop(bot["id"])

            conn = db()

            conn.execute(
                "DELETE FROM admins WHERE bot_id=?",
                (bot["id"],),
            )

            conn.execute(
                "DELETE FROM bots WHERE id=? AND telegram_user_id=?",
                (bot["id"], user_id),
            )

            conn.commit()
            conn.close()

            await update.message.reply_text(
                "🗑 بات ۱ حذف شد.\\n\\n"
                "اکنون می‌توانی یک بات جدید بسازی.",
                reply_markup=self.main_keyboard([]),
            )
            return

        # بروزرسانی
        if text == "🔄 بروزرسانی":

            bots = get_user_bots(user_id)

            await update.message.reply_text(
                "🔄 پنل بروزرسانی شد.",
                reply_markup=self.main_keyboard(bots),
            )
            return

        # بازگشت
        if text == "🔙 بازگشت":

            bots = get_user_bots(user_id)

            await update.message.reply_text(
                "🤖 LinuxX Highrise Manager",
                reply_markup=self.main_keyboard(bots),
            )
            return

        # تغییر توکن
        if text == "🔑 تغییر توکن":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "token"

            await update.message.reply_text(
                "🔑 توکن جدید Highrise را ارسال کن:"
            )
            return

        # تغییر روم
        if text == "🌐 تغییر لینک روم":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "room"

            await update.message.reply_text(
                "🌐 لینک یا کد روم جدید را ارسال کن:"
            )
            return

        # تغییر مدیر
        if text == "👤 تغییر ID مدیر":

            if not bot:
                return

            context.user_data.clear()
            context.user_data["edit_bot"] = bot["id"]
            context.user_data["edit_type"] = "owner"

            await update.message.reply_text(
                "👤 ID یا نام کاربری مدیر جدید را ارسال کن:"
            )
            return

'''

    s = s.replace(marker, handler + marker, 1)

    print("✅ کنترل دکمه‌های پایین اضافه شد")

# ---------------------------------------------------------
# 5. SAVE
# ---------------------------------------------------------

MAIN.write_text(s, encoding="utf-8")

print("✅ main.py ذخیره شد")

# ---------------------------------------------------------
# 6. CHECK
# ---------------------------------------------------------

import py_compile

try:
    py_compile.compile(
        str(MAIN),
        doraise=True
    )
except Exception as e:
    print()
    print("❌ Syntax Error!")
    print(e)
    print()
    print("🔄 در حال برگرداندن بکاپ...")

    shutil.copy2(backup, MAIN)

    print("✅ main.py به نسخه قبل برگشت")
    raise SystemExit(1)

print()
print("=" * 55)
print("✅ اصلاح کامل شد")
print("=" * 55)
print("✅ هر کاربر فقط ۱ بات")
print("✅ دکمه‌ها پایین صفحه")
print("✅ تنظیمات بات ۱")
print("✅ روشن/خاموش بات ۱")
print("✅ حذف بات ۱")
print("✅ ساخت بات جدید بعد از حذف")
print("✅ تغییر توکن")
print("✅ تغییر لینک روم")
print("✅ تغییر ID مدیر")
print("✅ Syntax OK")
print("=" * 55)
print()
print("برای اجرا:")
print("python main.py")
