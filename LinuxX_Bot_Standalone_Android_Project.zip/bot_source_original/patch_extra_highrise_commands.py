from pathlib import Path
import shutil
import re

MAIN = Path("main.py")
BACKUP = Path("main.py.before_extra_commands.bak")
MARKER = "# === LINUXX EXTRA COMMANDS V1 ==="

if not MAIN.exists():
    raise SystemExit("❌ main.py پیدا نشد. این فایل را داخل ~/highrise/LinuxXBot قرار بده.")

s = MAIN.read_text(encoding="utf-8")

if MARKER in s:
    raise SystemExit("⚠️ این پچ قبلاً روی main.py اعمال شده؛ دوباره اجرا نکن.")

shutil.copy2(MAIN, BACKUP)

if "import json" not in s:
    s = s.replace("import asyncio\n", "import asyncio\nimport json\n", 1)

if "from pathlib import Path" not in s:
    s = "from pathlib import Path\n" + s

if "from highrise import Position" not in s:
    s = "from highrise import Position\n" + s

helpers = r"""
    # === LINUXX EXTRA COMMANDS V1 ===

    def _linuxx_room_key(self):
        return str(getattr(self, "_linuxx_room_id", "default"))

    def _linuxx_load_locations(self):
        path = Path("saved_locations.json")
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _linuxx_save_locations(self, data):
        Path("saved_locations.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _linuxx_position_to_dict(self, pos):
        if pos is None:
            return None
        return {
            "x": getattr(pos, "x", 0),
            "y": getattr(pos, "y", 0),
            "z": getattr(pos, "z", 0),
            "facing": getattr(pos, "facing", "FrontRight"),
        }

    def _linuxx_dict_to_position(self, data):
        return Position(
            data["x"],
            data["y"],
            data["z"],
            data.get("facing", "FrontRight"),
        )

    def _linuxx_is_owner(self, uid, username=""):
        uid = str(uid)
        owner_id = str(
            globals().get(
                "OWNER_ID",
                "66b75164e15543699b01ffad",
            )
        )
        return (
            uid == owner_id
            or str(username).lower().lstrip("@") == "84.43"
        )

    def _linuxx_is_admin(self, uid, username=""):
        if self._linuxx_is_owner(uid, username):
            return True

        try:
            return bool(self.is_admin(uid))
        except Exception:
            pass

        admins = getattr(self, "admins", set())

        if isinstance(admins, dict):
            admins = admins.keys()

        admins = {str(x).lower().lstrip("@") for x in admins}

        return (
            str(uid) in admins
            or str(username).lower().lstrip("@") in admins
        )

    def _linuxx_find_user(self, target):
        target = str(target).strip().lstrip("@")
        for uid, user_obj in getattr(self, "users", {}).items():
            if str(uid) == target:
                return user_obj
            if str(getattr(user_obj, "username", "")).lower() == target.lower():
                return user_obj
        return None

    async def _linuxx_start_loop(self, owner_uid, message_text, delay):
        tasks = getattr(self, "_linuxx_loop_tasks", {})
        old = tasks.get(str(owner_uid))

        if old:
            old.cancel()

        async def runner():
            try:
                while True:
                    await self.highrise.chat(message_text)
                    await asyncio.sleep(delay)
            except asyncio.CancelledError:
                return
            except Exception as e:
                print("[LOOP ERROR]", repr(e))

        tasks[str(owner_uid)] = asyncio.create_task(runner())
        self._linuxx_loop_tasks = tasks

    async def _linuxx_stop_loop(self, owner_uid):
        tasks = getattr(self, "_linuxx_loop_tasks", {})
        task = tasks.pop(str(owner_uid), None)
        if task:
            task.cancel()
            return True
        return False

    async def _linuxx_spam(self, count, message_text):
        count = min(max(int(count), 1), 100)
        for _ in range(count):
            try:
                await self.highrise.chat(message_text)
            except Exception as e:
                print("[SPAM ERROR]", repr(e))
                break
            await asyncio.sleep(0.05)

    async def _linuxx_teleport_saved(self, user_id, location):
        try:
            await self.highrise.teleport(
                str(user_id),
                self._linuxx_dict_to_position(location),
            )
            return True
        except Exception as e:
            print("[SAVED LOCATION ERROR]", repr(e))
            return False

    async def _linuxx_handle_extra_commands(self, user, text):
        uid = str(user.id)
        username = str(getattr(user, "username", ""))

        is_admin = self._linuxx_is_admin(uid, username)
        is_owner = self._linuxx_is_owner(uid, username)

        normalized = text.translate(
            str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
        )

        if text == "!دستورات":
            await self.highrise.chat(
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━\n"
                "<#00CCFF>📖 دستورات عمومی:\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\n"
                "!تاس\n"
                "!دستورات\n"
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━\n"
                "<#FF5555>👑 دستورات مدیریتی:\n"
                "<#FFFFFF>!لباس\n"
                "!لباس @id\n"
                "!کیک @id\n"
                "!فریز @id\n"
                "!انفریز @id\n"
                "!ادمین @id\n"
                "!حذف ادمین @id\n"
                "!موت @id\n"
                "!انموت @id\n"
                "!حرکت\n"
                "!حرکت توقف\n"
                "!بات\n"
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━\n"
                "<#00FF88>📍 محل ادمین:\n"
                "<#FFFFFF>!محل ذخیره ادمین NAME\n"
                "NAME = تلپورت به محل (فقط ادمین)\n"
                "<#00FF88>📍 محل عمومی:\n"
                "<#FFFFFF>!ذخیره محل عمومی NAME\n"
                "NAME = تلپورت به محل عمومی\n"
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━\n"
                "<#00CCFF>🔁 لوپ:\n"
                "<#FFFFFF>!لوپ متن\n"
                "!لوپ ۱\n"
                "!لوپ توقف\n"
                "<#FF5555>⚡ اسپم:\n"
                "<#FFFFFF>!اسپم ۱۰۰ متن\n"
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━\n"
                "<#00CCFF>💡 !ایده و اجرا\n"
                "<#FFFFFF>Idea and implementation by @84.43 and @55._65\n"
                "<#FFD700>━━━━━━━━━━━━━━━━━━━━"
            )
            return True

        if text == "!ایده و اجرا":
            await self.highrise.chat(
                "<#00CCFF>Idea and implementation by "
                "<#FFD700>@84.43 <#FFFFFF>and <#FFD700>@55._65"
            )
            return True

        m = re.fullmatch(r"!محل ذخیره ادمین\s+(\S+)", text)
        if m:
            if not is_admin:
                await self.highrise.send_whisper(
                    uid,
                    "❌ فقط ادمین‌ها اجازه ذخیره محل ادمین را دارند.",
                )
                return True

            name = m.group(1).strip()
            data = self._linuxx_load_locations()
            room = data.setdefault(
                self._linuxx_room_key(),
                {"admin": {}, "public": {}},
            )
            admin_locations = room.setdefault("admin", {})

            if name not in admin_locations and len(admin_locations) >= 3:
                await self.highrise.send_whisper(
                    uid,
                    "❌ حداکثر ۳ محل ادمین قابل ذخیره است.",
                )
                return True

            pos = getattr(self, "positions", {}).get(uid)
            if pos is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ موقعیت شما پیدا نشد؛ کمی حرکت کن و دوباره بزن.",
                )
                return True

            admin_locations[name] = self._linuxx_position_to_dict(pos)
            self._linuxx_save_locations(data)

            await self.highrise.chat(
                f"<#00FF88>📍 محل ادمین «{name}» ذخیره شد."
            )
            return True

        m = re.fullmatch(r"!ذخیره محل عمومی\s+(\S+)", text)
        if m:
            if not is_owner:
                await self.highrise.send_whisper(
                    uid,
                    "❌ فقط مدیر اصلی اجازه ذخیره محل عمومی را دارد.",
                )
                return True

            name = m.group(1).strip()
            data = self._linuxx_load_locations()
            room = data.setdefault(
                self._linuxx_room_key(),
                {"admin": {}, "public": {}},
            )
            public_locations = room.setdefault("public", {})

            if name not in public_locations and len(public_locations) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "❌ حداکثر ۵ محل عمومی قابل ذخیره است.",
                )
                return True

            pos = getattr(self, "positions", {}).get(uid)
            if pos is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ موقعیت شما پیدا نشد؛ کمی حرکت کن و دوباره بزن.",
                )
                return True

            public_locations[name] = self._linuxx_position_to_dict(pos)
            self._linuxx_save_locations(data)

            await self.highrise.chat(
                f"<#00FF88>📍 محل عمومی «{name}» ذخیره شد."
            )
            return True

        if (
            not text.startswith("!")
            and text.strip()
            and not normalized.isdigit()
        ):
            name = text.strip()
            data = self._linuxx_load_locations()
            room = data.get(
                self._linuxx_room_key(),
                {"admin": {}, "public": {}},
            )

            admin_locations = room.get("admin", {})
            public_locations = room.get("public", {})

            if is_admin and name in admin_locations:
                ok = await self._linuxx_teleport_saved(
                    uid,
                    admin_locations[name],
                )
                if ok:
                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>📍 به محل «{name}» منتقل شدی.",
                    )
                return True

            if name in public_locations:
                ok = await self._linuxx_teleport_saved(
                    uid,
                    public_locations[name],
                )
                if ok:
                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>📍 به محل «{name}» منتقل شدی.",
                    )
                return True

        if text.startswith("!لوپ"):
            if not is_admin:
                await self.highrise.send_whisper(
                    uid,
                    "❌ فقط ادمین‌ها اجازه استفاده از لوپ را دارند.",
                )
                return True

            arg = text[len("!لوپ"):].strip()

            if arg == "توقف":
                stopped = await self._linuxx_stop_loop(uid)
                await self.highrise.chat(
                    "<#FFD700>🛑 لوپ متوقف شد."
                    if stopped
                    else "<#FF5555>لوپی برای توقف فعال نیست."
                )
                return True

            arg_norm = arg.translate(
                str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
            )

            if arg_norm.isdigit():
                delay = int(arg_norm)

                if not 1 <= delay <= 3600:
                    await self.highrise.send_whisper(
                        uid,
                        "❌ تأخیر باید بین ۱ تا ۳۶۰۰ ثانیه باشد.",
                    )
                    return True

                pending = getattr(
                    self,
                    "_linuxx_pending_loop",
                    {},
                )
                message_text = pending.get(uid)

                if not message_text:
                    await self.highrise.send_whisper(
                        uid,
                        "❌ اول بنویس: !لوپ متن دلخواه",
                    )
                    return True

                await self._linuxx_start_loop(
                    uid,
                    message_text,
                    delay,
                )

                pending.pop(uid, None)
                self._linuxx_pending_loop = pending

                await self.highrise.chat(
                    f"<#00FF88>🔁 لوپ شروع شد | تأخیر: {delay} ثانیه"
                )
                return True

            if not arg:
                await self.highrise.send_whisper(
                    uid,
                    "مثال: !لوپ سلام",
                )
                return True

            pending = getattr(
                self,
                "_linuxx_pending_loop",
                {},
            )
            pending[uid] = arg
            self._linuxx_pending_loop = pending

            await self.highrise.chat(
                "<#FFD700>⏱ تأخیر لوپ را مشخص کن.\n"
                "<#FFFFFF>مثال: !لوپ ۱"
            )
            return True

        m = re.fullmatch(
            r"!اسپم\s+([0-9۰-۹]+)\s+(.+)",
            text,
        )
        if m:
            if not is_admin:
                await self.highrise.send_whisper(
                    uid,
                    "❌ فقط ادمین‌ها اجازه استفاده از اسپم را دارند.",
                )
                return True

            count = int(
                m.group(1).translate(
                    str.maketrans(
                        "۰۱۲۳۴۵۶۷۸۹",
                        "0123456789",
                    )
                )
            )
            message_text = m.group(2).strip()

            if not 1 <= count <= 100:
                await self.highrise.send_whisper(
                    uid,
                    "❌ تعداد اسپم باید بین ۱ تا ۱۰۰ باشد.",
                )
                return True

            await self.highrise.chat(
                f"<#FF5555>⚡ اسپم {count} پیام شروع شد."
            )
            asyncio.create_task(
                self._linuxx_spam(
                    count,
                    message_text,
                )
            )
            return True

        m = re.fullmatch(
            r"!لباس\s+(@?\S+)",
            text,
        )
        if m:
            if not is_admin:
                await self.highrise.send_whisper(
                    uid,
                    "❌ فقط ادمین‌ها اجازه تغییر لباس بات را دارند.",
                )
                return True

            target = self._linuxx_find_user(m.group(1))

            if target is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ کاربر پیدا نشد.",
                )
                return True

            try:
                outfit = await self.highrise.get_user_outfit(
                    str(target.id)
                )
                await self.highrise.set_outfit(outfit)

                await self.highrise.chat(
                    f"<#00FF88>👕 لباس @{target.username} روی بات کپی شد."
                )
            except Exception as e:
                print("[OUTFIT COPY ERROR]", repr(e))
                await self.highrise.send_whisper(
                    uid,
                    "❌ کپی لباس انجام نشد؛ ممکن است بعضی آیتم‌ها در موجودی بات نباشند.",
                )
            return True

        return False
"""

anchor = (
    "    # -----------------------------------------------------\n"
    "    # START\n"
    "    # -----------------------------------------------------\n\n"
    "    async def on_start"
)

if anchor not in s:
    raise SystemExit(
        "❌ بخش START در main.py پیدا نشد؛ هیچ تغییری اعمال نشد."
    )

s = s.replace(
    anchor,
    helpers + "\n" + anchor,
    1,
)

start_old = """    async def on_start(self, session_metadata):
        print("[HIGHRISE] connected")
"""

start_new = """    async def on_start(self, session_metadata):
        try:
            if isinstance(session_metadata, dict):
                self._linuxx_room_id = (
                    session_metadata.get("room_id")
                    or session_metadata.get("roomId")
                    or "default"
                )
            else:
                self._linuxx_room_id = (
                    getattr(session_metadata, "room_id", None)
                    or getattr(session_metadata, "roomId", None)
                    or "default"
                )
        except Exception:
            self._linuxx_room_id = "default"

        print("[HIGHRISE] connected")
"""

if start_old not in s:
    raise SystemExit(
        "❌ on_start در قالب مورد انتظار پیدا نشد؛ هیچ تغییری اعمال نشد."
    )

s = s.replace(start_old, start_new, 1)

chat_anchor = """        print(
            f"[CHAT] @{user.username}: {text}"
        )

        # -----------------------------------------------
        # DANCE
"""

chat_new = """        print(
            f"[CHAT] @{user.username}: {text}"
        )

        # === LINUXX EXTRA COMMANDS V1 DISPATCH ===
        if await self._linuxx_handle_extra_commands(user, text):
            return

        # -----------------------------------------------
        # DANCE
"""

if chat_anchor not in s:
    raise SystemExit(
        "❌ محل مناسب on_chat پیدا نشد؛ هیچ تغییری اعمال نشد."
    )

s = s.replace(chat_anchor, chat_new, 1)

MAIN.write_text(s, encoding="utf-8")

print("✅ پچ با موفقیت اعمال شد.")
print(f"✅ بکاپ: {BACKUP.name}")
print("✅ محل ادمین: حداکثر ۳")
print("✅ محل عمومی: حداکثر ۵ و فقط مدیر اصلی")
print("✅ لوپ + توقف لوپ")
print("✅ اسپم حداکثر ۱۰۰")
print("✅ !لباس @id برای کپی لباس کاربر روی بات")
print("✅ !ایده و اجرا")
print("✅ !دستورات با دستورات جدید")
print("✅ ذخیره دائمی در saved_locations.json")
