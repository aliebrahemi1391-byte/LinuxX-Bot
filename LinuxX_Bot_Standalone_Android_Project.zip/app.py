from kivy.app import App
from kivy.clock import Clock
from kivy.uix.widget import Widget
import threading, time, os
import main

class LinuxXApp(App):
    def build(self):
        threading.Thread(target=main.start_server,daemon=True).start()
        Clock.schedule_once(self.open_webview,1.2)
        return Widget()
    def open_webview(self,*args):
        try:
            from jnius import autoclass
            Activity=autoclass("org.kivy.android.PythonActivity")
            WebView=autoclass("android.webkit.WebView")
            a=Activity.mActivity
            w=WebView(a)
            w.getSettings().setJavaScriptEnabled(True)
            w.getSettings().setDomStorageEnabled(True)
            w.loadUrl("http://127.0.0.1:8765/")
            a.setContentView(w)
        except Exception as e:
            print("WEBVIEW ERROR:",repr(e))
if __name__=="__main__":
    LinuxXApp().run()
