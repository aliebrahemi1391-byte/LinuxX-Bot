import os
import re
import sys
import json
import sqlite3
import asyncio
import random
import subprocess
from pathlib import Path

TOKEN_RE = re.compile(r"^[a-z0-9]{64}$")
ROOM_ID_RE = re.compile(r'^[A-Za-z0-9]{20,64}$')
from urllib.parse import urlparse, parse_qs

from highrise import BaseBot, Position


class HighriseBot(BaseBot):

    def __init__(self):
        super().__init__()

        self.bot_id = os.getenv("LINUXX_BOT_ID", "")
        self.owner_username = os.getenv(
            "LINUXX_OWNER_USERNAME",
            "",
        ).strip().lstrip("@")

        self.admin_ids = set()

        self.users = {}

        self.loop_task = None
        self.loop_text = None
        self.loop_delay = None
        self.pending_loop_text = None
        self.pending_loop_user = None
        self.positions = {}

        self.frozen = {}
        self.muted = set()

        self.movement_task = None
        self.floss_task = None
        self.adbot_dance_tasks = {}
        self.adbot_user_dances = {}


        self.running = True

    # -----------------------------------------------------
    # DATABASE / ADMINS
    # -----------------------------------------------------

    def load_admins(self):
        if not self.bot_id:
            return

        self.admin_ids = get_admin_ids(int(self.bot_id))

    def is_admin(self, user_id):
        if str(user_id) in self.admin_ids:
            return True

        # مالک بات همیشه مدیر اصلی است.
        user = self.users.get(str(user_id))

        if user:
            return (
                user.username.lower().lstrip("@")
                == self.owner_username.lower()
            )

        return False

    # -----------------------------------------------------
    # USER CACHE
    # -----------------------------------------------------

    async def refresh_users(self):
        try:
            response = await self.highrise.get_room_users()

            content = getattr(response, "content", None)

            if not content:
                return

            for item in content:
                try:
                    user = item[0]
                    position = item[1]

                    self.users[str(user.id)] = user

                    if position is not None:
                        self.positions[str(user.id)] = position

                except Exception:
                    continue

            print(
                f"[USERS] loaded {len(self.users)} users"
            )

        except Exception as e:
            print("[USERS ERROR]", e)

    def find_user(self, text):
        text = text.strip()

        if text.startswith("@"):
            text = text[1:]

        # ID مستقیم
        for uid, user in self.users.items():
            if uid == text:
                return user

        # username
        for user in self.users.values():
            if user.username.lower() == text.lower():
                return user

        return None

    # -----------------------------------------------------
    # START
    # -----------------------------------------------------

    # محل‌های ذخیره‌شده ادمین
    def _ensure_locations(self):
        if not hasattr(self, "admin_locations"):
            self.admin_locations = {}

    async def on_start(self, session_metadata):
        print("[HIGHRISE] connected")

        self.load_admins()

        # مهم:
        # کاربران موجود قبل از ورود بات را هم می‌خوانیم.
        await self.refresh_users()

        try:
            await self.highrise.chat(BOT_START_MESSAGE)
        except Exception:
            pass

        # Floss loop
        if self.floss_task is None:
            self.floss_task = asyncio.create_task(
                self.floss_loop()
            )

    # -----------------------------------------------------
    # AD-BOT DANCE ENGINE
    # -----------------------------------------------------

    async def stop_adbot_dance(self, user):
        uid = str(user.id)
        self.adbot_user_dances.pop(uid, None)
        task = self.adbot_dance_tasks.pop(uid, None)
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception as e:
                print("[DANCE STOP ERROR]", e)

    async def start_adbot_dance(self, user, emote_id):
        uid = str(user.id)
        await self.stop_adbot_dance(user)
        self.adbot_user_dances[uid] = emote_id
        sleep_time = dance_duration(emote_id) + 1.0

        async def dance_loop():
            try:
                while self.adbot_user_dances.get(uid) == emote_id:
                    await self.highrise.send_emote(emote_id, uid)
                    await asyncio.sleep(sleep_time)
            except asyncio.CancelledError:
                return
            except Exception as e:
                print("[DANCE ERROR]", emote_id, type(e).__name__, e)

        self.adbot_dance_tasks[uid] = asyncio.create_task(dance_loop())

    # -----------------------------------------------------
    # USER JOIN
    # -----------------------------------------------------

    async def on_user_join(self, user, position):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = position

        print(
            f"[JOIN] @{user.username} [{uid}]"
        )

        try:
            await self.highrise.chat(
                f"<#00CCFF>👋 خوش آمدی @{user.username}"
            )
        except Exception:
            pass

    # -----------------------------------------------------
    # USER LEAVE
    # -----------------------------------------------------

    async def on_user_leave(self, user):
        uid = str(user.id)

        self.users.pop(uid, None)
        self.positions.pop(uid, None)

        # frozen را پاک نمی‌کنیم تا اگر دوباره برگشت
        # بتوانیم دوباره کنترلش کنیم.

    # -----------------------------------------------------
    # USER MOVE / FREEZE
    # -----------------------------------------------------

    async def on_user_move(self, user, destination):
        uid = str(user.id)

        self.users[uid] = user
        self.positions[uid] = destination

        if uid in self.frozen:
            old_position = self.frozen[uid]

            try:
                await self.highrise.teleport(
                    uid,
                    old_position,
                )
            except Exception as e:
                print("[FREEZE ERROR]", e)

    # -----------------------------------------------------
    # CHAT
    # -----------------------------------------------------


# === LINUXX_COMMAND_FIX_V4 ===

    async def _lx_room_users(self):
        try:
            result = await self.highrise.get_room_users()
            return getattr(result, "content", []) or []
        except Exception as e:
            print("[ROOM USERS ERROR]", repr(e))
            return []

    async def _lx_find_user(self, username):
        username = username.strip().lstrip("@").lower()

        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if str(u.username).lower() == username:
                    return u, pos
            except Exception:
                continue

        return None, None

    async def _lx_my_position(self, user_id):
        for item in await self._lx_room_users():
            try:
                u = item[0]
                pos = item[1]

                if u.id == user_id:
                    return pos
            except Exception:
                continue

        return None

    async def _lx_send(self, text):
        try:
            await self.highrise.chat(text)
        except Exception as e:
            print("[CHAT ERROR]", repr(e))

    async def _lx_command_fix(self, user, message):

        msg = str(message).strip()
        parts = msg.split()

        if not parts:
            return False

        low = msg.lower()

        # ============================================================
        # !بیا @id
        # ============================================================
        if low.startswith("!بیا "):

            if len(parts) < 2:
                await self._lx_send("❌ فرمت: !بیا @id")
                return True

            target, _ = await self._lx_find_user(parts[1])

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            my_pos = await self._lx_my_position(user.id)

            if my_pos is None:
                await self._lx_send("❌ موقعیت شما پیدا نشد.")
                return True

            try:
                await self.highrise.teleport(target.id, my_pos)

                await self._lx_send(
                    f"✅ @{target.username} به موقعیت شما منتقل شد."
                )

            except Exception as e:
                print("[BRING ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !برو به @id نام محل
        # ============================================================
        if low.startswith("!برو به "):

            if len(parts) < 3:
                await self._lx_send(
                    "❌ فرمت: !برو به @id نام محل"
                )
                return True

            target_name = parts[2]
            location_name = self._normalize_location_name(" ".join(parts[3:]))

            if not location_name:
                await self._lx_send(
                    "❌ نام محل را وارد کن."
                )
                return True

            target, _ = await self._lx_find_user(target_name)

            if target is None:
                await self._lx_send("❌ کاربر پیدا نشد.")
                return True

            locations = getattr(self, "admin_locations", {})

            position = locations.get(self._normalize_location_name(location_name))

            # اگر کلید دقیق نبود، مقایسه نرمال‌شده
            if position is None:
                for _name, _pos in locations.items():
                    if self._normalize_location_name(_name) == self._normalize_location_name(location_name):
                        position = _pos
                        break

            # پشتیبانی از حروف بزرگ/کوچک
            if position is None:
                for key, value in locations.items():
                    if str(key).lower() == location_name:
                        position = value
                        break

            if position is None:
                await self._lx_send(
                    f"<#FF4444>❌ موقعیت <#FFD700>«{location_name}» <#FF4444>پیدا نشد."
                )
                return True

            try:
                await self.highrise.teleport(
                    target.id,
                    position
                )

                await self._lx_send(
                    f"✅ @{target.username} به «{location_name}» منتقل شد."
                )

            except Exception as e:
                print("[GOTO ERROR]", repr(e))
                await self._lx_send(
                    "❌ انتقال انجام نشد."
                )

            return True

        # ============================================================
        # !تیپ
        #
        # پشتیبانی:
        # !تیپ ۱ @id
        # !تیپ ۱ همه
        # !تیپ همه ۱
        # ============================================================
        if low.startswith("!تیپ "):

            args = parts[1:]

            if len(args) < 2:
                await self._lx_send(
                    "❌ فرمت:\n!تیپ ۱ @id\n!تیپ ۱ همه\n!تیپ همه ۱"
                )
                return True

            # تبدیل اعداد فارسی
            trans = str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789"
            )

            def number(x):
                try:
                    return int(str(x).translate(trans))
                except Exception:
                    return None

            amount = None
            target_arg = None

            # !تیپ همه ۱
            if str(args[0]).lower() == "همه":
                amount = number(args[1])
                target_arg = "همه"

            # !تیپ ۱ همه
            else:
                amount = number(args[0])
                target_arg = args[1]

            allowed = {
                1: "gold_bar_1",
                5: "gold_bar_5",
                10: "gold_bar_10",
                50: "gold_bar_50",
                100: "gold_bar_100",
                500: "gold_bar_500",
                1000: "gold_bar_1k",
                5000: "gold_bar_5000",
                10000: "gold_bar_10k",
            }

            if amount not in allowed:
                await self._lx_send(
                    "❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return True

            gold_bar = allowed[amount]

            # ========================================================
            # TIP ALL
            # ========================================================
            if str(target_arg).lower() == "همه":

                users = await self._lx_room_users()

                success = 0
                failed = 0

                for item in users:

                    try:
                        target = item[0]

                        # خود بات
                        if getattr(self, "bot_id", None):
                            if target.id == self.bot_id:
                                continue

                        # مالک/دستوردهنده هم طبق دستور تیپ می‌گیرد
                        try:
                            await self.highrise.tip_user(
                                target.id,
                                gold_bar
                            )
                            success += 1

                        except Exception as e:
                            failed += 1
                            print(
                                f"[TIP ALL ERROR] "
                                f"@{target.username}: {e}"
                            )

                    except Exception:
                        failed += 1

                await self._lx_send(
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {success}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return True

            # ========================================================
            # TIP ONE
            # ========================================================
            target, _ = await self._lx_find_user(target_arg)

            if target is None:
                await self._lx_send(
                    "❌ کاربر پیدا نشد."
                )
                return True

            try:
                await self.highrise.tip_user(
                    target.id,
                    gold_bar
                )

                await self._lx_send(
                    f"💰 {amount} تیپ به "
                    f"@{target.username} ارسال شد."
                )

            except Exception as e:
                print("[TIP ERROR]", repr(e))
                await self._lx_send(
                    "❌ ارسال تیپ انجام نشد."
                )

            return True

        return False



    def _normalize_location_name(self, name):
        if not name:
            return ""
        return " ".join(str(name).strip().lower().split())

    async def on_chat(self, user, message):
        # === LINUXX_COMMAND_FIX_CALL ===
        try:
            if await self._lx_command_fix(user, message):
                return
        except Exception as e:
            print('[COMMAND FIX ERROR]', repr(e))
        uid = str(user.id)

        self.users[uid] = user

        text = message.strip()

        if not text:
            return

        print(
            f"[CHAT] @{user.username}: {text}"
        )

        # -----------------------------------------------
        # AD-BOT DANCE / EMOTE
        # -----------------------------------------------

        normalized = text.translate(
            str.maketrans(
                "۰۱۲۳۴۵۶۷۸۹",
                "0123456789",
            )
        )

        emote_id = resolve_emote(normalized)

        if emote_id:
            try:
                await self.start_adbot_dance(user, emote_id)
            except Exception as e:
                print("[DANCE START ERROR]", e)
            return

        if normalized.lower() in (
            "stop",
            "dance stop",
            "!stop",
            "!dance stop",
            "توقف",
            "توقف دنس",
        ):
            await self.stop_adbot_dance(user)
            return

        # -----------------------------------------------
        # TASE
        # -----------------------------------------------

        if text == "!تاس":
            number = random.randint(1, 6)

            await self.highrise.chat(
                f"<#FFD700>🎲 نتیجه تاس: {number}"
            )

            return

        # -----------------------------------------------
        # COMMANDS
        # -----------------------------------------------

        if text == "!دستورات":

            # -------------------------------------------
            # دستورات عمومی — برای همه کاربران
            # -------------------------------------------

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\\n"
                "<#FFD700>📖 دستورات عمومی\\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\\n"
                "<#FFFFFF>!تاس\\n"
                "<#FFFFFF>!دستورات\\n"
                "<#FFFFFF>!ایده و اجرا\\n"
                "<#FFFFFF>نام محل عمومی = تلپورت به محل\\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            # -------------------------------------------
            # دستورات مدیریتی — فقط مدیر و ادمین
            # -------------------------------------------

            if self.is_admin(uid):

                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>━━━━━━━━━━━━━━━━━━━━\\n"
                    "<#FFD700>👑 دستورات مدیریتی\\n"
                    "<#FFFFFF>!لباس\\n"
                    "<#FFFFFF>!لباس @id\\n"
                    "<#FFFFFF>!کیک @id\\n"
                    "<#FFFFFF>!فریز @id\\n"
                    "<#FFFFFF>!انفریز @id\\n"
                    "<#FFFFFF>!ادمین @id\\n"
                    "<#FFFFFF>!حذف ادمین @id\\n"
                    "<#FFFFFF>!موت @id\\n"
                    "<#FFFFFF>!انموت @id\\n"
                    "<#FFFFFF>!حرکت\\n"
                    "<#FFFFFF>!حرکت توقف\\n"
                    "<#FFFFFF>!بات\\n"
                    "<#FFFFFF>!محل ذخیره ادمین نام\\n"
                    "<#FFFFFF>!ذخیره محل عمومی نام\\n"
                    "<#FFFFFF>!لوپ متن\\n"
                    "<#FFFFFF>!لوپ ثانیه\\n"
                    "<#FFFFFF>!اسپم تعداد متن\\n"
                    "<#FFD700>━━━━━━━━━━━━━━━━━━━━"
                )

            return

        # -----------------------------------------------
        # ADMIN CHECK
        # -----------------------------------------------

        admin_commands = (
            text.startswith("!لباس")
            or text.startswith("!کیک")
            or text.startswith("!فریز")
            or text.startswith("!انفریز")
            or text.startswith("!ادمین")
            or text.startswith("!حذف ادمین")
            or text.startswith("!موت")
            or text.startswith("!انموت")
            or text == "!حرکت"
            or text == "!حرکت توقف"
            or text == "!بات"
            or text.startswith("!محل ذخیره ادمین ")
            or text.startswith("!ذخیره محل عمومی ")
            or text.startswith("!لوپ ")
            or text.startswith("!اسپم ")
            or text == "!موجودی"
            or text.startswith("!تیپ ")
        )

        if admin_commands and not self.is_admin(uid):
            await self.highrise.send_whisper(
                uid,
                "<#FF5555>❌ شما مدیر بات نیستید."
            )
            return

        # -----------------------------------------------
        # BOT - COME TO ADMIN
        # -----------------------------------------------

        if text == "!بات":

            position = self.positions.get(uid)

            if position is None:
                await self.highrise.chat(
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            try:
                await self.highrise.walk_to(position)

                await self.highrise.chat(
                    "<#00FF88>🤖 بات به محل شما آمد."
                )

            except Exception as e:
                print("[BOT MOVE ERROR]", repr(e))

                await self.highrise.chat(
                    "<#FF5555>❌ خطا در حرکت بات."
                )

            return

        # -----------------------------------------------
        # OUTFIT
        # -----------------------------------------------

        if text == "!لباس":

            try:
                outfit_response = (
                    await self.highrise.get_user_outfit(
                        uid
                    )
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if outfit:
                    result = await self.highrise.set_outfit(
                        list(outfit)
                    )

                    if result is not None:
                        print(
                            "[OUTFIT RESULT]",
                            result,
                        )

                    await self.highrise.chat(
                        "<#00FF88>👕 لباس با موفقیت کپی شد."
                    )

                else:
                    await self.highrise.send_whisper(
                        uid,
                        "لباس کاربر پیدا نشد."
                    )

            except Exception as e:
                print("[OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"خطا در کپی لباس: {e}"
                )

            return

        # -----------------------------------------------
        # LINUXX GOLD TIP SYSTEM
        # -----------------------------------------------

        TIP_BARS = {
            1: "gold_bar_1",
            5: "gold_bar_5",
            10: "gold_bar_10",
            50: "gold_bar_50",
            100: "gold_bar_100",
            500: "gold_bar_500",
            1000: "gold_bar_1k",
            5000: "gold_bar_5000",
            10000: "gold_bar_10k",
        }

        TIP_LABELS = {
            1: "۱",
            5: "۵",
            10: "۱۰",
            50: "۵۰",
            100: "۱۰۰",
            500: "۵۰۰",
            1000: "۱۰۰۰",
            5000: "۵۰۰۰",
            10000: "۱۰۰۰۰",
        }

        def get_gold_amount(wallet_response):
            total = 0

            try:
                content = getattr(
                    wallet_response,
                    "content",
                    []
                )

                for currency in content:
                    ctype = str(
                        getattr(currency, "type", "")
                    ).lower()

                    amount = int(
                        getattr(currency, "amount", 0)
                    )

                    # نسخه‌های مختلف SDK ممکن است نام Gold را
                    # کمی متفاوت برگردانند.
                    if (
                        ctype == "gold"
                        or "gold" in ctype
                    ):
                        total += amount

            except Exception as e:
                print("[TIP WALLET PARSE ERROR]", repr(e))

            return total

        async def get_bot_gold():
            try:
                wallet = await self.highrise.get_wallet()
                return get_gold_amount(wallet)
            except Exception as e:
                print("[TIP WALLET ERROR]", repr(e))
                return None

        # -----------------------------------------------
        # موجودی گلد
        # -----------------------------------------------

        if text == "!موجودی":

            gold = await get_bot_gold()

            if gold is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ دریافت موجودی گلد ناموفق بود."
                )
                return

            await self.highrise.send_whisper(
                uid,
                f"<#FFD700>💰 موجودی گلد بات: {gold}"
            )

            return

        # -----------------------------------------------
        # TIP
        #
        # !تیپ ۱ @id
        # !تیپ ۵ @id
        # !تیپ ۱۰ @id
        # !تیپ همه ۱
        # -----------------------------------------------

        if text.startswith("!تیپ "):

            parts = text.split()

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n"
                    "!تیپ ۱ @id\n"
                    "!تیپ ۵ @id\n"
                    "!تیپ همه ۱"
                )
                return

            # تبدیل اعداد فارسی به انگلیسی
            def normalize_number(value):
                return value.translate(
                    str.maketrans(
                        "۰۱۲۳۴۵۶۷۸۹",
                        "0123456789"
                    )
                )

            # -------------------------------------------
            # TIP ALL
            # -------------------------------------------

            if parts[1] == "همه":

                amount_text = normalize_number(
                    parts[2]
                )

                if not amount_text.isdigit():
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار گلد نامعتبر است."
                    )
                    return

                amount = int(amount_text)

                if amount not in TIP_BARS:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ مقدار مجاز:\n"
                        "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                        "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                    )
                    return

                try:
                    room_response = (
                        await self.highrise.get_room_users()
                    )

                    room_users = getattr(
                        room_response,
                        "content",
                        []
                    )

                except Exception as e:
                    print(
                        "[TIP ROOM USERS ERROR]",
                        repr(e)
                    )

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ دریافت کاربران روم ناموفق بود."
                    )
                    return

                sent = 0
                failed = 0

                await self.highrise.chat(
                    f"<#FFD700>💰 شروع تیپ {TIP_LABELS[amount]} گلد به کاربران..."
                )

                for item in room_users:

                    target = getattr(
                        item,
                        "user",
                        item
                    )

                    target_id = getattr(
                        target,
                        "id",
                        None
                    )

                    target_username = getattr(
                        target,
                        "username",
                        "unknown"
                    )

                    if not target_id:
                        continue

                    # خود بات تیپ نشود
                    if str(target_id) == str(
                        getattr(self, "bot_id", "")
                    ):
                        continue

                    try:
                        wallet_gold = await get_bot_gold()

                        if wallet_gold is not None:
                            if wallet_gold < amount:
                                await self.highrise.send_whisper(
                                    uid,
                                    f"<#FF5555>🛑 موجودی تمام شد.\n"
                                    f"<#FFFFFF>تعداد ارسال موفق: {sent}"
                                )
                                return

                        result = await self.highrise.tip_user(
                            str(target_id),
                            TIP_BARS[amount]
                        )

                        if result == "success":

                            sent += 1

                            print(
                                f"[TIP] {amount} -> "
                                f"@{target_username}"
                            )

                            # مطابق منطق AD-BOT:
                            # بین ارسال‌های متوالی فاصله کوتاه
                            await asyncio.sleep(3)

                        elif result == "insufficient_funds":

                            await self.highrise.send_whisper(
                                uid,
                                f"<#FF5555>🛑 موجودی گلد کافی نیست.\n"
                                f"<#FFFFFF>ارسال موفق: {sent}"
                            )

                            return

                        else:

                            failed += 1

                            print(
                                "[TIP ERROR RESULT]",
                                result
                            )

                    except Exception as e:

                        failed += 1

                        print(
                            "[TIP USER ERROR]",
                            target_username,
                            repr(e)
                        )

                        # خطای یک کاربر باعث خراب شدن
                        # کل دستور نشود.
                        continue

                await self.highrise.send_whisper(
                    uid,
                    f"<#00FF88>✅ تیپ همه تمام شد.\n"
                    f"<#FFFFFF>موفق: {sent}\n"
                    f"<#FFFFFF>ناموفق: {failed}"
                )

                return

            # -------------------------------------------
            # TIP ONE USER
            # -------------------------------------------

            amount_text = normalize_number(
                parts[1]
            )

            if not amount_text.isdigit():

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار گلد باید عدد باشد."
                )
                return

            amount = int(amount_text)

            if amount not in TIP_BARS:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ مقدار مجاز:\n"
                    "۱، ۵، ۱۰، ۵۰، ۱۰۰، ۵۰۰، "
                    "۱۰۰۰، ۵۰۰۰، ۱۰۰۰۰"
                )
                return

            target_name = parts[2].strip()

            target = self.find_user(
                target_name
            )

            if not target:

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ کاربر پیدا نشد."
                )
                return

            wallet_gold = await get_bot_gold()

            if wallet_gold is not None and wallet_gold < amount:

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ موجودی کافی نیست.\n"
                    f"<#FFFFFF>موجودی: {wallet_gold}\n"
                    f"<#FFFFFF>مورد نیاز: {amount}"
                )
                return

            try:

                result = await self.highrise.tip_user(
                    str(target.id),
                    TIP_BARS[amount]
                )

                if result == "success":

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>✅ {TIP_LABELS[amount]} گلد "
                        f"به @{target.username} تیپ شد."
                    )

                elif result == "insufficient_funds":

                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ موجودی گلد کافی نیست."
                    )

                else:

                    await self.highrise.send_whisper(
                        uid,
                        f"<#FF5555>❌ تیپ انجام نشد.\n"
                        f"نتیجه: {result}"
                    )

            except Exception as e:

                print(
                    "[TIP USER ERROR]",
                    repr(e)
                )

                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ خطا هنگام ارسال گلد."
                )

            return

        # -----------------------------------------------
        # FIND TARGET
        # -----------------------------------------------

        def target_from_command(command):
            parts = command.split(maxsplit=1)

            if len(parts) < 2:
                return None

            return self.find_user(parts[1])

        # -----------------------------------------------
        # KICK
        # -----------------------------------------------

        if text.startswith("!کیک "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "kick",
                )

                await self.highrise.chat(
                    f"<#FF5555>👢 @{target.username} کیک شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # FREEZE
        # -----------------------------------------------

        if text.startswith("!فریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            position = self.positions.get(
                target_id
            )

            if position is None:
                await self.refresh_users()
                position = self.positions.get(
                    target_id
                )

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "❌ موقعیت کاربر پیدا نشد."
                )
                return

            self.frozen[target_id] = position

            await self.highrise.chat(
                f"<#00CCFF>🧊 @{target.username} فریز شد."
            )

            return

        # -----------------------------------------------
        # UNFREEZE
        # -----------------------------------------------

        if text.startswith("!انفریز "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            self.frozen.pop(
                str(target.id),
                None,
            )

            await self.highrise.chat(
                f"<#00FF88>🔓 @{target.username} انفریز شد."
            )

            return

        # -----------------------------------------------
        # MUTE
        # -----------------------------------------------

        if text.startswith("!موت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "mute",
                )

                self.muted.add(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#FFAA00>🔇 @{target.username} موت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # UNMUTE
        # -----------------------------------------------

        if text.startswith("!انموت "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                await self.highrise.moderate_room(
                    str(target.id),
                    "unmute",
                )

                self.muted.discard(
                    str(target.id)
                )

                await self.highrise.chat(
                    f"<#00FF88>🔊 @{target.username} انموت شد."
                )

            except Exception as e:
                await self.highrise.send_whisper(
                    uid,
                    f"خطا: {e}"
                )

            return

        # -----------------------------------------------
        # ADD ADMIN
        # -----------------------------------------------

        if text.startswith("!ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            add_admin(
                int(self.bot_id),
                target_id,
                target.username,
            )

            self.admin_ids.add(
                target_id
            )

            await self.highrise.chat(
                f"<#FFD700>👑 @{target.username} مدیر شد."
            )

            return

        # -----------------------------------------------
        # REMOVE ADMIN
        # -----------------------------------------------

        if text.startswith("!حذف ادمین "):

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "❌ ایدی طرف پیدا نشد."
                )
                return

            target_id = str(target.id)

            remove_admin(
                int(self.bot_id),
                target_id,
            )

            self.admin_ids.discard(
                target_id
            )

            await self.highrise.chat(
                f"<#FF5555>❌ @{target.username} از مدیریت حذف شد."
            )

            return

        # -----------------------------------------------
        # EXTRA LOCATION / LOOP / SPAM / OUTFIT COMMANDS
        # -----------------------------------------------

        # !ایده و اجرا
        if text == "!ایده و اجرا":
            await self.highrise.chat(
                "<#FFD700>💡 Idea and implementation by "
                "<#00CCFF>@84.43 "
                "<#FFFFFF>and "
                "<#00CCFF>@55._65"
            )
            return

        # ------------------------------------------------
        # !دستورات
        # ------------------------------------------------

        if text == "!دستورات":

            await self.highrise.chat(
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━\n"
                "<#FFD700>📖 دستورات عمومی\n"
                "<#FFFFFF>۱ تا ۲۵۰ = دنس\n"
                "<#FFFFFF>!تاس\n"
                "<#FFFFFF>!دستورات\n"
                "<#FFFFFF>!ایده و اجرا\n"
                "<#FFFFFF>محل‌های عمومی: نام محل\n"
                "<#00CCFF>━━━━━━━━━━━━━━━━━━━━"
            )

            if self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>👑 دستورات مدیریتی\n"
                    "!لباس\n"
                    "!لباس @id\n"
                    "!کیک @id\n"
                    "!فریز @id\n"
                    "!انفریز @id\n"
                    "!ادمین @id\n"
                    "!حذف ادمین @id\n"
                    "!موت @id\n"
                    "!انموت @id\n"
                    "!موجودی\n"
                    "!تیپ ۱ @id\n"
                    "!تیپ ۵ @id\n"
                    "!تیپ همه ۱\n"
                    "!تیپ همه ۵\n"
                    "!حرکت\n"
                    "!حرکت توقف\n"
                    "!بات\n\n"
                    "📍 محل ادمین:\n"
                    "!محل ذخیره ادمین t1\n"
                    "t1\n\n"
                    "🌍 محل عمومی:\n"
                    "!ذخیره محل عمومی a1\n"
                    "a1\n\n"
                    "🔁 لوپ:\n"
                    "!لوپ سلام\n"
                    "!لوپ 1\n"
                    "!لوپ توقف\n\n"
                    "📢 اسپم:\n"
                    "!اسپم 100 سلام"
                )

            return

        # ------------------------------------------------
        # LOOP STOP
        # ------------------------------------------------

        if text == "!لوپ توقف":

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ را متوقف کند."
                )
                return

            await self._stop_loop()

            await self.highrise.chat(
                "<#FFD700>🛑 لوپ متوقف شد."
            )
            return

        # ------------------------------------------------
        # LOOP TEXT
        # ------------------------------------------------

        if text.startswith("!لوپ "):

            value = text[5:].strip()

            if not value:
                return

            # اگر فقط عدد باشد یعنی تعیین تأخیر
            if value.isdigit():

                if not self.is_admin(uid):
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ تنظیم کند."
                    )
                    return

                if not self.pending_loop_text:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FFD700>ابتدا بنویس:\n!لوپ متن دلخواه\n"
                        "مثال: !لوپ سلام"
                    )
                    return

                delay = float(value)

                if delay < 1:
                    delay = 1

                if delay > 3600:
                    delay = 3600

                loop_text = self.pending_loop_text
                self.pending_loop_text = None

                await self._start_loop(
                    loop_text,
                    delay,
                )

                await self.highrise.chat(
                    f"<#00FF88>🔁 لوپ شروع شد\n"
                    f"<#FFFFFF>متن: {loop_text}\n"
                    f"<#FFFFFF>تأخیر: {delay:g} ثانیه"
                )

                return

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند لوپ بسازد."
                )
                return

            self.pending_loop_text = value
            self.pending_loop_user = uid

            await self.highrise.send_whisper(
                uid,
                "<#FFD700>⏱ تأخیر لوپ را وارد کن.\n"
                "<#FFFFFF>مثال:\n"
                "!لوپ 1\n\n"
                "<#FFFFFF>برای ارسال هر ۱ ثانیه."
            )

            return

        # ------------------------------------------------
        # SPAM
        # ------------------------------------------------

        if text.startswith("!اسپم "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند اسپم ارسال کند."
                )
                return

            parts = text.split(maxsplit=2)

            if len(parts) < 3:
                await self.highrise.send_whisper(
                    uid,
                    "<#FFD700>فرمت صحیح:\n!اسپم 100 سلام"
                )
                return

            try:
                count = int(
                    parts[1].translate(
                        str.maketrans(
                            "۰۱۲۳۴۵۶۷۸۹",
                            "0123456789",
                        )
                    )
                )
            except Exception:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ تعداد پیام باید عدد باشد."
                )
                return

            spam_text = parts[2].strip()

            if count < 1:
                count = 1

            # جلوگیری از مقدارهای بسیار بزرگ
            if count > 500:
                count = 500

            for _ in range(count):
                try:
                    await self.highrise.chat(spam_text)
                except Exception as e:
                    print("[SPAM ERROR]", e)
                    break

            return

        # ------------------------------------------------
        # ADMIN SAVED LOCATION
        # !محل ذخیره ادمین t1
        # ------------------------------------------------

        if text.startswith("!محل ذخیره ادمین "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر بات می‌تواند محل ادمین ذخیره کند."
                )
                return

            name = text[len("!محل ذخیره ادمین "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["admin"] and len(locations["admin"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل ادمین قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["admin"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>📍 محل ادمین «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # PUBLIC SAVED LOCATION
        # !ذخیره محل عمومی a1
        # ------------------------------------------------

        if text.startswith("!ذخیره محل عمومی "):

            # فقط مدیر اصلی
            if str(user.username).lower() != "84.43":
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ فقط مدیر اصلی بات می‌تواند محل عمومی ذخیره کند."
                )
                return

            name = text[len("!ذخیره محل عمومی "):].strip()

            if not name:
                return

            locations = self._load_locations()

            if name not in locations["public"] and len(locations["public"]) >= 5:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ حداکثر ۵ محل عمومی قابل ذخیره است."
                )
                return

            position = self.positions.get(uid)

            if position is None:
                await self.refresh_users()
                position = self.positions.get(uid)

            if position is None:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ موقعیت شما پیدا نشد."
                )
                return

            locations["public"][name] = self._position_to_dict(position)
            self._save_locations(locations)

            await self.highrise.chat(
                f"<#00FF88>🌍 محل عمومی «{name}» ذخیره شد."
            )
            return

        # ------------------------------------------------
        # TELEPORT TO SAVED LOCATION
        # ------------------------------------------------

        locations = self._load_locations()

        # محل ادمین فقط برای ادمین‌ها
        if text in locations["admin"]:

            if not self.is_admin(uid):
                return

            position = self._dict_to_position(
                locations["admin"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>📍 به محل ادمین «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[ADMIN TELEPORT ERROR]", e)

            return

        # محل عمومی برای همه
        if text in locations["public"]:

            position = self._dict_to_position(
                locations["public"][text]
            )

            if position:
                try:
                    await self.highrise.teleport(
                        uid,
                        position,
                    )

                    await self.highrise.send_whisper(
                        uid,
                        f"<#00FF88>🌍 به محل «{text}» منتقل شدی."
                    )

                except Exception as e:
                    print("[PUBLIC TELEPORT ERROR]", e)

            return

        # ------------------------------------------------
        # OUTFIT FROM TARGET
        # !لباس @id
        # ------------------------------------------------

        if text.startswith("!لباس "):

            if not self.is_admin(uid):
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ شما مدیر بات نیستید."
                )
                return

            target = target_from_command(text)

            if not target:
                await self.highrise.send_whisper(
                    uid,
                    "<#FF5555>❌ ایدی طرف پیدا نشد."
                )
                return

            try:
                outfit_response = await self.highrise.get_user_outfit(
                    str(target.id)
                )

                outfit = getattr(
                    outfit_response,
                    "outfit",
                    None,
                )

                if outfit is None:
                    outfit = getattr(
                        outfit_response,
                        "content",
                        None,
                    )

                if not outfit:
                    await self.highrise.send_whisper(
                        uid,
                        "<#FF5555>❌ لباس کاربر پیدا نشد."
                    )
                    return

                result = await self.highrise.set_outfit(
                    list(outfit)
                )

                await self.highrise.chat(
                    f"<#00FF88>👕 لباس @{target.username} روی بات اعمال شد."
                )

            except Exception as e:
                print("[COPY OUTFIT ERROR]", e)

                await self.highrise.send_whisper(
                    uid,
                    f"<#FF5555>❌ خطا در کپی لباس: {e}"
                )

            return

        # -----------------------------------------------
        # MOVEMENT
        # -----------------------------------------------

        if text == "!حرکت":

            if self.movement_task:
                await self.highrise.send_whisper(
                    uid,
                    "بات در حال حرکت است."
                )
                return

            self.movement_task = asyncio.create_task(
                self.random_walk()
            )

            await self.highrise.chat(
                "<#00FF88>🚶 حرکت بات شروع شد."
            )

            return

        if text == "!حرکت توقف":

            if self.movement_task:
                self.movement_task.cancel()
                self.movement_task = None

            await self.highrise.chat(
                "<#FFD700>🛑 حرکت بات متوقف شد."
            )

            return


    # -----------------------------------------------------
    # LINUXX_EXTRA_COMMANDS_V2
    # SAVED LOCATIONS
    # -----------------------------------------------------

    def _locations_file(self):
        return BASE_DIR / f"locations_{self.bot_id}.json"

    def _load_locations(self):
        path = self._locations_file()

        try:
            if path.exists():
                data = json.loads(
                    path.read_text(encoding="utf-8")
                )
            else:
                data = {}
        except Exception:
            data = {}

        if not isinstance(data, dict):
            data = {}

        data.setdefault("admin", {})
        data.setdefault("public", {})

        return data

    def _save_locations(self, data):
        try:
            self._locations_file().write_text(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            return True
        except Exception as e:
            print("[LOCATION SAVE ERROR]", e)
            return False

    def _position_to_dict(self, position):
        if position is None:
            return None

        return {
            "x": getattr(position, "x", 0),
            "y": getattr(position, "y", 0),
            "z": getattr(position, "z", 0),
            "facing": getattr(position, "facing", "FrontRight"),
        }

    def _dict_to_position(self, data):
        if not data:
            return None

        try:
            return Position(
                float(data["x"]),
                float(data["y"]),
                float(data["z"]),
                data.get("facing", "FrontRight"),
            )
        except Exception as e:
            print("[LOCATION POSITION ERROR]", e)
            return None

    def _set_pending_loop(self, text):
        self.pending_loop_text = text
        self.pending_loop_user = None

    async def _start_loop(self, text, delay):
        if hasattr(self, "loop_task") and self.loop_task:
            self.loop_task.cancel()
            try:
                await self.loop_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_text = text
        self.loop_delay = delay

        async def loop_runner():
            try:
                while True:
                    await self.highrise.chat(self.loop_text)
                    await asyncio.sleep(self.loop_delay)

            except asyncio.CancelledError:
                return

            except Exception as e:
                print("[LOOP ERROR]", e)

        self.loop_task = asyncio.create_task(loop_runner())

    async def _stop_loop(self):
        task = getattr(self, "loop_task", None)

        if task:
            task.cancel()

            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self.loop_task = None

    # -----------------------------------------------------
    # EXTRA COMMANDS V2
    # -----------------------------------------------------

    # -----------------------------------------------------
    # RANDOM WALK
    # -----------------------------------------------------

    async def random_walk(self):

        # چند نقطه نمونه برای حرکت.
        # بعداً می‌توانیم نقاط مخصوص هر روم را از پنل تنظیم کنیم.
        points = [
            Position(0, 0, 0, "FrontRight"),
            Position(2, 0, 2, "FrontRight"),
            Position(-2, 0, 2, "FrontLeft"),
            Position(2, 0, -2, "BackRight"),
            Position(-2, 0, -2, "BackLeft"),
        ]

        try:
            while True:

                destination = random.choice(
                    points
                )

                try:
                    await self.highrise.walk_to(
                        destination
                    )
                except Exception as e:
                    print(
                        "[WALK ERROR]",
                        e
                    )

                await asyncio.sleep(
                    random.uniform(
                        3,
                        7,
                    )
                )

        except asyncio.CancelledError:
            return

    # -----------------------------------------------------
    # FLOSS LOOP
    # -----------------------------------------------------

    async def floss_loop(self):

        floss = resolve_emote("222") or "dance-floss"
        sleep_time = dance_duration(floss) + 1.0

        while self.running:

            try:
                await self.highrise.send_emote(floss)

            except asyncio.CancelledError:
                return

            except Exception as e:
                print("[FLOSS ERROR]", e)

                # صبر برای reconnect شدن Highrise
                await asyncio.sleep(5)
                continue

            await asyncio.sleep(sleep_time)

    # -----------------------------------------------------
    # PRIVATE MESSAGE
    # -----------------------------------------------------

    async def on_message(
        self,
        user_id,
        conversation_id,
        is_new_conversation,
    ):

        try:
            await self.highrise.send_message(
                conversation_id,
                PV_MESSAGE,
            )
        except Exception as e:
            print(
                "[PV ERROR]",
                e
            )


# ---------------------------------------------------------
# TELEGRAM MANAGER
# ---------------------------------------------------------



# =========================================================
# LINUXX AUTH SYSTEM
# =========================================================

AUTH_PASSWORD = "python botOrder.py"
AUTH_FILE = BASE_DIR / "telegram_auth.json"

def load_auth():
    import json

    if not AUTH_FILE.exists():
        return {}

    try:
        return json.loads(
            AUTH_FILE.read_text(encoding="utf-8")
        )
    except Exception:
        return {}

def save_auth(data):
    import json

    AUTH_FILE.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2
        ),
        encoding="utf-8"
    )

def auth_status(user_id):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    return user

def is_authorized(user_id):
    user = auth_status(user_id)

    return (
        user.get("authorized", False)
        and not user.get("blocked", False)
    )

def is_blocked(user_id):
    return auth_status(user_id).get(
        "blocked",
        False
    )

def check_password(user_id, password):
    data = load_auth()
    key = str(user_id)

    user = data.get(
        key,
        {
            "attempts": 0,
            "authorized": False,
            "blocked": False,
        }
    )

    if user.get("blocked"):
        return "blocked"

    if password == AUTH_PASSWORD:

        user["authorized"] = True
        user["attempts"] = 0
        user["blocked"] = False

        data[key] = user
        save_auth(data)

        return "ok"

    user["attempts"] = int(
        user.get("attempts", 0)
    ) + 1

    if user["attempts"] >= 3:

        user["blocked"] = True
        user["authorized"] = False

        data[key] = user
        save_auth(data)

        return "blocked"

    data[key] = user
    save_auth(data)

    return 3 - user["attempts"]





if __name__ == "__main__":
    # The Highrise CLI imports this module as main:HighriseBot.
    pass
