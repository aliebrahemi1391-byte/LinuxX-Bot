# Buildozer service entry point. It keeps the local controller alive.
import main
main.start_server() if hasattr(main,"start_server") else None
